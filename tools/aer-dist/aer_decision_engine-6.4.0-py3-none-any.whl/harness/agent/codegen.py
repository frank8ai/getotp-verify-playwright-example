"""Code generation step for the stateless cloud loop.

The loop used to open a pull request whose only content was a marker file. That
is misleading evidence: the PR looks like work and contains none. This module
supplies the missing step.

It deliberately reuses the existing agent harness instead of shelling out
ad hoc:

* :func:`harness.agent.runner.compile_codex_exec_argv` owns the `codex exec`
  command line, so the isolation flags live in one place.
* :class:`harness.agent.runner.AgentRunner` turns the JSON event stream into a
  state-machine trace and enforces the token budget.

The step is invoked with ``sandbox_mode="workspace-write"``. The harness
defaults to ``read-only``, which would make code generation a silent no-op.

``workspace-write`` is a Linux/macOS capability. Measured on Windows: the agent
receives an effective mode of ``read-only``, attempts the write, is refused by
the sandbox, and the run ends with ``exit_code=0`` after ~49k tokens and no
workspace change. ``danger-full-access`` does write there. The loop is not
affected -- ``docs/adr/0001-single-unattended-execution-path.md`` and this
change's ``design.md`` put its executor on Linux, and the Windows path is the
demoted observation-only chain -- but a developer running the loop on Windows to
debug it will see a token-burning no-op rather than a failure.

Because the sandbox is writable, the protected surface named by
``config/verification-manifest.json`` is enforced here as a post-condition: a
run whose diff touches a protected path fails instead of opening a pull request.
Asking the model not to touch those paths is not an enforcement mechanism.

Deployment configuration arrives through the environment, because the argv is
built with ``--ignore-user-config``: the runner's own ``config.toml`` is not
read, so a gateway deployment has to name its model and provider explicitly.

* ``AER_CODEX_MODEL`` -- passed as ``-m``.
* ``AER_CODEX_CONFIG`` -- newline-separated ``-c key=value`` overrides.
* ``AER_CODEX_HOME`` -- becomes the child's ``CODEX_HOME``.
"""

from __future__ import annotations

import json
import os
import subprocess
from dataclasses import dataclass
from pathlib import Path
from typing import Callable, Mapping, Sequence

from .runner import AgentRunner, compile_codex_exec_argv
from .state import AgentState

DEFAULT_TIMEOUT_SEC = 900

MANIFEST_RELATIVE_PATH = Path("config") / "verification-manifest.json"

# Model selection and provider overrides. `--ignore-user-config` is always set
# (see `compile_codex_exec_argv`), so without these the run targets the built-in
# OpenAI endpoint: measured as `401 Unauthorized ... url:
# https://api.openai.com/v1/responses` on a deployment that routes through a
# gateway. They carry no secret -- the credential stays in the environment under
# the name the provider block declares via `env_key`.
CODEX_MODEL_ENV = "AER_CODEX_MODEL"
CODEX_CONFIG_ENV = "AER_CODEX_CONFIG"
CODEX_HOME_ENV = "AER_CODEX_HOME"

PROMPT_TEMPLATE = """You are implementing GitHub issue #{number} in the {repo} repository.

Title: {title}

Issue body:
---
{body}
---

Rules:
- Change only what the issue asks for. Do not refactor unrelated code.
- Add or update tests that fail before your change and pass after it.
- Do not modify any of these protected paths; a human must review changes there,
  and a diff that touches one is rejected before a pull request is opened:
{protected}
- Leave the working tree with your changes applied. Do not commit, do not push,
  and do not open a pull request; the loop does that.
"""


class CodegenError(RuntimeError):
    """Code generation could not produce a reviewable change."""


@dataclass(frozen=True)
class CodegenOutcome:
    changed: bool
    exit_code: int
    events: int
    total_tokens: int
    final_state: str
    reason: str = ""


def load_protected_surface(workdir: str) -> list[str]:
    """Read the protected-surface globs from the repository manifest.

    The manifest is the single source of truth: the same globs decide the
    closure verdict in ``core/aer/closure.py``. Duplicating them here would let
    the two drift.
    """
    path = Path(workdir) / MANIFEST_RELATIVE_PATH
    if not path.is_file():
        raise CodegenError(
            f"cannot enforce the protected surface: {MANIFEST_RELATIVE_PATH} "
            "is missing from the checkout"
        )
    manifest = json.loads(path.read_text(encoding="utf-8"))
    surface = manifest.get("protectedSurface")
    if not isinstance(surface, list) or not surface:
        raise CodegenError(
            f"{MANIFEST_RELATIVE_PATH} declares no protectedSurface; refusing to "
            "run code generation without a surface to enforce"
        )
    return [str(pattern) for pattern in surface]


def _format_protected_surface(protected_surface: Sequence[str]) -> str:
    return "\n".join(f"  - {pattern}" for pattern in protected_surface)


def build_prompt(
    issue: Mapping[str, object],
    *,
    repo: str,
    protected_surface: Sequence[str],
) -> str:
    """Render the deterministic implementation prompt for one issue."""
    number = int(issue.get("number") or 0)
    title = str(issue.get("title") or "").strip()
    body = str(issue.get("body") or "").strip() or "(no body provided)"
    return PROMPT_TEMPLATE.format(
        number=number,
        title=title,
        body=body,
        repo=repo,
        protected=_format_protected_surface(protected_surface),
    )


def changed_paths(workdir: str) -> list[str]:
    """Paths with staged, unstaged, or untracked changes, relative to the root.

    ``-uall`` is load-bearing: without it git collapses an untracked directory
    into a single ``dir/`` entry, which would not match a ``dir/**`` protected
    glob and would let a whole new subtree through unscreened.
    """
    result = subprocess.run(
        ["git", "status", "--porcelain", "-uall"],
        cwd=workdir,
        capture_output=True,
        text=True,
    )
    if result.returncode != 0:
        raise CodegenError(
            f"git status failed ({result.returncode}): {result.stderr.strip()}"
        )
    paths: list[str] = []
    for line in result.stdout.splitlines():
        if len(line) < 4:
            continue
        entry = line[3:].strip()
        # A rename is reported as `old -> new`; the destination is what lands.
        if " -> " in entry:
            entry = entry.split(" -> ", 1)[1]
        paths.append(entry.strip().strip('"'))
    return paths


def workspace_changed(workdir: str) -> bool:
    """True when the working tree has staged, unstaged, or untracked changes."""
    return bool(changed_paths(workdir))


def protected_paths_touched(workdir: str, paths: Sequence[str]) -> list[str]:
    """Changed paths that the manifest marks as protected."""
    from aer.closure import protected_surface_touched

    protected_surface = load_protected_surface(workdir)
    return [path for path in paths if protected_surface_touched([path], protected_surface)]


def _config_overrides_from_env() -> list[str]:
    """Read ``AER_CODEX_CONFIG`` as one ``-c key=value`` override per line.

    Newline-separated rather than comma- or space-separated: a TOML value may
    contain commas and spaces (``base_url = "https://gateway.example/v1"``), so
    any separator that can appear inside a value would split it.
    """
    raw = os.environ.get(CODEX_CONFIG_ENV, "")
    return [line.strip() for line in raw.splitlines() if line.strip()]


def run_codegen(
    issue: Mapping[str, object],
    workdir: str,
    *,
    repo: str,
    timeout_sec: int = DEFAULT_TIMEOUT_SEC,
    codex_home: str | None = None,
    codex_executable: str = "codex",
    model: str | None = None,
    config_overrides: Sequence[str] | None = None,
    env: Mapping[str, str] | None = None,
    popen: Callable[..., subprocess.CompletedProcess] | None = None,
) -> CodegenOutcome:
    """Run code generation in ``workdir`` and report what it produced.

    ``codex_executable`` is the executable to invoke. Callers that check for the
    CLI before starting work pass the path they resolved, so the check and the
    invocation cannot drift apart.

    ``model`` and ``config_overrides`` default to ``AER_CODEX_MODEL`` and
    ``AER_CODEX_CONFIG``; ``codex_home`` defaults to ``AER_CODEX_HOME``. An
    explicit argument wins over the environment. Isolation is applied by setting
    ``CODEX_HOME`` on the child process, which is the CLI's own mechanism --
    there is no ``--codex-home`` flag to pass.

    Raises :class:`CodegenError` when the agent could not run to completion.
    A completed run that produced no workspace change is *not* an error here;
    the caller decides, because "no change" is a policy question, not a
    transport failure.
    """
    prompt = build_prompt(
        issue,
        repo=repo,
        protected_surface=load_protected_surface(workdir),
    )
    isolated_home = codex_home or os.environ.get(CODEX_HOME_ENV) or None
    resolved_model = model if model is not None else os.environ.get(CODEX_MODEL_ENV) or None
    overrides = (
        list(config_overrides) if config_overrides is not None else _config_overrides_from_env()
    )
    argv = compile_codex_exec_argv(
        prompt,
        ephemeral=True,
        ignore_user_config=True,
        # The harness default is read-only, which would make code generation a
        # silent no-op. `workspace-write` is only honoured on Linux/macOS; see
        # the module docstring for the measured Windows behaviour.
        sandbox_mode="workspace-write",
        executable=codex_executable,
        model=resolved_model,
        config_overrides=overrides,
    )

    runner = AgentRunner()
    invoke = popen or subprocess.run
    child_env = {**os.environ, **(env or {})}
    if isolated_home:
        child_env["CODEX_HOME"] = str(isolated_home)
    try:
        completed = invoke(
            argv,
            cwd=workdir,
            capture_output=True,
            text=True,
            timeout=timeout_sec,
            env=child_env,
        )
    except subprocess.TimeoutExpired as exc:
        raise CodegenError(
            f"codegen exceeded {timeout_sec}s without completing: {exc}"
        ) from exc
    except FileNotFoundError as exc:
        raise CodegenError(
            "codex CLI is not installed on this runner; codegen cannot run: "
            f"`{codex_executable}` could not be executed"
        ) from exc

    lines = (completed.stdout or "").splitlines()
    # AgentRunner turns a budget overrun into a NEED_USER_ACTION transition
    # rather than raising, so the state check below is what surfaces it.
    runner.process_event_stream(lines)

    changed = workspace_changed(workdir)
    if changed:
        # The sandbox is writable, so the prompt alone cannot keep the agent out
        # of the protected surface. Reject the diff here rather than opening a
        # pull request that has to be reverted.
        offenders = protected_paths_touched(workdir, changed_paths(workdir))
        if offenders:
            raise CodegenError(
                "codegen touched protected paths that require human review: "
                + ", ".join(sorted(offenders))
            )

    outcome = CodegenOutcome(
        changed=changed,
        exit_code=int(completed.returncode),
        events=len([line for line in lines if line.strip()]),
        total_tokens=runner.budget_tracker.total_tokens,
        final_state=runner.state_machine.state.value,
        reason="" if changed else "agent produced no workspace changes",
    )

    if completed.returncode != 0 and not changed:
        stderr_tail = (completed.stderr or "").strip()[-2000:]
        raise CodegenError(
            f"codegen exited {completed.returncode} with no workspace changes: {stderr_tail}"
        )

    state_machine = runner.state_machine
    if state_machine.state == AgentState.NEED_USER_ACTION:
        reason = state_machine.history[-1]["reason"] if state_machine.history else "unspecified"
        raise CodegenError(f"codegen reached NEED_USER_ACTION: {reason}")

    return outcome
