"""Safe tool invocation layer routed via sandbox isolation."""

from __future__ import annotations

from pathlib import Path
from typing import Any

from ..sandbox.base import SandboxDriver


class AgentTools:
    def __init__(self, sandbox: SandboxDriver, root_dir: Path | str = ".") -> None:
        self.sandbox = sandbox
        self.root_dir = Path(root_dir)

    def read_file(self, rel_path: str) -> str:
        res = self.sandbox.run_command(
            f"python -c \"from pathlib import Path; print(Path('{rel_path}').read_text(encoding='utf-8'))\""
        )
        return res.stdout

    def write_file(self, rel_path: str, content: str) -> None:
        escaped = content.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", "\\n")
        self.sandbox.run_command(
            f"python -c \"from pathlib import Path; Path('{rel_path}').write_text('''{content}''', encoding='utf-8')\""
        )

    def git_status(self) -> str:
        res = self.sandbox.run_command("git status --porcelain")
        return res.stdout.strip()

    def git_diff(self) -> str:
        res = self.sandbox.run_command("git diff")
        return res.stdout

    def run_gate(self, command: str) -> dict[str, Any]:
        res = self.sandbox.run_command(command)
        return {
            "exitCode": res.exit_code,
            "stdout": res.stdout,
            "stderr": res.stderr,
            "timedOut": res.timed_out,
        }
