"""Event streaming parser for Codex / agent exec events."""

from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass, field
from typing import Any


@dataclass(frozen=True)
class Observation:
    tool: str
    exit_code: int
    output_digest: str
    raw_output: str = ""

    def to_dict(self) -> dict[str, Any]:
        return {
            "tool": self.tool,
            "exitCode": self.exit_code,
            "outputDigest": self.output_digest,
            "rawOutput": self.raw_output,
        }


@dataclass(frozen=True)
class TokenUsage:
    prompt_tokens: int = 0
    completion_tokens: int = 0
    cached_tokens: int = 0
    total_tokens: int = 0

    def to_dict(self) -> dict[str, int]:
        return {
            "promptTokens": self.prompt_tokens,
            "completionTokens": self.completion_tokens,
            "cachedTokens": self.cached_tokens,
            "totalTokens": self.total_tokens,
        }


@dataclass
class AgentEvent:
    event_type: str
    payload: dict[str, Any] = field(default_factory=dict)
    observation: Observation | None = None
    usage: TokenUsage | None = None


def parse_event_line(line: str) -> AgentEvent:
    text = line.strip()
    if not text:
        return AgentEvent(event_type="empty")
    try:
        data = json.loads(text)
    except json.JSONDecodeError:
        return AgentEvent(event_type="unparseable", payload={"raw": text})

    if not isinstance(data, dict):
        return AgentEvent(event_type="unknown", payload={"raw": data})

    event_type = str(data.get("type") or data.get("event") or "unknown")

    observation = None
    if event_type == "command_execution" or "command_execution" in data:
        sub = data.get("command_execution") or data
        tool = str(sub.get("tool") or sub.get("command") or "exec")
        exit_code = int(sub.get("exit_code") or sub.get("exitCode") or 0)
        output = str(sub.get("output") or sub.get("stdout") or "")
        digest = "sha256:" + hashlib.sha256(output.encode("utf-8")).hexdigest()
        observation = Observation(
            tool=tool,
            exit_code=exit_code,
            output_digest=digest,
            raw_output=output,
        )

    usage = None
    if "usage" in data and isinstance(data["usage"], dict):
        u = data["usage"]
        usage = TokenUsage(
            prompt_tokens=int(u.get("prompt_tokens") or u.get("input_tokens") or 0),
            completion_tokens=int(u.get("completion_tokens") or u.get("output_tokens") or 0),
            cached_tokens=int(u.get("cached_tokens") or 0),
            total_tokens=int(u.get("total_tokens") or 0),
        )

    return AgentEvent(
        event_type=event_type,
        payload=data,
        observation=observation,
        usage=usage,
    )
