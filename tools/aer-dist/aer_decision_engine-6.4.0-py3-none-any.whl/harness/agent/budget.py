"""Step-level and session-level token budget enforcement."""

from __future__ import annotations

from dataclasses import dataclass
from .events import TokenUsage


class BudgetExceededError(RuntimeError):
    pass


@dataclass
class AgentBudgetTracker:
    step_token_limit: int = 100_000
    session_token_limit: int = 1_000_000
    total_prompt_tokens: int = 0
    total_completion_tokens: int = 0
    total_tokens: int = 0

    def record_usage(self, usage: TokenUsage) -> None:
        step_total = usage.total_tokens or (usage.prompt_tokens + usage.completion_tokens)
        if step_total > self.step_token_limit:
            raise BudgetExceededError(
                f"Step token limit exceeded: observed {step_total} > limit {self.step_token_limit}"
            )

        self.total_prompt_tokens += usage.prompt_tokens
        self.total_completion_tokens += usage.completion_tokens
        self.total_tokens += step_total

        if self.total_tokens > self.session_token_limit:
            raise BudgetExceededError(
                f"Session token limit exceeded: total {self.total_tokens} > limit {self.session_token_limit}"
            )
