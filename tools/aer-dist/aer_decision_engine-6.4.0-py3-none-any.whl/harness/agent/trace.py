"""Append-only tamper-evident hash chain trace."""

from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any

GENESIS_HASH = "0" * 64


class TraceTamperError(ValueError):
    pass


@dataclass
class TraceEntry:
    index: int
    timestamp: str
    event_type: str
    prev_hash: str
    entry_hash: str
    payload: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {
            "index": self.index,
            "timestamp": self.timestamp,
            "eventType": self.event_type,
            "prevHash": self.prev_hash,
            "entryHash": self.entry_hash,
            "payload": self.payload,
        }


def _hash_entry(index: int, timestamp: str, event_type: str, prev_hash: str, payload: dict) -> str:
    serialized = json.dumps(payload, sort_keys=True, ensure_ascii=False)
    raw = f"{index}|{timestamp}|{event_type}|{prev_hash}|{serialized}"
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


class AgentTraceChain:
    def __init__(self) -> None:
        self.entries: list[TraceEntry] = []

    @property
    def latest_hash(self) -> str:
        return self.entries[-1].entry_hash if self.entries else GENESIS_HASH

    def append(self, event_type: str, payload: dict[str, Any] | None = None) -> TraceEntry:
        index = len(self.entries)
        timestamp = datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")
        prev = self.latest_hash
        p = payload or {}
        digest = _hash_entry(index, timestamp, event_type, prev, p)
        entry = TraceEntry(
            index=index,
            timestamp=timestamp,
            event_type=event_type,
            prev_hash=prev,
            entry_hash=digest,
            payload=p,
        )
        self.entries.append(entry)
        return entry

    def verify(self) -> bool:
        expected_prev = GENESIS_HASH
        for entry in self.entries:
            if entry.prev_hash != expected_prev:
                raise TraceTamperError(
                    f"Hash chain broken at index {entry.index}: prev_hash mismatch ({entry.prev_hash} != {expected_prev})"
                )
            recomputed = _hash_entry(entry.index, entry.timestamp, entry.event_type, entry.prev_hash, entry.payload)
            if recomputed != entry.entry_hash:
                raise TraceTamperError(
                    f"Entry hash mismatch at index {entry.index}: recomputed {recomputed} != recorded {entry.entry_hash}"
                )
            expected_prev = entry.entry_hash
        return True

    def to_dict(self) -> dict[str, Any]:
        self.verify()
        return {
            "version": "agent-trace/v1",
            "entries": [e.to_dict() for e in self.entries],
            "chainDigest": self.latest_hash,
        }
