"""Finite state machine for agent execution cycles with explicit transitions."""

from __future__ import annotations

from datetime import datetime, timezone
from enum import Enum
from typing import Any


class AgentState(str, Enum):
    DISCOVER = "DISCOVER"
    PLAN = "PLAN"
    RED = "RED"
    GREEN = "GREEN"
    VERIFY = "VERIFY"
    PR = "PR"
    DONE = "DONE"
    BLOCKED = "BLOCKED"
    NEED_USER_ACTION = "NEED_USER_ACTION"


VALID_TRANSITIONS: dict[AgentState, set[AgentState]] = {
    AgentState.DISCOVER: {AgentState.PLAN, AgentState.BLOCKED, AgentState.NEED_USER_ACTION},
    AgentState.PLAN: {AgentState.RED, AgentState.GREEN, AgentState.BLOCKED, AgentState.NEED_USER_ACTION},
    AgentState.RED: {AgentState.GREEN, AgentState.BLOCKED, AgentState.NEED_USER_ACTION},
    AgentState.GREEN: {AgentState.VERIFY, AgentState.BLOCKED, AgentState.NEED_USER_ACTION},
    AgentState.VERIFY: {AgentState.PR, AgentState.RED, AgentState.BLOCKED, AgentState.NEED_USER_ACTION},
    AgentState.PR: {AgentState.DONE, AgentState.VERIFY, AgentState.BLOCKED, AgentState.NEED_USER_ACTION},
    AgentState.DONE: set(),
    AgentState.BLOCKED: {AgentState.PLAN, AgentState.DISCOVER, AgentState.NEED_USER_ACTION},
    AgentState.NEED_USER_ACTION: {AgentState.DISCOVER, AgentState.PLAN},
}


class InvalidStateTransitionError(ValueError):
    pass


class AgentStateMachine:
    def __init__(self, initial_state: AgentState = AgentState.DISCOVER, epoch: int = 1) -> None:
        self.state = initial_state
        self.epoch = epoch
        self.history: list[dict[str, str]] = []

    def transition(self, next_state: AgentState, *, reason: str = "") -> None:
        allowed = VALID_TRANSITIONS.get(self.state, set())
        if next_state not in allowed:
            raise InvalidStateTransitionError(
                f"Illegal transition from {self.state.value} to {next_state.value}. Allowed: {[s.value for s in allowed]}"
            )
        now = datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")
        self.history.append({
            "fromState": self.state.value,
            "toState": next_state.value,
            "timestamp": now,
            "reason": reason,
        })
        self.state = next_state

    def to_dict(self) -> dict[str, Any]:
        return {
            "state": self.state.value,
            "epoch": self.epoch,
            "history": list(self.history),
        }
