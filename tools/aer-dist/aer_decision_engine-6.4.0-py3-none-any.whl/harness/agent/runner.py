"""Runner compiling to codex exec with ephemeral isolation and event streaming."""

from __future__ import annotations

import os
import subprocess
from typing import Iterator, Sequence

from .events import AgentEvent, parse_event_line
from .state import AgentStateMachine, AgentState
from .trace import AgentTraceChain
from .budget import AgentBudgetTracker, BudgetExceededError


def compile_codex_exec_argv(
    prompt: str,
    *,
    ephemeral: bool = True,
    ignore_user_config: bool = True,
    sandbox_mode: str = "read-only",
    executable: str = "codex",
    model: str | None = None,
    config_overrides: Sequence[str] = (),
) -> list[str]:
    """Compile the `codex exec` command line.

    ``executable`` lets a caller pass the path it already resolved (for example
    a preflight check) instead of relying on a second PATH lookup at spawn time.

    The prompt is a **positional** argument. It used to be passed as
    ``-p <prompt>``, but in codex-cli 0.154.0 ``-p`` is ``--profile``: the
    prompt was rejected as an invalid profile name and no prompt reached the
    model at all (measured: ``invalid --profile value``, exit code 2, no
    output). Every flag therefore precedes the prompt.

    ``--ignore-user-config`` means ``$CODEX_HOME/config.toml`` is not read, so
    nothing that selects a provider or a model can come from the machine's
    configuration: ``model`` becomes ``-m`` and each entry of
    ``config_overrides`` becomes a ``-c key=value``. Without them the run falls
    back to the built-in OpenAI endpoint, which is not what a deployment with a
    custom gateway wants.

    There is deliberately no ``--codex-home`` flag to compile. The CLI has no
    such option -- ``codex exec --codex-home <dir>`` fails with ``error:
    unexpected argument '--codex-home' found``, exit code 2 -- so a caller that
    wanted an isolated home directory got a codegen run that never started. The
    documented mechanism is the ``CODEX_HOME`` environment variable, which the
    caller sets on the child process; ``--ignore-user-config`` skips the
    ``config.toml`` inside it but still resolves auth through it.
    """
    argv = [executable, "exec", "--json"]
    if ephemeral:
        argv.append("--ephemeral")
    if ignore_user_config:
        argv.append("--ignore-user-config")
    if sandbox_mode:
        argv.extend(["--sandbox", sandbox_mode])
    if model:
        argv.extend(["-m", model])
    for override in config_overrides:
        argv.extend(["-c", override])
    argv.append(prompt)
    return argv


class AgentRunner:
    def __init__(
        self,
        state_machine: AgentStateMachine | None = None,
        trace_chain: AgentTraceChain | None = None,
        budget_tracker: AgentBudgetTracker | None = None,
    ) -> None:
        self.state_machine = state_machine or AgentStateMachine()
        self.trace_chain = trace_chain or AgentTraceChain()
        self.budget_tracker = budget_tracker or AgentBudgetTracker()

    def process_event_stream(self, event_lines: Iterator[str] | list[str]) -> None:
        for line in event_lines:
            event = parse_event_line(line)
            self.trace_chain.append(event.event_type, event.payload)

            if event.usage:
                try:
                    self.budget_tracker.record_usage(event.usage)
                except BudgetExceededError as exc:
                    self.state_machine.transition(
                        AgentState.NEED_USER_ACTION,
                        reason=f"Budget exceeded: {exc}",
                    )
                    break

            if event.observation:
                # Direct exit code checking
                if event.observation.exit_code != 0:
                    if self.state_machine.state == AgentState.VERIFY:
                        self.state_machine.transition(
                            AgentState.RED,
                            reason=f"Gate failed with exit code {event.observation.exit_code}",
                        )
