"""Append-only Merkle log with inclusion proofs."""

from __future__ import annotations

import hashlib
from typing import Sequence


def _sha256_hex(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


class MerkleLog:
    """Append-only Merkle tree log producing verifiable inclusion proofs."""

    def __init__(self, entries: list[bytes] | None = None) -> None:
        self.entries: list[bytes] = list(entries or [])

    def append(self, entry: bytes) -> int:
        idx = len(self.entries)
        self.entries.append(entry)
        return idx

    @property
    def root_hash(self) -> str:
        if not self.entries:
            return _sha256_hex(b"")
        hashes = [_sha256_hex(b"\x00" + e) for e in self.entries]
        while len(hashes) > 1:
            next_level = []
            for i in range(0, len(hashes), 2):
                if i + 1 < len(hashes):
                    combined = _sha256_hex(b"\x01" + bytes.fromhex(hashes[i]) + bytes.fromhex(hashes[i + 1]))
                else:
                    combined = hashes[i]
                next_level.append(combined)
            hashes = next_level
        return hashes[0]

    def get_inclusion_proof(self, index: int) -> list[tuple[str, str]]:
        """Produce audit path for entry at index: list of (direction, hash)."""
        if index < 0 or index >= len(self.entries):
            raise IndexError("Index out of bounds for Merkle log")

        proof: list[tuple[str, str]] = []
        hashes = [_sha256_hex(b"\x00" + e) for e in self.entries]
        curr_idx = index

        while len(hashes) > 1:
            next_level = []
            for i in range(0, len(hashes), 2):
                if i + 1 < len(hashes):
                    if i == curr_idx:
                        proof.append(("right", hashes[i + 1]))
                    elif i + 1 == curr_idx:
                        proof.append(("left", hashes[i]))
                    combined = _sha256_hex(b"\x01" + bytes.fromhex(hashes[i]) + bytes.fromhex(hashes[i + 1]))
                else:
                    combined = hashes[i]
                next_level.append(combined)
            curr_idx //= 2
            hashes = next_level

        return proof

    @staticmethod
    def verify_inclusion(entry: bytes, proof: list[tuple[str, str]], expected_root: str) -> bool:
        """Verify inclusion proof mathematically against expected root."""
        curr = _sha256_hex(b"\x00" + entry)
        for direction, sibling in proof:
            if direction == "right":
                curr = _sha256_hex(b"\x01" + bytes.fromhex(curr) + bytes.fromhex(sibling))
            else:
                curr = _sha256_hex(b"\x01" + bytes.fromhex(sibling) + bytes.fromhex(curr))
        return curr == expected_root
