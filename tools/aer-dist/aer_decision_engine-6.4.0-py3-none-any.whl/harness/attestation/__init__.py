"""Platform attestation and DSSE envelope layer."""
