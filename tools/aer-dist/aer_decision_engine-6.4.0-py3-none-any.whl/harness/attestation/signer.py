"""Signer and Verifier interfaces supporting HMAC and dev-only Ed25519."""

from __future__ import annotations

import base64
import hashlib
import hmac
from typing import Any

from .dsse import pre_authentication_encoding


class SignatureVerificationError(Exception):
    """Raised when an attestation signature fails cryptographic verification."""


class AttestationSigner:
    """Creates DSSE signatures. Supports HMAC-SHA256 and dev-only local key."""

    def __init__(self, key_bytes: bytes, key_id: str = "dev-key-1", algorithm: str = "hmac-sha256") -> None:
        self.key_bytes = key_bytes
        self.key_id = key_id
        self.algorithm = algorithm

    def sign_pae(self, pae_bytes: bytes) -> dict[str, str]:
        """Sign PAE payload and return signature dict."""
        if self.algorithm == "hmac-sha256":
            sig = hmac.new(self.key_bytes, pae_bytes, hashlib.sha256).digest()
            sig_b64 = base64.b64encode(sig).decode("ascii")
            return {
                "keyid": self.key_id,
                "sig": sig_b64,
                "attestationPosture": "dev-only-local",
            }
        raise NotImplementedError(f"Unsupported algorithm: {self.algorithm}")


class AttestationVerifier:
    """Verifies DSSE signatures and binding to candidate commit SHA."""

    def __init__(self, key_bytes: bytes, key_id: str = "dev-key-1", algorithm: str = "hmac-sha256") -> None:
        self.key_bytes = key_bytes
        self.key_id = key_id
        self.algorithm = algorithm

    def verify_envelope(self, envelope: dict[str, Any], expected_commit_sha: str = "") -> bool:
        payload_type = envelope.get("payloadType", "")
        payload_b64 = envelope.get("payload", "")
        signatures = envelope.get("signatures", [])
        if not payload_b64 or not signatures:
            raise SignatureVerificationError("Malformed envelope: missing payload or signatures")

        payload_bytes = base64.b64decode(payload_b64.encode("ascii"))
        pae = pre_authentication_encoding(payload_type, payload_bytes)

        # Check cryptographic signature
        valid_any = False
        for s in signatures:
            sig_raw = base64.b64decode(s.get("sig", "").encode("ascii"))
            expected_sig = hmac.new(self.key_bytes, pae, hashlib.sha256).digest()
            if not hmac.compare_digest(sig_raw, expected_sig):
                raise SignatureVerificationError("Signature tamper detected: signature does not match PAE payload")
            valid_any = True

        if not valid_any:
            raise SignatureVerificationError("Zero valid signatures verified")

        # Check candidate binding
        if expected_commit_sha:
            import json
            statement = json.loads(payload_bytes.decode("utf-8"))
            subjects = statement.get("subject", [])
            matches_commit = any(
                s.get("digest", {}).get("sha256") == expected_commit_sha.strip().lower()
                for s in subjects
            )
            if not matches_commit:
                raise SignatureVerificationError(f"Attestation subject does not bind to candidate SHA: {expected_commit_sha}")

        return True
