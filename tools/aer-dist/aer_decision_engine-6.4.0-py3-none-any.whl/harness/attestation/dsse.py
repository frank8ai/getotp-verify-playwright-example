"""DSSE envelope and canonical in-toto Statement v1 builder."""

from __future__ import annotations

import base64
import hashlib
import json
from typing import Any

IN_TOTO_STATEMENT_TYPE = "https://in-toto.io/Statement/v1"
AER_PREDICATE_TYPE = "https://aer.dev/verification-evidence/v2"


def canonical_json_bytes(obj: Any) -> bytes:
    """Serialize object to deterministic canonical JSON with sorted keys."""
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=True).encode("utf-8")


def create_in_toto_statement(
    commit_sha: str,
    tree_hash: str,
    predicate: dict[str, Any],
) -> dict[str, Any]:
    """Create in-toto statement v1 byte-reproducible payload."""
    clean_commit = commit_sha.strip().lower()
    clean_tree = tree_hash.strip().lower()
    return {
        "_type": IN_TOTO_STATEMENT_TYPE,
        "subject": [
            {
                "name": f"commit:{clean_commit}",
                "digest": {"sha256": clean_commit},
            },
            {
                "name": f"tree:{clean_tree}",
                "digest": {"sha256": clean_tree},
            },
        ],
        "predicateType": AER_PREDICATE_TYPE,
        "predicate": predicate,
    }


def wrap_dsse_envelope(
    payload_type: str,
    payload_bytes: bytes,
    signatures: list[dict[str, str]] | None = None,
) -> dict[str, Any]:
    """Wrap canonical payload in standard DSSE envelope (Dead Simple Signing Envelope)."""
    return {
        "payloadType": payload_type,
        "payload": base64.b64encode(payload_bytes).decode("ascii"),
        "signatures": signatures or [],
    }


def pre_authentication_encoding(payload_type: str, payload_bytes: bytes) -> bytes:
    """Compute PAE (Pre-Authentication Encoding) according to DSSE specification:

    PAE(type, body) = "DSSEv1" + " " + len(type) + " " + type + " " + len(body) + " " + body
    """
    type_bytes = payload_type.encode("utf-8")
    header = f"DSSEv1 {len(type_bytes)} ".encode("ascii")
    body_header = f" {len(payload_bytes)} ".encode("ascii")
    return header + type_bytes + body_header + payload_bytes
