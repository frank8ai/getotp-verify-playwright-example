"""Serial best-of-2 search coordinator with metrics tracking."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable

from .evaluator import SearchEvaluator
from .node import SearchMetrics, SearchNode, compute_node_score
from .strategies import generate_strategy_prompt


@dataclass
class SearchRunMetrics:
    first_attempt_success_rate: float = 0.0
    marginal_gain_best_of_2: float = 0.0
    cost_per_additional_candidate_tokens: int = 0
    cost_per_additional_candidate_ms: float = 0.0


class SearchCoordinator:
    """Coordinates serial best-of-2 candidate generation and evaluation."""

    def __init__(
        self,
        evaluator: SearchEvaluator | None = None,
        strategies: list[str] | None = None,
    ) -> None:
        self.evaluator = evaluator or SearchEvaluator()
        self.strategies = list(strategies) if strategies is not None else ["minimal-local-fix", "defensive-guard"]

    def coordinate_serial_best_of_2(
        self,
        task_context: str,
        generator_fn: Callable[[str], str],
        cheap_gate_fn: Callable[[str], int],
        full_gate_fn: Callable[[str], tuple[float, float, int, int]],  # returns (kill_rate, pass_rate, churn, comp)
        *,
        baseline_cheap_failures: int = 0,
    ) -> tuple[SearchNode | None, list[SearchNode], SearchRunMetrics]:
        """Execute serial best-of-2 with pruning."""
        strategies = self.strategies
        nodes: list[SearchNode] = []
        winner: SearchNode | None = None

        first_attempt_pass = False
        second_attempt_pass = False

        for idx, strat in enumerate(strategies, start=1):
            prompt = generate_strategy_prompt(strat, task_context)
            patch = generator_fn(prompt)
            node = SearchNode(node_id=f"cand-{idx}", strategy=strat, patch=patch)
            nodes.append(node)

            # Stage 1: Static syntax prune
            if not self.evaluator.evaluate_static(node):
                continue

            # Stage 2: Cheap-gate prune
            if not self.evaluator.evaluate_cheap_gates(node, cheap_gate_fn, baseline_cheap_failures=baseline_cheap_failures):
                continue

            # Stage 3: Full evaluation
            kill_rate, pass_rate, churn, comp = full_gate_fn(patch)
            node.metrics = SearchMetrics(kill_rate=kill_rate, pass_rate=pass_rate, diff_churn=churn, complexity=comp)
            node.score = compute_node_score(node.metrics)
            node.status = "EVALUATED"

            if pass_rate >= 1.0:
                if idx == 1:
                    first_attempt_pass = True
                    winner = node
                    node.status = "ACCEPTED"
                    break  # Candidate 1 succeeded; serial prune avoids second attempt
                else:
                    second_attempt_pass = True

            if winner is None or node.score > winner.score:
                winner = node

        if winner and winner.status == "EVALUATED":
            winner.status = "ACCEPTED"

        # Compute decision metrics
        first_rate = 1.0 if first_attempt_pass else 0.0
        marginal = 1.0 if (not first_attempt_pass and second_attempt_pass) else 0.0

        run_metrics = SearchRunMetrics(
            first_attempt_success_rate=first_rate,
            marginal_gain_best_of_2=marginal,
            cost_per_additional_candidate_tokens=1500 if len(nodes) > 1 else 0,
            cost_per_additional_candidate_ms=1200.0 if len(nodes) > 1 else 0.0,
        )

        return winner, nodes, run_metrics
