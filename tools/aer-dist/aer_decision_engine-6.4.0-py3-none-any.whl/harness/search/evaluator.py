"""Prune-first static and gate evaluator."""

from __future__ import annotations

import ast
from typing import Any, Callable

from .node import SearchMetrics, SearchNode, compute_node_score


class SearchEvaluator:
    """Evaluates candidates using prune-first checks."""

    def evaluate_static(self, node: SearchNode) -> bool:
        """Stage 1: Syntax & AST parsing check. Prunes immediately on failure without I/O."""
        if not node.patch or not node.patch.strip():
            node.status = "PRUNED_SYNTAX"
            node.prune_reason = "Empty patch"
            return False

        try:
            ast.parse(node.patch)
            return True
        except SyntaxError as e:
            node.status = "PRUNED_SYNTAX"
            node.prune_reason = f"Syntax error in candidate patch: {e}"
            return False

    def evaluate_cheap_gates(
        self,
        node: SearchNode,
        cheap_gate_runner: Callable[[str], int],
        *,
        baseline_cheap_failures: int = 0,
    ) -> bool:
        """Stage 2: Cheap gates. If failure count exceeds baseline, prune before running full gates."""
        failures = cheap_gate_runner(node.patch)
        if failures > baseline_cheap_failures:
            node.status = "PRUNED_CHEAP_GATE"
            node.prune_reason = f"Cheap gate failures ({failures}) exceed baseline ({baseline_cheap_failures})"
            return False
        return True
