"""SearchNode definition and pure value scoring function."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass
class SearchMetrics:
    kill_rate: float = 0.0
    pass_rate: float = 0.0
    diff_churn: int = 0
    complexity: int = 0

    def to_dict(self) -> dict[str, Any]:
        return {
            "killRate": self.kill_rate,
            "passRate": self.pass_rate,
            "diffChurn": self.diff_churn,
            "complexity": self.complexity,
        }


def compute_node_score(
    metrics: SearchMetrics,
    *,
    w_kill: float = 1.0,
    w_pass: float = 2.0,
    w_churn: float = 0.01,
    w_comp: float = 0.02,
) -> float:
    """Pure scoring function: score = w1*killRate + w2*passRate - w3*diffChurn - w4*complexity."""
    return (
        w_kill * metrics.kill_rate
        + w_pass * metrics.pass_rate
        - w_churn * float(metrics.diff_churn)
        - w_comp * float(metrics.complexity)
    )


@dataclass
class SearchNode:
    node_id: str
    strategy: str
    patch: str
    status: str = "PENDING"  # PENDING, PRUNED_SYNTAX, PRUNED_CHEAP_GATE, EVALUATED, ACCEPTED
    score: float = 0.0
    prune_reason: str = ""
    parent_id: str = ""
    metrics: SearchMetrics = field(default_factory=SearchMetrics)

    def to_dict(self) -> dict[str, Any]:
        d = {
            "nodeId": self.node_id,
            "strategy": self.strategy,
            "patch": self.patch,
            "status": self.status,
            "score": self.score,
            "metrics": self.metrics.to_dict(),
        }
        if self.parent_id:
            d["parentId"] = self.parent_id
        if self.prune_reason:
            d["pruneReason"] = self.prune_reason
        return d
