"""Differentiated repair prompt strategies."""

from __future__ import annotations

import hashlib


def generate_strategy_prompt(strategy: str, task_context: str) -> str:
    """Generate distinct strategy prompts with unique guidance."""
    if strategy == "minimal-local-fix":
        body = (
            "STRATEGY: MINIMAL_LOCAL_FIX\n"
            "Directive: Identify the exact line or block causing the fault and make the smallest possible change. "
            "Do not add defensive checks or refactor surrounding logic. Keep diff churn as close to 0 as possible."
        )
    elif strategy == "defensive-guard":
        body = (
            "STRATEGY: DEFENSIVE_GUARD\n"
            "Directive: Wrap the failure condition with explicit defensive guards, parameter validation, or early returns. "
            "Ensure edge cases, null values, and out-of-range inputs fail gracefully before entering core logic."
        )
    elif strategy == "root-cause-refactor":
        body = (
            "STRATEGY: ROOT_CAUSE_REFACTOR\n"
            "Directive: Fix the foundational semantic issue in the data flow or algorithm. "
            "Restructure the function or component cleanly so the fault becomes structurally impossible."
        )
    else:
        body = f"STRATEGY: DEFAULT\nDirective: Repair failure.\n{strategy}"

    return f"{body}\n\nTASK_CONTEXT:\n{task_context.strip()}\n"


def strategy_fingerprint(prompt: str) -> str:
    digest = hashlib.sha256(prompt.strip().encode("utf-8")).hexdigest()
    return f"sha256:{digest[:16]}"
