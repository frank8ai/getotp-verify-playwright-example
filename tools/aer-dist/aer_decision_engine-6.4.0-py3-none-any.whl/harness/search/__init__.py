"""Candidate search and pruning package."""
