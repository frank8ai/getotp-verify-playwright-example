"""Execution tracer probe capturing failure frame stack and repository execution trace."""

from __future__ import annotations

import linecache
import os
import sys
import traceback
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable


@dataclass
class CapturedFrame:
    file: str
    line: int
    function: str
    code: str
    locals_map: dict[str, str] = field(default_factory=dict)


@dataclass
class TraceResult:
    success: bool
    exception_type: str = ""
    exception_message: str = ""
    failure_frames: list[CapturedFrame] = field(default_factory=list)
    # Tracing overhead relative to an untraced baseline, or ``None`` when it was
    # not measured. A single traced run cannot know what the callable would have
    # cost without tracing, so the probe does not guess: only a caller holding a
    # baseline populates this. ``None`` keeps the field out of the slice rather
    # than writing an unmeasured number into evidence.
    overhead_ratio: float | None = None
    fallback_used: bool = False
    error: str = ""


def _is_repo_path(path_str: str, repo_root: Path) -> bool:
    if not path_str or "<" in path_str:
        return False
    norm = path_str.replace("\\", "/")
    if "site-packages" in norm or "/.venv/" in norm or "/venv/" in norm:
        return False
    try:
        p = Path(path_str).resolve()
        return repo_root in p.parents or p == repo_root
    except Exception:
        return False


class TraceProbe:
    """Trace probe wrapping execution and capturing failure point frames."""

    def __init__(self, repo_dir: Path | str | None = None) -> None:
        self.repo_root = Path(repo_dir or ".").resolve()

    def trace_call(self, target: Callable[..., Any], *args: Any, **kwargs: Any) -> tuple[Any, TraceResult]:
        """Execute callable with tracing, capturing failure frames.

        The returned ``overhead_ratio`` is always ``None``: see ``TraceResult``.
        """
        captured_frames: list[CapturedFrame] = []
        exc_type_name = ""
        exc_msg = ""
        fallback = False
        target_ret = None
        success = True

        def _trace(frame: Any, event: str, arg: Any) -> Any:
            nonlocal captured_frames, exc_type_name, exc_msg
            if event == "exception":
                exc_type, exc_val, tb = arg
                exc_type_name = getattr(exc_type, "__name__", str(exc_type))
                exc_msg = str(exc_val)
                # Capture frame stack
                cur = frame
                stack = []
                while cur is not None:
                    code_obj = cur.f_code
                    filename = code_obj.co_filename
                    if _is_repo_path(filename, self.repo_root):
                        lineno = cur.f_lineno
                        line_text = linecache.getline(filename, lineno).strip()
                        # Safe string representation of locals
                        safe_locals = {}
                        for k, v in cur.f_locals.items():
                            if not k.startswith("__"):
                                try:
                                    safe_locals[k] = repr(v)[:100]
                                except Exception:
                                    safe_locals[k] = "<unprintable>"
                        stack.append(
                            CapturedFrame(
                                file=str(Path(filename).relative_to(self.repo_root)).replace("\\", "/"),
                                line=lineno,
                                function=code_obj.co_name,
                                code=line_text,
                                locals_map=safe_locals,
                            )
                        )
                    cur = cur.f_back
                if stack:
                    captured_frames = list(reversed(stack))
            return _trace

        old_trace = sys.gettrace()
        try:
            sys.settrace(_trace)
            target_ret = target(*args, **kwargs)
        except Exception as e:
            success = False
            if not exc_type_name:
                exc_type_name = type(e).__name__
                exc_msg = str(e)
            if not captured_frames:
                # Fallback to standard traceback inspection
                fallback = True
                tb = e.__traceback__
                for frame_summary in traceback.extract_tb(tb):
                    if _is_repo_path(frame_summary.filename, self.repo_root):
                        captured_frames.append(
                            CapturedFrame(
                                file=str(Path(frame_summary.filename).relative_to(self.repo_root)).replace("\\", "/"),
                                line=frame_summary.lineno,
                                function=frame_summary.name,
                                code=frame_summary.line,
                                locals_map={},
                            )
                        )
        finally:
            sys.settrace(old_trace)

        return target_ret, TraceResult(
            success=success,
            exception_type=exc_type_name,
            exception_message=exc_msg,
            failure_frames=captured_frames,
            fallback_used=fallback,
        )
