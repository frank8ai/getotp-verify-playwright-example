"""Backward slice extractor: walks from failure anchor backwards to produce compact causal facts."""

from __future__ import annotations

import ast
import linecache
import re
from pathlib import Path
from typing import Any

from .tracer import CapturedFrame, TraceResult


def _overhead_field(trace: TraceResult) -> dict[str, Any]:
    """``overheadRatio`` only when the tracer actually measured it.

    ``overheadRatio`` is optional in causal-slice/v1. Emitting a placeholder --
    the probe used to write a constant 0.05 on success and 0.12 on failure --
    puts a number nothing measured into the slice evidence, where it reads like a
    measurement and would be believed by anything downstream that budgets on it.
    """
    if trace.overhead_ratio is None:
        return {}
    return {"overheadRatio": trace.overhead_ratio}


class BackwardSliceExtractor:
    """Extracts a backward causal execution slice from captured failure frames."""

    def __init__(self, repo_dir: Path | str | None = None) -> None:
        self.repo_root = Path(repo_dir or ".").resolve()

    def extract_slice(self, trace: TraceResult) -> dict[str, Any]:
        """Produce a causal slice conforming to causal-slice/v1 schema."""
        if not trace.failure_frames:
            # Fallback when no frames were captured
            return {
                "schemaVersion": "causal-slice/v1",
                "failureAnchor": {
                    "file": "unknown",
                    "line": 0,
                    "function": "unknown",
                    "exceptionType": trace.exception_type or "UnknownError",
                    "exceptionMessage": trace.exception_message or "",
                },
                "rootCauseExpr": trace.exception_message or "Unknown failure",
                "causalChain": [],
                "localState": {},
                "sliceLinesCount": 1,
                **_overhead_field(trace),
                "fallbackUsed": True,
            }

        anchor_frame = trace.failure_frames[-1]
        anchor_file = anchor_frame.file
        anchor_line = anchor_frame.line
        anchor_code = anchor_frame.code
        anchor_func = anchor_frame.function

        # Extract variable names involved in the failure anchor line
        relevant_vars: set[str] = set()
        tokens = re.findall(r"\b[a-zA-Z_][a-zA-Z0-9_]*\b", anchor_code)
        py_keywords = {"assert", "if", "in", "is", "not", "and", "or", "return", "def", "self", "True", "False", "None"}
        for t in tokens:
            if t not in py_keywords:
                relevant_vars.add(t)

        causal_chain: list[dict[str, Any]] = []
        target_path = self.repo_root / anchor_file
        file_lines: list[str] = []
        if target_path.is_file():
            try:
                file_lines = target_path.read_text(encoding="utf-8").splitlines()
            except Exception:
                file_lines = []

        # Backward slice: scan previous lines within the same function
        start_scan_line = max(1, anchor_line - 50)
        scanned_lines = file_lines[start_scan_line - 1 : anchor_line - 1]

        for offset, raw_line in enumerate(scanned_lines):
            curr_lineno = start_scan_line + offset
            stripped = raw_line.strip()
            if not stripped or stripped.startswith("#"):
                continue

            # Check if this line assigns or modifies one of our relevant vars
            matched_var = ""
            role = "call"
            for var in list(relevant_vars):
                if re.search(rf"\b{re.escape(var)}\s*=", stripped):
                    matched_var = var
                    role = "assignment"
                    break
                elif re.search(rf"\bif\b.*\b{re.escape(var)}\b", stripped):
                    matched_var = var
                    role = "branch"
                    break

            if matched_var:
                # Add new variables from the right-hand side of assignment
                rhs_tokens = re.findall(r"\b[a-zA-Z_][a-zA-Z0-9_]*\b", stripped)
                for rt in rhs_tokens:
                    if rt not in py_keywords:
                        relevant_vars.add(rt)

                causal_chain.append({
                    "file": anchor_file,
                    "line": curr_lineno,
                    "code": stripped,
                    "role": role,
                    "variable": matched_var,
                })

        # Add the failure anchor itself
        causal_chain.append({
            "file": anchor_file,
            "line": anchor_line,
            "code": anchor_code,
            "role": "assertion" if "assert" in anchor_code else "call",
            "variable": sorted(relevant_vars)[0] if relevant_vars else "",
        })

        # Filter localState to only keep relevant variables
        filtered_locals = {}
        for k, v in anchor_frame.locals_map.items():
            if k in relevant_vars:
                filtered_locals[k] = v

        total_lines = len(causal_chain) + len(filtered_locals) + 3

        return {
            "schemaVersion": "causal-slice/v1",
            "failureAnchor": {
                "file": anchor_file,
                "line": anchor_line,
                "function": anchor_func,
                "exceptionType": trace.exception_type or "AssertionError",
                "exceptionMessage": trace.exception_message or "",
            },
            "rootCauseExpr": anchor_code or trace.exception_message,
            "causalChain": causal_chain,
            "localState": filtered_locals,
            "sliceLinesCount": total_lines,
            **_overhead_field(trace),
            "fallbackUsed": trace.fallback_used,
        }

    def render_markdown(self, slice_data: dict[str, Any]) -> str:
        """Render a compact Markdown slice (< 30 lines, < 800 tokens)."""
        anchor = slice_data.get("failureAnchor", {})
        lines = [
            f"### Causal Execution Slice at {anchor.get('file')}:{anchor.get('line')} in `{anchor.get('function')}()`",
            f"**Exception**: {anchor.get('exceptionType')}: {anchor.get('exceptionMessage')}",
            "",
            "#### Causal Chain",
            "```python",
        ]
        for step in slice_data.get("causalChain", []):
            lines.append(f"L{step.get('line')}: {step.get('code')}  # [{step.get('role')}]")
        lines.append("```")

        locals_map = slice_data.get("localState", {})
        if locals_map:
            lines.append("#### Local Failure State")
            lines.append("```json")
            import json
            lines.append(json.dumps(locals_map, indent=2))
            lines.append("```")

        return "\n".join(lines)
