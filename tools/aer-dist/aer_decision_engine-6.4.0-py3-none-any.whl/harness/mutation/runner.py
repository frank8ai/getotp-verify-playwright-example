"""Mutation runner: executes mutants in isolated work copy against test suite."""

from __future__ import annotations

import os
import shutil
import subprocess
import sys
import tempfile
import time
from pathlib import Path
from typing import Callable, Iterable

from .models import Mutant, MutationReport, MutationResult


class MutationRunner:
    """Executes mutants one at a time and evaluates kill rate."""

    def __init__(
        self,
        test_command: list[str] | None = None,
        timeout_multiplier: float = 1.5,
        total_timeout_multiplier: float = 3.0,
    ) -> None:
        self.test_command = test_command or [sys.executable, "-m", "unittest", "discover", "-s", "tests", "-q"]
        self.timeout_multiplier = timeout_multiplier
        self.total_timeout_multiplier = total_timeout_multiplier

    def evaluate_mutants(
        self,
        mutants: list[Mutant],
        repo_dir: Path | str,
        *,
        baseline_duration_sec: float = 5.0,
    ) -> MutationReport:
        """Run each mutant in an isolated copy of target files and observe test outcome."""
        if not mutants:
            return MutationReport(
                total_mutants=0,
                killed_mutants=0,
                survived_mutants=0,
                kill_rate=1.0,
                results=[],
                surviving_mutants=[],
                applicable=False,
                not_applicable_reason="No admissible mutants generated for changed production code",
            )

        root = Path(repo_dir).resolve()
        individual_timeout = max(1.0, baseline_duration_sec * self.timeout_multiplier)
        total_cap_sec = max(3.0, baseline_duration_sec * self.total_timeout_multiplier)

        results: list[MutationResult] = []
        surviving: list[str] = []
        start_all = time.monotonic()

        for mutant in mutants:
            elapsed_total = time.monotonic() - start_all
            if elapsed_total > total_cap_sec:
                # Circuit breaker triggered
                return MutationReport(
                    total_mutants=len(mutants),
                    killed_mutants=sum(1 for r in results if r.status in ("KILLED", "TIMEOUT")),
                    survived_mutants=sum(1 for r in results if r.status == "SURVIVED"),
                    kill_rate=0.0,
                    results=results,
                    surviving_mutants=surviving,
                    applicable=False,
                    not_applicable_reason=f"Total mutation wall-clock budget breached ({total_cap_sec:.1f}s)",
                )

            target_file_path = root / mutant.target_file
            if not target_file_path.is_file():
                continue

            original_code = target_file_path.read_text(encoding="utf-8")
            start_mutant = time.monotonic()
            mutant_status = "SURVIVED"
            killer = ""

            try:
                # Inject mutant into file
                target_file_path.write_text(mutant.mutated_source, encoding="utf-8")

                # Execute test command
                env = os.environ.copy()
                env["PYTHONPATH"] = str(root / "core") if (root / "core").is_dir() else str(root)
                res = subprocess.run(
                    self.test_command,
                    cwd=str(root),
                    capture_output=True,
                    text=True,
                    timeout=individual_timeout,
                    env=env,
                )
                dur_ms = (time.monotonic() - start_mutant) * 1000.0
                if res.returncode != 0:
                    mutant_status = "KILLED"
                    killer = "test_suite_failure"
                else:
                    mutant_status = "SURVIVED"
                    surviving.append(mutant.id)
            except subprocess.TimeoutExpired:
                dur_ms = (time.monotonic() - start_mutant) * 1000.0
                # Timeout at 1.5x baseline counts as KILLED (deadlock/infinite loop mutant)
                mutant_status = "KILLED"
                killer = "timeout_infinite_loop"
            except Exception as exc:
                dur_ms = (time.monotonic() - start_mutant) * 1000.0
                mutant_status = "KILLED"
                killer = f"error_{type(exc).__name__}"
            finally:
                # Always restore original file content
                target_file_path.write_text(original_code, encoding="utf-8")

            results.append(
                MutationResult(
                    mutant_id=mutant.id,
                    status=mutant_status,
                    killer_test=killer,
                    duration_ms=dur_ms,
                )
            )

        total = len(results)
        killed = sum(1 for r in results if r.status in ("KILLED", "TIMEOUT"))
        survived = sum(1 for r in results if r.status == "SURVIVED")
        kill_rate = (killed / total) if total > 0 else 1.0

        return MutationReport(
            total_mutants=total,
            killed_mutants=killed,
            survived_mutants=survived,
            kill_rate=kill_rate,
            results=results,
            surviving_mutants=surviving,
            applicable=True,
        )
