"""AST-based deterministic mutant synthesizer for python code."""

from __future__ import annotations

import ast
import copy
import hashlib
from pathlib import Path
from typing import Iterator

from .models import Mutant


class MutationSynthesizer:
    """Generates 3-5 deterministic AST mutants from target python source code."""

    def __init__(self, max_mutants: int = 5) -> None:
        self.max_mutants = max_mutants

    def generate_mutants(self, source: str, file_path: str = "target.py") -> list[Mutant]:
        """Generate at most max_mutants deterministic valid AST mutants."""
        # Never mutate test files
        norm_path = file_path.replace("\\", "/")
        if norm_path.startswith("tests/") or "test_" in norm_path or norm_path.endswith("_test.py"):
            return []

        try:
            tree = ast.parse(source)
        except SyntaxError:
            return []

        candidates: list[Mutant] = []
        mutant_idx = 1

        # Walk through AST and generate potential mutations
        for node in ast.walk(tree):
            if len(candidates) >= self.max_mutants:
                break

            # Operator 1: return X -> return None
            if isinstance(node, ast.Return) and node.value is not None:
                if not (isinstance(node.value, ast.Constant) and node.value.value is None):
                    mutated = self._apply_mutation(tree, node, "return_none")
                    if mutated:
                        mutant_id = f"mutant-{mutant_idx}"
                        mutant_idx += 1
                        candidates.append(
                            Mutant(
                                id=mutant_id,
                                target_file=file_path,
                                line_number=getattr(node, "lineno", 1),
                                mutation_type="return_none",
                                description=f"Replaced return expression at line {getattr(node, 'lineno', 1)} with None",
                                mutated_source=mutated,
                            )
                        )
                        if len(candidates) >= self.max_mutants:
                            break

            # Operator 2: Comparison inversion (e.g. > to <=)
            elif isinstance(node, ast.Compare) and len(node.ops) == 1:
                op = node.ops[0]
                inverted_op = self._invert_comparison_op(op)
                if inverted_op is not None:
                    mutated = self._apply_mutation(tree, node, "invert_comparison", new_op=inverted_op)
                    if mutated:
                        mutant_id = f"mutant-{mutant_idx}"
                        mutant_idx += 1
                        candidates.append(
                            Mutant(
                                id=mutant_id,
                                target_file=file_path,
                                line_number=getattr(node, "lineno", 1),
                                mutation_type="invert_comparison",
                                description=f"Inverted comparison operator at line {getattr(node, 'lineno', 1)}",
                                mutated_source=mutated,
                            )
                        )
                        if len(candidates) >= self.max_mutants:
                            break

            # Operator 3: Boundary +/- 1 on integer literals
            elif isinstance(node, ast.Constant) and isinstance(node.value, int) and not isinstance(node.value, bool):
                # Only shift reasonable constants, avoiding 0 in some cases or shifting by +1
                new_val = node.value + 1 if node.value >= 0 else node.value - 1
                mutated = self._apply_mutation(tree, node, "boundary_shift", new_val=new_val)
                if mutated:
                    mutant_id = f"mutant-{mutant_idx}"
                    mutant_idx += 1
                    candidates.append(
                        Mutant(
                            id=mutant_id,
                            target_file=file_path,
                            line_number=getattr(node, "lineno", 1),
                            mutation_type="boundary_shift",
                            description=f"Shifted integer constant {node.value} -> {new_val} at line {getattr(node, 'lineno', 1)}",
                            mutated_source=mutated,
                        )
                    )
                    if len(candidates) >= self.max_mutants:
                        break

            # Operator 4: Boolean negation (True -> False, False -> True)
            elif isinstance(node, ast.Constant) and isinstance(node.value, bool):
                new_val = not node.value
                mutated = self._apply_mutation(tree, node, "boolean_negation", new_val=new_val)
                if mutated:
                    mutant_id = f"mutant-{mutant_idx}"
                    mutant_idx += 1
                    candidates.append(
                        Mutant(
                            id=mutant_id,
                            target_file=file_path,
                            line_number=getattr(node, "lineno", 1),
                            mutation_type="boolean_negation",
                            description=f"Negated boolean constant {node.value} -> {new_val} at line {getattr(node, 'lineno', 1)}",
                            mutated_source=mutated,
                        )
                    )
                    if len(candidates) >= self.max_mutants:
                        break

            # Operator 5: if cond -> if not (cond)
            elif isinstance(node, ast.If):
                mutated = self._apply_mutation(tree, node, "negate_condition")
                if mutated:
                    mutant_id = f"mutant-{mutant_idx}"
                    mutant_idx += 1
                    candidates.append(
                        Mutant(
                            id=mutant_id,
                            target_file=file_path,
                            line_number=getattr(node, "lineno", 1),
                            mutation_type="negate_condition",
                            description=f"Negated if-condition at line {getattr(node, 'lineno', 1)}",
                            mutated_source=mutated,
                        )
                    )
                    if len(candidates) >= self.max_mutants:
                        break

        # Sort candidates deterministically
        candidates.sort(key=lambda m: (m.line_number, m.mutation_type, m.description))
        return candidates[:self.max_mutants]

    def _invert_comparison_op(self, op: ast.cmpop) -> ast.cmpop | None:
        if isinstance(op, ast.Gt):
            return ast.LtE()
        if isinstance(op, ast.Lt):
            return ast.GtE()
        if isinstance(op, ast.GtE):
            return ast.Lt()
        if isinstance(op, ast.LtE):
            return ast.Gt()
        if isinstance(op, ast.Eq):
            return ast.NotEq()
        if isinstance(op, ast.NotEq):
            return ast.Eq()
        return None

    def _apply_mutation(self, original_tree: ast.AST, target_node: ast.AST, mutation_type: str, **kwargs) -> str | None:
        new_tree = copy.deepcopy(original_tree)

        class Replacer(ast.NodeTransformer):
            def __init__(self, target_line, target_col):
                self.target_line = target_line
                self.target_col = target_col
                self.replaced = False

            def visit(self, node):
                if getattr(node, "lineno", None) == self.target_line and getattr(node, "col_offset", None) == self.target_col:
                    if mutation_type == "return_none" and isinstance(node, ast.Return):
                        self.replaced = True
                        return ast.Return(value=ast.Constant(value=None))
                    elif mutation_type == "invert_comparison" and isinstance(node, ast.Compare):
                        self.replaced = True
                        return ast.Compare(left=node.left, ops=[kwargs["new_op"]], comparators=node.comparators)
                    elif mutation_type == "boundary_shift" and isinstance(node, ast.Constant):
                        self.replaced = True
                        return ast.Constant(value=kwargs["new_val"])
                    elif mutation_type == "boolean_negation" and isinstance(node, ast.Constant):
                        self.replaced = True
                        return ast.Constant(value=kwargs["new_val"])
                    elif mutation_type == "negate_condition" and isinstance(node, ast.If):
                        self.replaced = True
                        new_test = ast.UnaryOp(op=ast.Not(), operand=node.test)
                        return ast.If(test=new_test, body=node.body, orelse=node.orelse)
                return self.generic_visit(node)

        replacer = Replacer(getattr(target_node, "lineno", None), getattr(target_node, "col_offset", None))
        mutated_ast = replacer.visit(new_tree)
        if not replacer.replaced:
            return None

        ast.fix_missing_locations(mutated_ast)
        try:
            code = ast.unparse(mutated_ast)
            # Assert re-parseability
            ast.parse(code)
            return code
        except Exception:
            return None
