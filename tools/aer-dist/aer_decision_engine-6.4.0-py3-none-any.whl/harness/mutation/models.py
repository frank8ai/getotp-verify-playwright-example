"""Data models and serialization contracts for mutation invalidation."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass(frozen=True)
class Mutant:
    """A synthesized source code mutation."""
    id: str
    target_file: str
    line_number: int
    mutation_type: str
    description: str
    mutated_source: str

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "targetFile": self.target_file,
            "lineNumber": self.line_number,
            "mutationType": self.mutation_type,
            "description": self.description,
            "mutatedSource": self.mutated_source,
        }


@dataclass(frozen=True)
class MutationResult:
    """Outcome of testing a single mutant."""
    mutant_id: str
    status: str  # KILLED, SURVIVED, TIMEOUT, ERROR
    killer_test: str = ""
    duration_ms: float = 0.0

    def to_dict(self) -> dict[str, Any]:
        return {
            "mutantId": self.mutant_id,
            "status": self.status,
            "killerTest": self.killer_test,
            "durationMs": self.duration_ms,
        }


@dataclass
class MutationReport:
    """Summary of all evaluated mutations."""
    total_mutants: int
    killed_mutants: int
    survived_mutants: int
    kill_rate: float
    results: list[MutationResult] = field(default_factory=list)
    surviving_mutants: list[str] = field(default_factory=list)
    applicable: bool = True
    not_applicable_reason: str = ""

    def to_dict(self) -> dict[str, Any]:
        return {
            "totalMutants": self.total_mutants,
            "killedMutants": self.killed_mutants,
            "survivedMutants": self.survived_mutants,
            "killRate": self.kill_rate,
            "results": [r.to_dict() for r in self.results],
            "survivingMutants": self.surviving_mutants,
            "applicable": self.applicable,
            "notApplicableReason": self.not_applicable_reason,
        }
