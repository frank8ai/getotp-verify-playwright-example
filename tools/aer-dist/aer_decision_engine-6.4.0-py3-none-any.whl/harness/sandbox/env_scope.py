"""Scope-based environment filtering for sandbox execution (aligns with broker model)."""

from __future__ import annotations

import os
from typing import Mapping


FORBIDDEN_SCOPE_SIGNALS = (
    "secret",
    "password",
    "token",
    "key",
    "auth",
    "credential",
    "bearer",
    "jwt",
    "private",
    "cert",
    "signature",
    "_pat",
    "pat_",
)

# Strict allowlist for customer-code execution environments.
# Customer-code sandboxes must start from an empty environment and may only
# receive explicitly approved, non-sensitive runtime configurations.
APPROVED_CUSTOMER_ENV_VARS = frozenset((
    "PATH",
    "PYTHONPATH",
    "LANG",
    "LC_ALL",
    "PYTHONUNBUFFERED",
    "PYTHONDONTWRITEBYTECODE",
))


def filter_environment_for_scope(
    base_env: Mapping[str, str],
    allowed_scopes: set[str] | list[str] | None = None,
) -> dict[str, str]:
    """Filter environment variables strictly according to provider scopes, rejecting raw secret naming."""
    filtered: dict[str, str] = {}

    for k, v in base_env.items():
        k_lower = k.lower()
        if any(sig in k_lower for sig in FORBIDDEN_SCOPE_SIGNALS):
            continue
        filtered[k] = v

    return filtered


def safe_sandbox_environment(
    caller_env: Mapping[str, str] | None = None,
    *,
    customer_code_mode: bool = False,
    base_env: Mapping[str, str] | None = None,
    approved_vars: frozenset[str] | set[str] | None = None,
) -> dict[str, str]:
    """Produce an environment that guarantees no host/operator secrets leak to sandboxed code.

    In customer_code_mode (P0-A):
    Execution starts from an EMPTY environment. Only explicitly approved,
    non-secret variables are permitted. Remaining host environment variables
    (even with innocuous names like DATABASE_URL or SENTRY_DSN) are discarded.
    """
    if customer_code_mode:
        allowed = approved_vars if approved_vars is not None else APPROVED_CUSTOMER_ENV_VARS
        safe: dict[str, str] = {}
        source = base_env if base_env is not None else os.environ
        for k, v in source.items():
            if k in allowed:
                k_lower = k.lower()
                if not any(sig in k_lower for sig in FORBIDDEN_SCOPE_SIGNALS):
                    safe[k] = str(v)
        if caller_env:
            for k, v in caller_env.items():
                if k in allowed:
                    k_lower = k.lower()
                    if not any(sig in k_lower for sig in FORBIDDEN_SCOPE_SIGNALS):
                        safe[k] = str(v)
        return safe

    # Internal / compatibility mode:
    source = base_env if base_env is not None else os.environ
    safe_base = filter_environment_for_scope(source)
    if caller_env:
        safe_caller = filter_environment_for_scope(caller_env)
        safe_base.update(safe_caller)
    return safe_base
