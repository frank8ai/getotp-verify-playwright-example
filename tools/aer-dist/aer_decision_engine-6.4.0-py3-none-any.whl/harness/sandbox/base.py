"""Base abstractions and data contracts for sandbox drivers."""

from __future__ import annotations

import abc
import hashlib
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Mapping


@dataclass(frozen=True)
class SandboxExecutionResult:
    exit_code: int
    stdout: str
    stderr: str
    duration_ms: float
    startup_ms: float = 0.0
    snapshot_id: str = ""
    network_policy: str = "none"
    fs_diff_digest: str = "sha256:e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    timed_out: bool = False

    def to_dict(self) -> dict[str, Any]:
        return {
            "exitCode": self.exit_code,
            "stdout": self.stdout,
            "stderr": self.stderr,
            "durationMs": self.duration_ms,
            "startupMs": self.startup_ms,
            "snapshotId": self.snapshot_id,
            "networkPolicy": self.network_policy,
            "fsDiffDigest": self.fs_diff_digest,
            "timedOut": self.timed_out,
        }


def compute_dir_diff_digest(dir_path: Path | str) -> str:
    path = Path(dir_path)
    if not path.is_dir():
        return "sha256:e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    entries: list[str] = []
    for item in sorted(path.rglob("*")):
        if ".git" in item.parts:
            continue
        rel = item.relative_to(path).as_posix()
        if item.is_file():
            hasher = hashlib.sha256()
            try:
                hasher.update(item.read_bytes())
                digest = hasher.hexdigest()
            except OSError:
                digest = "read-error"
            entries.append(f"{rel}:{digest}")
        elif item.is_dir():
            entries.append(f"{rel}:dir")
    raw = "\n".join(entries).encode("utf-8")
    return "sha256:" + hashlib.sha256(raw).hexdigest()


class SandboxDriver(abc.ABC):
    @abc.abstractmethod
    def run_command(
        self,
        command: list[str] | str,
        *,
        cwd: Path | str | None = None,
        env: Mapping[str, str] | None = None,
        timeout_sec: float = 60.0,
    ) -> SandboxExecutionResult:
        """Run command within sandbox isolation."""
        raise NotImplementedError

    @abc.abstractmethod
    def dispose(self) -> None:
        """Clean up all isolated resources and temporary structures."""
        raise NotImplementedError

    def __enter__(self) -> SandboxDriver:
        return self

    def __exit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        self.dispose()
