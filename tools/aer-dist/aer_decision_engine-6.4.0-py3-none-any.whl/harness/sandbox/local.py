"""Local process sandbox with full process tree termination on timeout."""

from __future__ import annotations

import os
import signal
import subprocess
import time
from pathlib import Path
from typing import Mapping

from .base import SandboxDriver, SandboxExecutionResult, compute_dir_diff_digest
from .env_scope import safe_sandbox_environment


def kill_process_tree(pid: int) -> None:
    if os.name == "nt":
        # Windows: taskkill /F /T /PID kills the target process and any child/grandchild processes
        subprocess.run(
            ["taskkill", "/F", "/T", "/PID", str(pid)],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            check=False,
        )
    else:
        # Unix: kill entire process group
        try:
            pgid = os.getpgid(pid)
            os.killpg(pgid, signal.SIGKILL)
        except (ProcessLookupError, OSError):
            try:
                os.kill(pid, signal.SIGKILL)
            except OSError:
                pass


class LocalProcessSandbox(SandboxDriver):
    def __init__(self, root_dir: Path | str = ".") -> None:
        self.root_dir = Path(root_dir).resolve()
        self.initial_fs_digest = compute_dir_diff_digest(self.root_dir)

    def run_command(
        self,
        command: list[str] | str,
        *,
        cwd: Path | str | None = None,
        env: Mapping[str, str] | None = None,
        timeout_sec: float = 60.0,
    ) -> SandboxExecutionResult:
        workdir = Path(cwd) if cwd else self.root_dir
        workdir.mkdir(parents=True, exist_ok=True)
        shell = isinstance(command, str)
        preexec = None
        creationflags = 0
        if os.name != "nt":
            preexec = os.setsid
        else:
            # CREATE_NEW_PROCESS_GROUP = 0x00000200
            creationflags = 0x00000200

        sanitized_env = safe_sandbox_environment(caller_env=env)
        start_time = time.perf_counter()
        proc = subprocess.Popen(
            command,
            cwd=str(workdir),
            env=sanitized_env,
            shell=shell,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            preexec_fn=preexec,
            creationflags=creationflags,
        )

        timed_out = False
        try:
            stdout, stderr = proc.communicate(timeout=timeout_sec)
        except subprocess.TimeoutExpired:
            timed_out = True
            kill_process_tree(proc.pid)
            stdout, stderr = proc.communicate()

        duration_ms = (time.perf_counter() - start_time) * 1000.0
        fs_diff = compute_dir_diff_digest(self.root_dir)

        return SandboxExecutionResult(
            exit_code=proc.returncode if not timed_out else -1,
            stdout=stdout or "",
            stderr=stderr or "",
            duration_ms=duration_ms,
            startup_ms=0.0,
            snapshot_id="local-host",
            network_policy="host",
            fs_diff_digest=fs_diff,
            timed_out=timed_out,
        )

    def dispose(self) -> None:
        pass
