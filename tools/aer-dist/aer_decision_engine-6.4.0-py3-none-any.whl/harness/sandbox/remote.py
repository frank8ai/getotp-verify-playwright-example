"""Remote generic sandbox driver contract implementation."""

from __future__ import annotations

from pathlib import Path
from typing import Mapping

from .base import SandboxDriver, SandboxExecutionResult


class RemoteSandboxDriver(SandboxDriver):
    def __init__(
        self,
        endpoint: str,
        *,
        auth_scope: str = "provider:remote-exec",
        timeout_sec: float = 120.0,
    ) -> None:
        self.endpoint = endpoint
        self.auth_scope = auth_scope
        self.timeout_sec = timeout_sec

    def run_command(
        self,
        command: list[str] | str,
        *,
        cwd: Path | str | None = None,
        env: Mapping[str, str] | None = None,
        timeout_sec: float = 60.0,
    ) -> SandboxExecutionResult:
        raise NotImplementedError("Remote sandbox driver execution is not implemented")

    def dispose(self) -> None:
        pass
