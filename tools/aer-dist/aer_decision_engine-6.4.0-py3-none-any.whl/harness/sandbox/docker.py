"""Docker container sandbox driver (enforces secure container isolation, deny-by-default network, ephemeral workspace)."""

from __future__ import annotations

import os
import shutil
import subprocess
import tempfile
import time
import uuid
from pathlib import Path
from typing import Mapping

from .base import SandboxDriver, SandboxExecutionResult, compute_dir_diff_digest
from .env_scope import safe_sandbox_environment


class DockerUnavailableError(RuntimeError):
    pass


def is_docker_available() -> bool:
    docker_bin = shutil.which("docker")
    if not docker_bin:
        return False
    try:
        res = subprocess.run(
            [docker_bin, "info"],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            check=False,
            timeout=5.0,
        )
        return res.returncode == 0
    except (subprocess.SubprocessError, OSError):
        return False


def resolve_workspace_owner(repo_dir: Path | None = None) -> str | None:
    """Determine container UID:GID matching the ephemeral workspace owner on POSIX hosts."""
    if os.name != "posix":
        return None
    uid: int | None = None
    gid: int | None = None
    if repo_dir is not None and repo_dir.exists():
        st = repo_dir.stat()
        uid = getattr(st, "st_uid", None)
        gid = getattr(st, "st_gid", None)
    if uid is None and hasattr(os, "getuid"):
        uid = os.getuid()
    if gid is None and hasattr(os, "getgid"):
        gid = os.getgid()
    if uid is not None and gid is not None:
        return f"{uid}:{gid}"
    return None


def build_docker_run_args(
    *,
    container_name: str,
    repo_dir: Path,
    ephemeral_build_dir: Path | None = None,
    writable_workspace: bool = False,
    network: str = "none",
    env: Mapping[str, str] | None = None,
    customer_code_mode: bool = True,
    image: str = "python:3.12-slim",
    command: list[str] | str,
    workdir: str = "/workspace",
    pids_limit: int = 128,
    memory_limit: str = "1g",
    cpus_limit: str = "2.0",
    read_only_root: bool = False,
    user: str | None = None,
) -> list[str]:
    """Construct the exact `docker run` argument vector adhering to security and resource invariants."""
    args = [
        "docker",
        "run",
        "--rm",
        "--name",
        container_name,
        "--network",
        network,
        # Security flags: drop setuid/setgid capability escalation where possible
        "--security-opt",
        "no-new-privileges:true",
        # Resource exhaustion protections (P0-E)
        "--pids-limit",
        str(pids_limit),
        "--memory",
        memory_limit,
        "--cpus",
        str(cpus_limit),
        "--cap-drop",
        "ALL",
        # Ephemeral in-memory tmp filesystem for build tools/scratch
        "--tmpfs",
        "/tmp:rw,noexec,nosuid,size=256m",
    ]

    if user:
        args.extend(["--user", user])

    if read_only_root:
        args.append("--read-only")

    if writable_workspace:
        # Ephemeral copy / overlay mounted rw; host remains untouched
        args.extend(["-v", f"{repo_dir.as_posix()}:/workspace:rw"])
    else:
        # Host repository strictly mounted read-only
        args.extend(["-v", f"{repo_dir.as_posix()}:/workspace:ro"])
        if ephemeral_build_dir:
            # Writable scratch volume mounted under workspace for test caches/build artifacts
            args.extend(["-v", f"{ephemeral_build_dir.as_posix()}:/workspace/.aer-build:rw"])

    args.extend(["-w", workdir])

    # Credential isolation (P0-A): allowlist-based empty environment for customer code
    sanitized_env = safe_sandbox_environment(caller_env=env, customer_code_mode=customer_code_mode)
    for k, v in sorted(sanitized_env.items()):
        args.extend(["-e", f"{k}={v}"])

    args.append(image)
    if isinstance(command, str):
        args.extend(["sh", "-c", command])
    else:
        args.extend(list(command))
    return args


class DockerSandbox(SandboxDriver):
    def __init__(
        self,
        repo_dir: Path | str = ".",
        *,
        image: str = "python:3.12-slim",
        writable_ephemeral_workspace: bool = True,
        pids_limit: int = 128,
        memory_limit: str = "1g",
        cpus_limit: str = "2.0",
        read_only_root: bool = False,
        user: str | None = None,
    ) -> None:
        self.repo_dir = Path(repo_dir).resolve()
        self.image = image
        self.writable_ephemeral_workspace = writable_ephemeral_workspace
        self.pids_limit = pids_limit
        self.memory_limit = memory_limit
        self.cpus_limit = cpus_limit
        self.read_only_root = read_only_root
        self.user = user
        self.initial_host_digest = compute_dir_diff_digest(self.repo_dir)

        if not is_docker_available():
            raise DockerUnavailableError(
                "Docker runtime is not installed or daemon is not reachable (status: unverified-local)"
            )

        # Set up ephemeral workspace if requested so realistic tests can compile/build without mutating host repo
        self._temp_dir: tempfile.TemporaryDirectory[str] | None = None
        self.working_repo_dir = self.repo_dir
        self.ephemeral_build_dir: Path | None = None

        if self.writable_ephemeral_workspace:
            self._temp_dir = tempfile.TemporaryDirectory(prefix="aer-docker-ephemeral-")
            temp_root = Path(self._temp_dir.name)
            ephemeral_ws = temp_root / "workspace"
            shutil.copytree(self.repo_dir, ephemeral_ws, symlinks=True)
            self.working_repo_dir = ephemeral_ws
        else:
            self._temp_dir = tempfile.TemporaryDirectory(prefix="aer-docker-build-")
            self.ephemeral_build_dir = Path(self._temp_dir.name) / ".aer-build"
            self.ephemeral_build_dir.mkdir(parents=True, exist_ok=True)

        if self.user is None:
            self.user = resolve_workspace_owner(self.working_repo_dir)

        self.active_container_name: str | None = None

    def run_command(
        self,
        command: list[str] | str,
        *,
        cwd: Path | str | None = None,
        env: Mapping[str, str] | None = None,
        timeout_sec: float = 60.0,
    ) -> SandboxExecutionResult:
        container_name = f"aer-sandbox-{uuid.uuid4().hex[:12]}"
        self.active_container_name = container_name

        target_workdir = "/workspace"
        if cwd:
            resolved_cwd = Path(cwd).resolve()
            # P0-C: Invalid cwd outside workspace must be rejected, not silently replaced
            if resolved_cwd.is_absolute():
                try:
                    rel = resolved_cwd.relative_to(self.repo_dir)
                    target_workdir = f"/workspace/{rel.as_posix()}" if str(rel) != "." else "/workspace"
                except ValueError:
                    raise ValueError(
                        f"Requested cwd '{cwd}' is outside the repository root '{self.repo_dir}'. Fail-closed enforcement active."
                    )
            else:
                rel = Path(cwd)
                if rel.is_absolute() or ".." in rel.parts:
                    raise ValueError(
                        f"Requested relative cwd '{cwd}' attempts directory traversal outside repository. Fail-closed enforcement active."
                    )
                target_workdir = f"/workspace/{rel.as_posix()}"

        docker_cmd = build_docker_run_args(
            container_name=container_name,
            repo_dir=self.working_repo_dir,
            ephemeral_build_dir=self.ephemeral_build_dir,
            writable_workspace=self.writable_ephemeral_workspace,
            network="none",
            env=env,
            customer_code_mode=True,
            image=self.image,
            command=command,
            workdir=target_workdir,
            pids_limit=self.pids_limit,
            memory_limit=self.memory_limit,
            cpus_limit=self.cpus_limit,
            read_only_root=self.read_only_root,
            user=self.user,
        )

        start_time = time.perf_counter()
        proc = subprocess.Popen(
            docker_cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
        )
        timed_out = False
        try:
            stdout, stderr = proc.communicate(timeout=timeout_sec)
        except subprocess.TimeoutExpired:
            timed_out = True
            # Send SIGKILL specifically to the named container so process tree and container terminate cleanly
            subprocess.run(["docker", "kill", "-s", "KILL", container_name], check=False, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            subprocess.run(["docker", "rm", "-f", container_name], check=False, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            stdout, stderr = proc.communicate()
        finally:
            self.active_container_name = None

        duration_ms = (time.perf_counter() - start_time) * 1000.0
        fs_diff = compute_dir_diff_digest(self.working_repo_dir)

        # P0-G: Honest metrics - startup_ms is 0.0 (unmeasured for synchronous docker run), not an invented constant 100.0
        return SandboxExecutionResult(
            exit_code=proc.returncode if not timed_out else -1,
            stdout=stdout or "",
            stderr=stderr or "",
            duration_ms=duration_ms,
            startup_ms=0.0,
            snapshot_id=container_name,
            network_policy="none",
            fs_diff_digest=fs_diff,
            timed_out=timed_out,
        )

    def dispose(self) -> None:
        if self.active_container_name:
            try:
                subprocess.run(["docker", "rm", "-f", self.active_container_name], check=False, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            except OSError:
                pass
            self.active_container_name = None
        if self._temp_dir is not None:
            self._temp_dir.cleanup()
            self._temp_dir = None
