"""Git worktree sandbox driver for clean, isolated checkouts."""

from __future__ import annotations

import os
import shutil
import subprocess
import time
import uuid
from pathlib import Path
from typing import Mapping

from .base import SandboxDriver, SandboxExecutionResult, compute_dir_diff_digest
from .env_scope import safe_sandbox_environment
from .local import kill_process_tree


class WorktreeDirtyError(RuntimeError):
    pass


class LowDiskSpaceError(RuntimeError):
    pass


def get_free_disk_gb(path: Path) -> float:
    total, used, free = shutil.disk_usage(path)
    return free / (1024 ** 3)


class GitWorktreeSandbox(SandboxDriver):
    def __init__(
        self,
        repo_dir: Path | str = ".",
        *,
        base_ref: str = "HEAD",
        worktree_parent: Path | str | None = None,
        min_free_disk_gb: float = 5.0,
    ) -> None:
        self.repo_dir = Path(repo_dir).resolve()
        self.base_ref = base_ref

        # Check host cleanliness
        res = subprocess.run(
            ["git", "status", "--porcelain", "-uno"],
            cwd=str(self.repo_dir),
            capture_output=True,
            text=True,
            check=True,
        )
        if res.stdout.strip():
            raise WorktreeDirtyError(
                f"Cannot create worktree sandbox: host repository is dirty:\n{res.stdout}"
            )

        parent = Path(worktree_parent) if worktree_parent else self.repo_dir.parent
        free_gb = get_free_disk_gb(parent)
        self.low_disk_mode = free_gb < min_free_disk_gb

        self.worktree_id = f"aer-wt-{uuid.uuid4().hex[:8]}"
        self.worktree_path = parent / self.worktree_id

        start_time = time.perf_counter()
        subprocess.run(
            ["git", "worktree", "add", "--detach", str(self.worktree_path), self.base_ref],
            cwd=str(self.repo_dir),
            capture_output=True,
            text=True,
            check=True,
        )
        self.startup_ms = (time.perf_counter() - start_time) * 1000.0
        self.initial_fs_digest = compute_dir_diff_digest(self.worktree_path)

    def run_command(
        self,
        command: list[str] | str,
        *,
        cwd: Path | str | None = None,
        env: Mapping[str, str] | None = None,
        timeout_sec: float = 60.0,
    ) -> SandboxExecutionResult:
        workdir = self.worktree_path
        if cwd:
            rel = Path(cwd)
            if rel.is_absolute():
                try:
                    rel = rel.relative_to(self.repo_dir)
                    workdir = self.worktree_path / rel
                except ValueError:
                    workdir = rel
            else:
                workdir = self.worktree_path / rel

        shell = isinstance(command, str)
        preexec = None
        creationflags = 0
        if os.name != "nt":
            preexec = os.setsid
        else:
            creationflags = 0x00000200

        sanitized_env = safe_sandbox_environment(caller_env=env)
        start_time = time.perf_counter()
        proc = subprocess.Popen(
            command,
            cwd=str(workdir),
            env=sanitized_env,
            shell=shell,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            preexec_fn=preexec,
            creationflags=creationflags,
        )

        timed_out = False
        try:
            stdout, stderr = proc.communicate(timeout=timeout_sec)
        except subprocess.TimeoutExpired:
            timed_out = True
            kill_process_tree(proc.pid)
            stdout, stderr = proc.communicate()

        duration_ms = (time.perf_counter() - start_time) * 1000.0
        fs_diff = compute_dir_diff_digest(self.worktree_path)

        return SandboxExecutionResult(
            exit_code=proc.returncode if not timed_out else -1,
            stdout=stdout or "",
            stderr=stderr or "",
            duration_ms=duration_ms,
            startup_ms=self.startup_ms,
            snapshot_id=self.worktree_id,
            network_policy="none",
            fs_diff_digest=fs_diff,
            timed_out=timed_out,
        )

    def dispose(self) -> None:
        if self.worktree_path.exists():
            subprocess.run(
                ["git", "worktree", "remove", "--force", str(self.worktree_path)],
                cwd=str(self.repo_dir),
                capture_output=True,
                text=True,
                check=False,
            )
            if self.worktree_path.exists():
                shutil.rmtree(self.worktree_path, ignore_errors=True)
            subprocess.run(
                ["git", "worktree", "prune"],
                cwd=str(self.repo_dir),
                capture_output=True,
                check=False,
            )
