"""E2B remote cloud sandbox driver implementation."""

from __future__ import annotations

from pathlib import Path
from typing import Mapping

from .base import SandboxDriver, SandboxExecutionResult


class E2BRemoteSandbox(SandboxDriver):
    def __init__(
        self,
        template: str = "base",
        *,
        provider_scope: str = "provider:e2b",
    ) -> None:
        self.template = template
        self.provider_scope = provider_scope

    def run_command(
        self,
        command: list[str] | str,
        *,
        cwd: Path | str | None = None,
        env: Mapping[str, str] | None = None,
        timeout_sec: float = 60.0,
    ) -> SandboxExecutionResult:
        raise NotImplementedError("E2B remote sandbox execution is not implemented")

    def dispose(self) -> None:
        pass
