"""Sandbox selection logic and human-required execution guards."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from .base import SandboxDriver
from .docker import DockerSandbox, is_docker_available
from .local import LocalProcessSandbox
from .worktree import GitWorktreeSandbox


class SandboxPolicyViolationError(PermissionError):
    pass


def load_sandbox_policy(config_path: Path | str | None = None) -> dict[str, Any]:
    path = Path(config_path) if config_path else Path("config/sandbox-policy.json")
    if not path.is_file():
        return {
            "defaultDriver": "worktree",
            "customerCodeProfiles": ["aer-verify", "customer-code"],
            "driverPrecedence": ["docker", "worktree", "local"],
            "profiles": {
                "aer-verify": {
                    "defaultDriver": "docker",
                    "allowedDrivers": ["docker"],
                    "networkPolicy": "none",
                    "allowExecution": True,
                    "customerCodeMode": True,
                    "resourceLimits": {
                        "pidsLimit": 128,
                        "memory": "1g",
                        "cpus": "2.0",
                    },
                },
                "customer-code": {
                    "defaultDriver": "docker",
                    "allowedDrivers": ["docker"],
                    "networkPolicy": "none",
                    "allowExecution": True,
                    "customerCodeMode": True,
                    "resourceLimits": {
                        "pidsLimit": 128,
                        "memory": "1g",
                        "cpus": "2.0",
                    },
                },
                "autopilot-low": {
                    "defaultDriver": "worktree",
                    "allowedDrivers": ["worktree", "local", "docker", "remote"],
                },
                "autopilot-medium": {
                    "defaultDriver": "worktree",
                    "allowedDrivers": ["worktree", "local", "docker", "remote"],
                },
                "human-required": {"allowExecution": False},
            },
        }
    return json.loads(path.read_text(encoding="utf-8"))


def select_sandbox_driver(
    repo_dir: Path | str = ".",
    *,
    profile: str = "autopilot-low",
    requested_driver: str | None = None,
    customer_code_mode: bool | None = None,
    config_path: Path | str | None = None,
    docker_image: str = "python:3.12-slim",
) -> SandboxDriver:
    """Select appropriate sandbox driver respecting policy and human-required boundaries.

    Customer code invariant:
    Untrusted customer repository code must never silently execute with unrestricted
    host access because a sandbox is unknown, unavailable, or misconfigured.
    """
    policy = load_sandbox_policy(config_path)
    profiles = policy.get("profiles", {})

    # P0-C: Unknown or mistyped profile must fail closed immediately
    if profile not in profiles:
        raise SandboxPolicyViolationError(
            f"Unknown or unconfigured sandbox profile '{profile}'. Fail-closed enforcement active."
        )

    profile_cfg = profiles[profile]

    if profile == "human-required" or profile_cfg.get("allowExecution") is False:
        reason = profile_cfg.get("disallowedReason", "execution forbidden for profile human-required")
        raise SandboxPolicyViolationError(f"Sandbox execution blocked: {reason}")

    customer_profiles = set(policy.get("customerCodeProfiles") or ["aer-verify", "customer-code"])
    is_customer_mode = (
        customer_code_mode
        if customer_code_mode is not None
        else (profile in customer_profiles or profile_cfg.get("customerCodeMode", False))
    )

    driver_name = requested_driver or profile_cfg.get("defaultDriver") or policy.get("defaultDriver", "worktree")
    allowed_drivers = profile_cfg.get("allowedDrivers")

    if is_customer_mode:
        # In customer-code mode, host-execution drivers (local / worktree) are prohibited as trust boundaries.
        # Only containerized/microVM sandboxes (e.g. docker) are permissible.
        if driver_name in ("local", "worktree"):
            raise SandboxPolicyViolationError(
                f"Driver '{driver_name}' is forbidden for customer code execution. "
                f"Customer code must execute in an isolated container sandbox (fail-closed)."
            )

    if allowed_drivers is not None and driver_name not in allowed_drivers:
        raise SandboxPolicyViolationError(
            f"Driver '{driver_name}' is not permitted by profile '{profile}' policy. "
            f"Allowed drivers: {allowed_drivers}"
        )

    if driver_name == "docker":
        limits = profile_cfg.get("resourceLimits", {})
        pids_limit = int(limits.get("pidsLimit", 128))
        memory_limit = str(limits.get("memory", "1g"))
        cpus_limit = str(limits.get("cpus", "2.0"))
        return DockerSandbox(
            repo_dir=repo_dir,
            image=docker_image,
            pids_limit=pids_limit,
            memory_limit=memory_limit,
            cpus_limit=cpus_limit,
        )
    elif driver_name == "worktree":
        return GitWorktreeSandbox(repo_dir=repo_dir)
    elif driver_name == "local":
        return LocalProcessSandbox(root_dir=repo_dir)
    else:
        # Unknown or unsupported drivers must fail closed; NEVER silently fall back to host execution!
        raise SandboxPolicyViolationError(
            f"Unknown or unsupported sandbox driver '{driver_name}'. Fail-closed enforcement active."
        )
