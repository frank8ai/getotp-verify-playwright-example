"""AER testing harness and execution capability layer."""
