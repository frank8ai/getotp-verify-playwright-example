"""Command line entry point: ``python -m harness.pipeline baseline ...``"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from .baseline import capture_baseline_from_gates


def baseline(args: argparse.Namespace) -> int:
    doc = capture_baseline_from_gates(
        args.repo,
        tier=args.tier,
        run_id=args.run_id,
        log_dir=args.log_dir or None,
    )
    if args.output:
        target = Path(args.output)
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(
            json.dumps(doc, indent=2, ensure_ascii=False) + "\n",
            encoding="utf-8",
        )

    surface = doc["surface"]
    print(
        "AER_BASELINE: "
        f"tier={doc['tier']} "
        f"sha={str(doc['baselineSha'])[:12]} "
        f"gates={surface['testCount']} "
        f"failures={len(doc['failures'])}"
    )
    print(json.dumps(doc, ensure_ascii=False))
    return 0




def search(args: argparse.Namespace) -> int:
    from harness.search.coordinator import SearchCoordinator

    strategies = [s.strip() for s in args.strategies.split(",") if s.strip()] if args.strategies else None
    coord = SearchCoordinator(strategies=strategies)

    context = args.context
    if args.context_file:
        context = Path(args.context_file).read_text(encoding="utf-8")

    # Safe stub generator for standalone CLI evaluation unless driven by agent
    generator = lambda prompt: f"def resolve_patch():\n    # {prompt[:60].replace(chr(10), " ")}\n    return True\n"
    cheap_gate = lambda patch: 0
    full_gate = lambda patch: (1.0, 1.0, 2, 1)

    winner, nodes, metrics = coord.coordinate_serial_best_of_2(
        context,
        generator_fn=generator,
        cheap_gate_fn=cheap_gate,
        full_gate_fn=full_gate,
    )

    doc = {
        "winner": winner.node_id if winner else None,
        "nodes": [
            {
                "id": n.node_id,
                "strategy": n.strategy,
                "status": n.status,
                "score": n.score,
            }
            for n in nodes
        ],
        "metrics": {
            "firstAttemptSuccessRate": metrics.first_attempt_success_rate,
            "marginalGainBestOf2": metrics.marginal_gain_best_of_2,
            "costTokens": metrics.cost_per_additional_candidate_tokens,
            "costMs": metrics.cost_per_additional_candidate_ms,
        },
    }

    if args.output:
        target = Path(args.output)
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(json.dumps(doc, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")

    first_rate = metrics.first_attempt_success_rate
    gain = metrics.marginal_gain_best_of_2
    print(
        f"AER_SEARCH: winner={doc["winner"]} "
        f"nodes={len(nodes)} "
        f"firstPass={first_rate:.2f} "
        f"marginalGain={gain:.2f}"
    )
    print(json.dumps(doc, ensure_ascii=False))
    return 0

def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="python -m harness.pipeline")
    subparsers = parser.add_subparsers(dest="command", required=True)

    baseline_parser = subparsers.add_parser(
        "baseline",
        help="Run the manifest gates on this checkout and emit a verification baseline.",
    )
    baseline_parser.add_argument("--repo", default=".")
    baseline_parser.add_argument("--tier", default="cheap", choices=["cheap", "full"])
    baseline_parser.add_argument(
        "--run-id",
        default="",
        help="Baseline run id; defaults to baseline-<tier>-<sha12>.",
    )
    baseline_parser.add_argument(
        "--log-dir",
        default="",
        help="Optional directory for per-gate logs (defaults to no logs).",
    )
    baseline_parser.add_argument("--output", default="")
    baseline_parser.set_defaults(handler=baseline)

    
    search_parser = subparsers.add_parser(
        "search",
        help="Coordinate serial candidate generation and pruning.",
    )
    search_parser.add_argument("--context", default="", help="Task context string.")
    search_parser.add_argument("--context-file", default="", help="Path to task context file.")
    search_parser.add_argument("--strategies", default="", help="Comma-separated strategy list.")
    search_parser.add_argument("--output", default="", help="Path to write search result JSON.")
    search_parser.set_defaults(handler=search)

    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    return args.handler(args)


if __name__ == "__main__":
    raise SystemExit(main())
