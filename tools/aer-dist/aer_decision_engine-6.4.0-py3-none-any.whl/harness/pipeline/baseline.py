"""Trusted-baseline production for the RVCE closure loop.

``core.aer.closure.run_closure`` needs a baseline document to attribute failures
differentially. This module turns "run the manifest gates, then assemble a
verification-baseline/v2 document" into one callable and one CLI.

The capture point matters more than anything else here: the baseline must be
produced on the **base / merge-base commit**, never on the candidate HEAD. A
baseline captured on the candidate makes ``git diff <baselineSha> HEAD`` empty,
which silently disables failure attribution *and* protected-surface detection --
a self-certifying PASS.
"""

from __future__ import annotations

import subprocess
from pathlib import Path
from typing import Any

# Import the concrete modules rather than the ``core.aer`` package surface: the
# package-level ``build_evidence`` is re-exported from ``attribution`` and does
# not understand ``surface.testIds`` or ``mutation_report``.
from core.aer.baseline import capture_baseline
from core.aer.closure import load_manifest, run_gates


def _git_sha(repo_path: Path) -> str:
    result = subprocess.run(
        ["git", "-C", str(repo_path), "rev-parse", "HEAD"],
        capture_output=True,
        text=True,
        check=False,
    )
    return result.stdout.strip() if result.returncode == 0 else ""


def capture_baseline_from_gates(
    repo: Path | str = ".",
    *,
    tier: str = "cheap",
    run_id: str = "",
    log_dir: Path | str | None = None,
) -> dict[str, Any]:
    """Run the manifest gates on ``repo`` and return a baseline document.

    ``run_gates`` is the same executor ``aer verify`` uses, so the baseline
    surface and failure fingerprints are directly comparable with the candidate
    run. ``log_dir`` is optional: baseline failures are consumed only through
    their fingerprints, so the closure engine never needs their gate logs.
    """
    repo_path = Path(repo).resolve()
    manifest = load_manifest(repo_path)
    outcomes = run_gates(manifest, tier=tier, cwd=repo_path, log_dir=log_dir)

    surface = {
        "testCount": len(outcomes),
        "testFiles": [
            f"gate:{outcome.test_id.split('::', 1)[0]}" for outcome in outcomes
        ],
        "testIds": [outcome.test_id for outcome in outcomes],
    }
    failures = [outcome.failure_record() for outcome in outcomes if not outcome.passed]

    return capture_baseline(
        repo_path,
        tier=tier,
        run_id=run_id or f"baseline-{tier}-{_git_sha(repo_path)[:12]}",
        candidate_surface=surface,
        failures=failures,
    )
