"""AER closure-loop pipeline.

Orchestration that turns the already-implemented RVCE machinery into a
production entry point. Everything here calls the existing ``core.aer`` APIs;
it deliberately lives outside ``core/aer/**`` so that wiring changes do not
trip the manifest's protected surface.
"""
