"""Evidence-document gates, ported from three sibling shell scripts.

Each gate validates one evidence document against its schema and blocks with
exit 2 when the document is missing, malformed, or inconsistent:

* `check-review-evidence.ps1`   -> ``review-evidence/v1``
* `check-tdd-evidence.ps1`      -> ``tdd-evidence/v1``
* `check-debugging-evidence.ps1`` -> ``debugging-evidence/v1``

They live together because they share one job -- "is this evidence document
acceptable?" -- and one set of PowerShell coercion quirks. The *rules* stay
written out separately per gate; only the coercion helpers are shared.

Why the coercion helpers exist at all: PowerShell's `@()`, `-not`, and `-lt`
do not behave like their Python lookalikes, and every difference below was
measured against the running reference rather than inferred. Getting one wrong
either lets an unverified change through (too lax) or breaks a legitimate
agent (too strict), so they are pinned by parity tests.

Measured behaviours encoded here
--------------------------------

``@($value).Count -gt 0`` is **False only for an empty array**. `@($null)`
is a one-element array in PowerShell, so a *missing* field counts as present:

    @($null).Count  -> 1        # missing  => "must not include" BLOCKS
    @(@()).Count    -> 0        # []       => passes
    @(@{}).Count    -> 1        # {}       => BLOCKS

``$value | Where-Object { -not [string]::IsNullOrWhiteSpace($_) }`` *enumerates*
first, so the same missing field filters down to zero:

    $null       -> 0 items
    @()         -> 0 items
    "pytest"    -> 1 item
    "   "       -> 0 items (filtered)

`-not $value` treats an empty *hashtable* as truthy, unlike Python's `not {}`:

    -not $null  -> True      -not @{}   -> False
    -not 0      -> True      -not "false" -> False

`$value -lt 0` compares as **strings** when `$value` is a string, so a
non-numeric confidence is not simply coerced to zero:

    $null -lt 0      -> True    (blocks)
    "abc" -gt 1      -> True    (blocks)
    "0.5" -gt 1      -> False   (passes)
"""

from __future__ import annotations

import sys
from pathlib import Path
from typing import Any

from .gate_support import (
    GateResult,
    is_blank as _is_blank,
    load_document,
    ps_string as _ps_str,
    ps_truthy as _ps_truthy,
)

REVIEW_SCHEMA = "review-evidence/v1"
TDD_SCHEMA = "tdd-evidence/v1"
DEBUGGING_SCHEMA = "debugging-evidence/v1"

ALLOWED_REVIEW_ROLES: tuple[str, ...] = (
    "scope-safety",
    "tests-regression",
    "qa-smoke",
    "security-sensitive",
    "release-readiness",
    "human-required",
)
ALLOWED_REVIEW_DECISIONS: tuple[str, ...] = ("PASS", "CHANGES_REQUESTED", "NEED_USER_ACTION")
ALLOWED_REVIEW_RISKS: tuple[str, ...] = ("low", "medium", "high")

ALLOWED_TDD_DECISIONS: tuple[str, ...] = ("PASS", "FAIL", "NOT_FEASIBLE", "NEED_USER_ACTION")

ALLOWED_DEBUGGING_DECISIONS: tuple[str, ...] = ("PATCH_READY", "NEED_MORE_INFO", "HUMAN_REQUIRED")
# The reference iterates this tuple in order and reports the first blank one.
DEBUGGING_REQUIRED_FIELDS: tuple[str, ...] = (
    "symptom",
    "reproduction",
    "rootCause",
    "fixPlan",
)

REVIEW_VALID = "REVIEW_EVIDENCE_VALID"
REVIEW_INVALID = "REVIEW_EVIDENCE_INVALID"
TDD_VALID = "TDD_EVIDENCE_VALID"
TDD_INVALID = "TDD_EVIDENCE_INVALID"
DEBUGGING_VALID = "DEBUGGING_EVIDENCE_VALID"
DEBUGGING_INVALID = "DEBUGGING_EVIDENCE_INVALID"


def _invalid(marker: str, reason: str) -> GateResult:
    return GateResult(exit_code=2, message=f"{marker}: {reason}")


def _has_any(value: Any) -> bool:
    """Mirror `@($value).Count -gt 0` -- False *only* for an empty array.

    A missing field yields True here, which is what makes
    "PASS review must not include required_actions" fire on a document that
    simply omits the key. That is the reference behaviour, verified against it;
    do not "fix" this into a Python truthiness test.
    """
    if isinstance(value, (list, tuple)):
        return len(value) > 0
    return True


def _filtered_count(value: Any) -> int:
    """Mirror `@($value | Where-Object { -not IsNullOrWhiteSpace($_) }).Count`.

    Unlike `_has_any`, this enumerates first, so a missing field is zero.
    """
    if value is None:
        return 0
    if isinstance(value, (list, tuple)):
        items = list(value)
    else:
        items = [value]
    return sum(1 for item in items if not _is_blank(item))


def _confidence_out_of_range(value: Any) -> bool:
    """Mirror `$value -lt 0 -or $value -gt 1`.

    PowerShell picks the comparison type from the left operand: numbers compare
    numerically, strings compare as strings, and `$null` compares as less than
    zero (so a missing confidence is rejected rather than defaulting to valid).
    """
    if value is None:
        # `$null -lt 0` is True in PowerShell.
        return True
    if isinstance(value, str):
        # String comparison: "abc" > "1" blocks, "0.5" > "1" does not.
        return value < "0" or value > "1"
    if isinstance(value, bool):
        # `$true` coerces to 1, which is in range.
        return int(value) < 0 or int(value) > 1
    if isinstance(value, (int, float)):
        return value < 0 or value > 1
    # Objects and arrays are not comparable in the reference; treating them as
    # out of range keeps the gate closed rather than open.
    return True


def _load_document(path: str | Path) -> tuple[Any, str | None]:
    """Read + parse the evidence file, returning (doc, refusal_reason).

    Thin wrapper over the shared loader so the three gates below keep their
    local call shape.  The behaviour lives in `core.aer.gate_support` because
    a second gate grew a divergent copy of it; see that module for the
    measured reference behaviour and why the copies disagreed.

    A *missing* file is not an error here: every caller supplies its own
    "missing ... file" wording after checking existence first.
    """
    target = Path(path)
    if not target.exists():
        return None, None
    return load_document(target)


def _field(doc: Any, name: str) -> Any:
    return doc.get(name) if isinstance(doc, dict) else None


# --------------------------------------------------------------------------
# review-evidence/v1
# --------------------------------------------------------------------------
def check_review_evidence(doc: Any) -> GateResult:
    """Validate a review-evidence/v1 document."""
    if _field(doc, "schemaVersion") != REVIEW_SCHEMA:
        return _invalid(REVIEW_INVALID, "unsupported schemaVersion")

    role = _field(doc, "role")
    if _ps_str(role) not in ALLOWED_REVIEW_ROLES:
        return _invalid(REVIEW_INVALID, f"unsupported role: {_ps_str(role)}")

    decision = _field(doc, "decision")
    if _ps_str(decision) not in ALLOWED_REVIEW_DECISIONS:
        return _invalid(REVIEW_INVALID, f"unsupported decision: {_ps_str(decision)}")

    risk = _field(doc, "risk")
    if _ps_str(risk) not in ALLOWED_REVIEW_RISKS:
        return _invalid(REVIEW_INVALID, f"unsupported risk: {_ps_str(risk)}")

    if _ps_str(decision) == "PASS":
        if _filtered_count(_field(doc, "tested_commands")) == 0:
            return _invalid(REVIEW_INVALID, "PASS review must include tested_commands")
        if _filtered_count(_field(doc, "changed_paths")) == 0:
            return _invalid(REVIEW_INVALID, "PASS review must include changed_paths")
        # `@($null).Count` is 1, so an omitted key blocks here. A PASS review
        # has to say `[]` explicitly.
        if _has_any(_field(doc, "required_actions")):
            return _invalid(REVIEW_INVALID, "PASS review must not include required_actions")
        if _has_any(_field(doc, "forbidden_claims_detected")):
            return _invalid(
                REVIEW_INVALID, "PASS review must not include forbidden_claims_detected"
            )

    return GateResult(exit_code=0, message=REVIEW_VALID)


def run_review_evidence(path: str | Path) -> GateResult:
    if not Path(path).exists():
        return _invalid(REVIEW_INVALID, "missing review evidence file")
    doc, refusal = _load_document(path)
    if refusal:
        return _invalid(REVIEW_INVALID, refusal)
    return check_review_evidence(doc)


# --------------------------------------------------------------------------
# tdd-evidence/v1
# --------------------------------------------------------------------------
def check_tdd_evidence(doc: Any) -> GateResult:
    """Validate a tdd-evidence/v1 document."""
    if _field(doc, "schemaVersion") != TDD_SCHEMA:
        return _invalid(TDD_INVALID, "unsupported schemaVersion")

    decision = _field(doc, "decision")
    if _ps_str(decision) not in ALLOWED_TDD_DECISIONS:
        return _invalid(TDD_INVALID, "invalid decision")

    if _ps_str(decision) == "NOT_FEASIBLE":
        if _is_blank(_field(doc, "notFeasibleReason")):
            return _invalid(TDD_INVALID, "NOT_FEASIBLE requires notFeasibleReason")
        return GateResult(exit_code=0, message=f"{TDD_VALID} decision=NOT_FEASIBLE")

    if _ps_str(decision) != "PASS":
        # FAIL and NEED_USER_ACTION are valid documents; they just are not
        # claims of a passing red/green cycle.
        return GateResult(exit_code=0, message=f"{TDD_VALID} decision={_ps_str(decision)}")

    red = _field(doc, "red")
    if not _ps_truthy(_field(red, "failedAsExpected")):
        return _invalid(TDD_INVALID, "red.failedAsExpected must be true for PASS")
    if _is_blank(_field(red, "testCommand")):
        return _invalid(TDD_INVALID, "red.testCommand required")
    if _is_blank(_field(red, "failureSummary")):
        return _invalid(TDD_INVALID, "red.failureSummary required")

    green = _field(doc, "green")
    if not _ps_truthy(_field(green, "passed")):
        return _invalid(TDD_INVALID, "green.passed must be true for PASS")
    if _is_blank(_field(green, "testCommand")):
        return _invalid(TDD_INVALID, "green.testCommand required")

    refactor = _field(doc, "refactor")
    if _ps_truthy(_field(refactor, "changed")) and not _ps_truthy(
        _field(refactor, "testsStillPass")
    ):
        return _invalid(TDD_INVALID, "refactor changed but testsStillPass is false")

    return GateResult(exit_code=0, message=TDD_VALID)


def run_tdd_evidence(path: str | Path) -> GateResult:
    if not Path(path).exists():
        return _invalid(TDD_INVALID, "missing TDD evidence file")
    doc, refusal = _load_document(path)
    if refusal:
        return _invalid(TDD_INVALID, refusal)
    return check_tdd_evidence(doc)


# --------------------------------------------------------------------------
# debugging-evidence/v1
# --------------------------------------------------------------------------
def check_debugging_evidence(doc: Any) -> GateResult:
    """Validate a debugging-evidence/v1 document."""
    if _field(doc, "schemaVersion") != DEBUGGING_SCHEMA:
        return _invalid(DEBUGGING_INVALID, "unsupported schemaVersion")

    decision = _field(doc, "decision")
    if _ps_str(decision) not in ALLOWED_DEBUGGING_DECISIONS:
        return _invalid(DEBUGGING_INVALID, "invalid decision")

    if _confidence_out_of_range(_field(doc, "confidence")):
        return _invalid(DEBUGGING_INVALID, "confidence outside range")

    if _ps_str(decision) == "PATCH_READY":
        for field in DEBUGGING_REQUIRED_FIELDS:
            if _is_blank(_field(doc, field)):
                return _invalid(DEBUGGING_INVALID, f"PATCH_READY missing {field}")
        if not _ps_truthy(_field(doc, "hypotheses")):
            return _invalid(DEBUGGING_INVALID, "PATCH_READY requires hypotheses")
        if not _ps_truthy(_field(doc, "experiments")):
            return _invalid(DEBUGGING_INVALID, "PATCH_READY requires experiments")

    return GateResult(
        exit_code=0, message=f"{DEBUGGING_VALID} decision={_ps_str(decision)}"
    )


def run_debugging_evidence(path: str | Path) -> GateResult:
    if not Path(path).exists():
        return _invalid(DEBUGGING_INVALID, "missing debugging evidence")
    doc, refusal = _load_document(path)
    if refusal:
        return _invalid(DEBUGGING_INVALID, refusal)
    return check_debugging_evidence(doc)


KINDS = {
    "review": run_review_evidence,
    "tdd": run_tdd_evidence,
    "debugging": run_debugging_evidence,
}


def main(argv: list[str] | None = None) -> int:
    import argparse

    parser = argparse.ArgumentParser(
        prog="python -m aer.evidence_gates",
        description="Validate an evidence document (port of the check-*-evidence scripts).",
    )
    parser.add_argument("kind", choices=sorted(KINDS))
    parser.add_argument("--path", required=True)
    args = parser.parse_args(argv)

    return KINDS[args.kind](args.path).emit()


if __name__ == "__main__":  # pragma: no cover - exercised via CLI tests
    sys.exit(main())
