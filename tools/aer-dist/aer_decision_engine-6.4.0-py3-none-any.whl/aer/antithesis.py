"""Anti-tautology guard: reject tests that cannot fail on the base revision.

The guard addresses a specific failure mode of LLM-authored changes: a PR adds
tests that assert nothing meaningful, so the new "coverage" passes both before
and after the change. It is deliberately a static, deterministic check over
facts that a caller can collect locally:

* added test functions with no failure signal at all,
* added tests whose only assertions are trivially true,
* edits to protected surfaces (CI, auth, billing, migrations, existing tests).

The module never claims to run the base revision itself. The stronger
base-revision differential check belongs to the caller, which has both SHAs.
"""

from __future__ import annotations

import ast
from dataclasses import dataclass, field
from pathlib import Path

from pathlib import Path

SUPPORTED_ATTACK_CLASSES = {
    "DELETED_REQUIRED_TESTS": "Deletion of baseline test functions or test modules in candidate.",
    "REMOVED_ASSERTIONS": "Removal or reduction of assertion statements from existing tests.",
    "ASSERTION_FREE_TEST": "Added test functions containing zero assertions or failure signals.",
    "TRIVIAL_ASSERTION": "Tautological or trivial assertions (e.g. assert True, 1 == 1, len() >= 0).",
    "SWALLOWED_EXCEPTION": "Silently swallowing exceptions in tests with except: pass.",
    "EMPTY_LOOP_ASSERTION": "Assertions enclosed in loops iterating over empty literals.",
    "UNCONDITIONAL_TEST_SKIP": "Unconditionally skipping or disabling tests with skip decorators or calls.",
}

UNSUPPORTED_ATTACK_CLASSES = {
    "DYNAMIC_ASSERTION_MONKEYPATCHING": "Runtime monkeypatching of pytest/unittest assertion rewrites (deferred to P1 conditional dynamic mutation).",
    "MOCKED_TRUTHY_RETURNS": "Dynamic mock injection returning truthy values requiring runtime dataflow tracing.",
    "COMPLEX_TAUTOLOGICAL_SOLVERS": "Non-trivial mathematical or solver-backed tautologies outside AST pattern scope.",
}

PROTECTED_PATH_SEGMENTS = (
    ".github/workflows/",
    "auth/",
    "billing/",
    "payment/",
    "ledger/",
    "secrets/",
    "secret/",
    "migrations/",
    "session/",
    "sessions/",
)

_TRIVIAL_ASSERTIONS = {
    "True",
    "1",
    "1 == 1",
    "'true'",
    '"true"',
    "bool(True)",
    "not False",
    "1 is 1",
}

_ASSERTION_METHOD_PREFIXES = (
    "assert",
    "fail",
)

_NON_EXITING_ASSERTION_METHODS = {
    # unittest helpers that record/aggregate rather than raise immediately.
    "assertwarns",
    "assertwarnsregex",
    "assertlogs",
    "assertnoLogs".lower(),
}

_CONTEXT_ASSERTION_METHODS = {
    "assertraises",
    "assertraisesregex",
    "assertwarns",
    "assertwarnsregex",
    "assertlogs",
}


@dataclass(frozen=True)
class TautologyFinding:
    kind: str
    location: str
    detail: str
    severity: str = "HIGH"

    def to_dict(self) -> dict[str, str]:
        return {
            "kind": self.kind,
            "location": self.location,
            "detail": self.detail,
            "severity": self.severity,
        }


@dataclass
class AntiTautologyReport:
    status: str = "PASS"
    findings: list[TautologyFinding] = field(default_factory=list)

    def add(self, kind: str, location: str, detail: str, *, blocking: bool = True, severity: str = "HIGH") -> None:
        self.findings.append(TautologyFinding(kind=kind, location=location, detail=detail, severity=severity))
        if blocking:
            if kind == "PROTECTED_SURFACE":
                self.status = "HUMAN_REQUIRED"
            elif severity in ("AMBIGUOUS", "UNSUPPORTED"):
                if self.status != "DENY":
                    self.status = "HUMAN_REQUIRED"
            else:
                self.status = "DENY"

    def to_dict(self) -> dict:
        return {
            "status": self.status,
            "findings": [f.to_dict() for f in self.findings],
        }


def _call_name(node: ast.AST) -> str:
    if isinstance(node, ast.Call):
        func = node.func
        if isinstance(func, ast.Attribute):
            return func.attr
        if isinstance(func, ast.Name):
            return func.id
    return ""


def _calls_in(body: list[ast.stmt]) -> list[ast.Call]:
    calls: list[ast.Call] = []
    for statement in body:
        calls.extend(node for node in ast.walk(statement) if isinstance(node, ast.Call))
    return calls


def _is_assertion_call(call: ast.Call) -> bool:
    name = _call_name(call).lower()
    if not name:
        return False
    return name.startswith(_ASSERTION_METHOD_PREFIXES)


def _assertions_in(body: list[ast.stmt]) -> list[ast.AST]:
    """Return nodes that can make the test fail."""
    assertions: list[ast.AST] = []
    for statement in body:
        if isinstance(statement, ast.Raise):
            assertions.append(statement)
        for node in ast.walk(statement):
            if isinstance(node, ast.Assert):
                assertions.append(node)
            elif isinstance(node, ast.Call) and _is_assertion_call(node):
                if _call_name(node).lower() in _NON_EXITING_ASSERTION_METHODS:
                    continue
                assertions.append(node)
    return assertions


def _unwrap_context_manager(assertion: ast.Call) -> ast.Call | None:
    """For `with self.assertRaises(...)` return the inner body call if present."""
    if _call_name(assertion).lower() not in _CONTEXT_ASSERTION_METHODS:
        return None
    for arg in assertion.args:
        if isinstance(arg, ast.Lambda):
            return None
    return None


def _is_pytest_raises_call(call: ast.Call) -> bool:
    """Detect `pytest.raises(...)` context manager."""
    if isinstance(call.func, ast.Attribute):
        if call.func.attr == "raises" and isinstance(call.func.value, ast.Name) and call.func.value.id == "pytest":
            return True
    return False


def _has_context_assertion(statement: ast.stmt) -> bool:
    if isinstance(statement, (ast.With, ast.AsyncWith)):
        for item in statement.items:
            if isinstance(item.context_expr, ast.Call):
                if _is_assertion_call(item.context_expr) or _is_pytest_raises_call(item.context_expr):
                    return True
    return False


def _trivial_call_arg(assertion: ast.Call) -> bool:
    if _call_name(assertion).lower() in _CONTEXT_ASSERTION_METHODS:
        return False
    if not assertion.args:
        return False
    return ast.dump(assertion.args[0]) in _TRIVIAL_ASSERTIONS


def _is_trivial_isinstance_call(call: ast.Call) -> bool:
    """Distinguish trivial isinstance tautologies (e.g. isinstance(1, int), isinstance(x, object))
    from legitimate dynamic runtime type assertions (e.g. isinstance(result, MyModel)).
    """
    if len(call.args) < 2:
        return True
    first = call.args[0]
    second = call.args[1]
    # Asserting isinstance(anything, object) is tautological in Python 3
    if isinstance(second, ast.Name) and second.id == "object":
        return True
    if isinstance(second, ast.Tuple) and any(isinstance(elt, ast.Name) and elt.id == "object" for elt in second.elts):
        return True
    # Constant literal tested against its own literal type
    if isinstance(first, ast.Constant):
        val = first.value
        if isinstance(second, ast.Name):
            type_name = second.id
            if (
                (isinstance(val, bool) and type_name == "bool")
                or (isinstance(val, int) and not isinstance(val, bool) and type_name == "int")
                or (isinstance(val, str) and type_name == "str")
                or (isinstance(val, float) and type_name == "float")
                or (isinstance(val, bytes) and type_name == "bytes")
            ):
                return True
    return False


def _is_trivial(assertion: ast.AST) -> bool:
    if isinstance(assertion, ast.Raise):
        return False
    if isinstance(assertion, ast.Assert):
        return _node_is_trivial(assertion.test)
    if isinstance(assertion, ast.Call):
        name = _call_name(assertion).lower()
        if name == "fail":
            return False
        if name == "assertisinstance":
            return _is_trivial_isinstance_call(assertion)
        if name == "asserttrue":
            if assertion.args and _node_is_trivial(assertion.args[0]):
                return True
        return _trivial_call_arg(assertion)
    return False


def _node_is_trivial(node: ast.AST) -> bool:
    dumped = ast.dump(node)
    if dumped in _TRIVIAL_ASSERTIONS:
        return True
    if isinstance(node, ast.Constant) and node.value is True:
        return True
    if isinstance(node, ast.BoolOp) and isinstance(node.op, ast.Or):
        if any(_node_is_trivial(val) for val in node.values):
            return True
    if isinstance(node, ast.Call):
        func_name = _call_name(node).lower()
        if func_name == "isinstance":
            return True
    if isinstance(node, ast.Compare) and len(node.ops) == 1:
        op = node.ops[0]
        left = node.left
        right = node.comparators[0]
        if isinstance(op, ast.GtE):
            if (
                isinstance(left, ast.Call)
                and _call_name(left).lower() == "len"
                and isinstance(right, ast.Constant)
                and right.value == 0
            ):
                return True
        elif isinstance(op, ast.LtE):
            if (
                isinstance(right, ast.Call)
                and _call_name(right).lower() == "len"
                and isinstance(left, ast.Constant)
                and left.value == 0
            ):
                return True
        elif isinstance(op, ast.Gt):
            if (
                isinstance(left, ast.Call)
                and _call_name(left).lower() == "len"
                and isinstance(right, ast.Constant)
                and right.value == -1
            ):
                return True
        elif isinstance(op, ast.Lt):
            if (
                isinstance(right, ast.Call)
                and _call_name(right).lower() == "len"
                and isinstance(left, ast.Constant)
                and left.value == -1
            ):
                return True
        left_d = ast.dump(left)
        right_d = ast.dump(right)
        if isinstance(op, ast.Eq) and (left_d == right_d or (isinstance(left, ast.Constant) and isinstance(right, ast.Constant) and left.value == right.value)):
            return True
        if left_d == right_d and left_d in {"1", "True", "'1'", "\"1\""}:
            return True
    return False


def _iter_test_functions(module: ast.AST):
    for node in ast.walk(module):
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and node.name.startswith("test_"):
            yield node
        elif isinstance(node, ast.ClassDef) and node.name.startswith("Test"):
            for child in node.body:
                if isinstance(child, (ast.FunctionDef, ast.AsyncFunctionDef)) and child.name.startswith("test_"):
                    yield child


def _function_has_failure_signal(function: ast.FunctionDef | ast.AsyncFunctionDef) -> tuple[bool, bool]:
    """Return (has_failure_signal, only_trivial_assertions)."""
    direct_assertions = _assertions_in(function.body)
    has_context_assertion = any(_has_context_assertion(statement) for statement in function.body)

    # A `with self.assertRaises(...)` block always carries a failure signal even
    # when its body only raises as expected. This is intentionally not treated
    # as a trivial assertion.
    if has_context_assertion:
        return True, False

    if not direct_assertions:
        return False, False

    return True, all(_is_trivial(assertion) for assertion in direct_assertions)


def _get_decorator_chain(node: ast.AST) -> str:
    if isinstance(node, ast.Call):
        return _get_decorator_chain(node.func)
    if isinstance(node, ast.Attribute):
        parent = _get_decorator_chain(node.value)
        return f"{parent}.{node.attr}" if parent else node.attr
    if isinstance(node, ast.Name):
        return node.id
    return ""


def _check_suppressed_or_empty_assertions(function: ast.FunctionDef | ast.AsyncFunctionDef) -> list[tuple[str, str]]:
    findings = []

    # 1. Unconditional skip decorators
    for dec in function.decorator_list:
        chain = _get_decorator_chain(dec).lower()
        if chain in ("unittest.skip", "pytest.mark.skip", "skip"):
            findings.append(("UNCONDITIONAL_TEST_SKIP", f"test decorated with unconditional skip '{chain}'"))
        elif chain in ("unittest.skipif", "pytest.mark.skipif"):
            if isinstance(dec, ast.Call) and dec.args:
                arg0 = dec.args[0]
                if _node_is_trivial(arg0):
                    findings.append(("UNCONDITIONAL_TEST_SKIP", f"test decorated with trivially-true skipif '{chain}'"))

    # 2. Unconditional skip calls in function body
    for stmt in function.body:
        if isinstance(stmt, ast.Expr) and isinstance(stmt.value, ast.Call):
            call_name = _call_name(stmt.value).lower()
            if call_name in ("skiptest", "skip"):
                findings.append(("UNCONDITIONAL_TEST_SKIP", f"test unconditionally invokes '{call_name}' in body"))

    # 3. Exception handlers and empty loops
    for node in ast.walk(function):
        if isinstance(node, ast.ExceptHandler):
            # Check for except: pass or except Exception: pass
            if len(node.body) == 1 and isinstance(node.body[0], ast.Pass):
                findings.append(("SWALLOWED_EXCEPTION", "test silently swallows exceptions with except: pass"))
        elif isinstance(node, (ast.For, ast.AsyncFor)):
            # Check for assert in loop over empty literal
            if hasattr(node.iter, "elts") and len(node.iter.elts) == 0:
                findings.append(("EMPTY_LOOP_ASSERTION", "assertions inside an empty collection loop will never execute"))
    return findings


def analyze_added_test(source: str, *, location: str = "<added-test>") -> AntiTautologyReport:
    report = AntiTautologyReport()
    try:
        module = ast.parse(source)
    except SyntaxError as exc:
        report.add("UNPARSEABLE", location, f"syntax error: {exc}")
        return report

    tests = list(_iter_test_functions(module))
    if not tests:
        report.add("NO_TEST_FUNCTION", location, "added test file contains no test_ functions or Test classes")
        return report

    for test in tests:
        name = f"{location}::{test.name}"
        suppressed_findings = _check_suppressed_or_empty_assertions(test)
        if suppressed_findings:
            for kind, detail in suppressed_findings:
                report.add(kind, name, detail)
            continue
        has_signal, only_trivial = _function_has_failure_signal(test)
        if not has_signal:
            report.add("ASSERTION_FREE_TEST", name, "test has no assertions and cannot fail")
            continue
        if only_trivial:
            report.add("TRIVIAL_ASSERTION", name, "test only uses trivially-true assertions")
    return report


def is_protected_path(path: str) -> bool:
    normalized = path.replace("\\", "/")
    while normalized.startswith("./"):
        normalized = normalized[2:]
    workflow_relative = normalized.startswith(".github/workflows/")
    if workflow_relative:
        return True
    return any(segment in normalized for segment in PROTECTED_PATH_SEGMENTS) or (
        normalized.startswith("tests/") and normalized.endswith(".py")
    )


def is_collected_test_path(path: str) -> bool:
    """Return True only for files a test runner would collect as tests.

    Helper modules that live under ``tests/`` (for example
    ``tests/golden/support.py``) are intentionally excluded: they are imported
    by tests, not collected by unittest/pytest, so demanding ``test_`` functions
    in them would be a false positive.
    """
    normalized = path.replace("\\", "/")
    while normalized.startswith("./"):
        normalized = normalized[2:]
    if not normalized.endswith(".py"):
        return False
    name = normalized.rsplit("/", 1)[-1]
    return name.startswith("test_") or name.endswith("_test.py")


def is_non_python_test_path(path: str) -> bool:
    """Check whether a path represents a non-Python test file across common programming languages."""
    normalized = path.replace("\\", "/")
    while normalized.startswith("./"):
        normalized = normalized[2:]
    basename = normalized.rsplit("/", 1)[-1].lower()
    ext = basename.rsplit(".", 1)[-1] if "." in basename else ""
    if ext in ("js", "jsx", "ts", "tsx", "go", "rs", "java", "rb", "cpp", "c"):
        if "test" in basename or "spec" in basename or "/test/" in f"/{normalized}/" or "/tests/" in f"/{normalized}/":
            return True
    return False


def analyze_touched_paths(
    paths: list[str],
    *,
    allow_protected: bool = False,
) -> AntiTautologyReport:
    report = AntiTautologyReport()
    for path in paths:
        if not is_protected_path(path):
            continue
        if allow_protected:
            report.add("PROTECTED_SURFACE", path, "protected surface touched (explicitly allowed)", blocking=False)
        else:
            report.add("PROTECTED_SURFACE", path, "changes to protected test/CI/auth paths require human review")
    return report


def analyze_diff_files(
    added_test_files: dict[str, str] | None = None,
    touched_paths: list[str] | None = None,
    *,
    allow_protected: bool = False,
) -> AntiTautologyReport:
    combined = AntiTautologyReport()
    for location, source in (added_test_files or {}).items():
        sub = analyze_added_test(source, location=location)
        combined.findings.extend(sub.findings)
        if sub.status != "PASS":
            combined.status = sub.status
    path_report = analyze_touched_paths(touched_paths or [], allow_protected=allow_protected)
    combined.findings.extend(path_report.findings)
    if path_report.status == "HUMAN_REQUIRED":
        combined.status = "HUMAN_REQUIRED"
    return combined


def load_added_test_files(paths: list[str]) -> dict[str, str]:
    files: dict[str, str] = {}
    for path in paths:
        candidate = Path(path)
        if is_collected_test_path(path) and candidate.is_file():
            files[path] = candidate.read_text(encoding="utf-8-sig")
    return files


def analyze_git_diff(
    base_sha: str,
    *,
    cwd: str = ".",
    allow_protected: bool = False,
) -> AntiTautologyReport:
    """Collect added test files and touched paths from a git diff."""
    import subprocess

    def _git(*args: str) -> list[str]:
        result = subprocess.run(
            ["git", *args],
            cwd=cwd,
            capture_output=True,
            text=True,
            check=True,
        )
        return [line for line in result.stdout.splitlines() if line.strip()]

    # A shallow checkout cannot resolve the base SHA. Fail loudly instead of
    # silently returning an empty diff that would let every test through.
    try:
        subprocess.run(
            ["git", "cat-file", "-e", f"{base_sha}^{{commit}}"],
            cwd=cwd,
            capture_output=True,
            check=True,
        )
    except (subprocess.CalledProcessError, OSError) as exc:
        raise RuntimeError(
            f"base SHA {base_sha} is not present in this checkout; "
            "use actions/checkout with fetch-depth: 0"
        ) from exc

    touched = _git("diff", "--name-only", f"{base_sha}...HEAD")
    added_tests: dict[str, str] = {}
    for path in _git("diff", "--name-only", "--diff-filter=AM", f"{base_sha}...HEAD", "--", "tests"):
        if not is_collected_test_path(path):
            continue
        try:
            added_tests[path] = Path(cwd, path).read_text(encoding="utf-8-sig")
        except OSError:
            continue
    return analyze_diff_files(
        added_test_files=added_tests,
        touched_paths=touched,
        allow_protected=allow_protected,
    )


def analyze_test_diff_integrity(
    base_sources: dict[str, str],
    cand_sources: dict[str, str],
) -> AntiTautologyReport:
    """Compare baseline test files to candidate test files to detect deletions or weakened assertions."""
    report = AntiTautologyReport()

    # 1. Deleted test files
    for path in sorted(base_sources.keys()):
        if path not in cand_sources:
            report.add(
                "DELETED_REQUIRED_TESTS",
                path,
                f"test module '{path}' present in baseline was deleted in candidate",
                severity="AMBIGUOUS",
            )

    # 2. Deletions or assertion weakening within preserved files
    for path, cand_code in sorted(cand_sources.items()):
        base_code = base_sources.get(path)
        if not base_code:
            continue
        try:
            base_mod = ast.parse(base_code)
            cand_mod = ast.parse(cand_code)
        except SyntaxError:
            continue

        base_funcs = {f.name: f for f in _iter_test_functions(base_mod)}
        cand_funcs = {f.name: f for f in _iter_test_functions(cand_mod)}

        for fname, base_func in sorted(base_funcs.items()):
            loc = f"{path}::{fname}"
            if fname not in cand_funcs:
                report.add(
                    "DELETED_REQUIRED_TESTS",
                    loc,
                    f"test function '{fname}' present in baseline was deleted in candidate",
                    severity="AMBIGUOUS",
                )
            else:
                cand_func = cand_funcs[fname]
                base_asserts = len(_assertions_in(base_func.body))
                cand_asserts = len(_assertions_in(cand_func.body))
                if cand_asserts < base_asserts:
                    report.add(
                        "REMOVED_ASSERTIONS",
                        loc,
                        f"test function '{fname}' has fewer assertions ({cand_asserts}) than baseline ({base_asserts})",
                        severity="AMBIGUOUS",
                    )
    return report
