"""Python port of ``scripts/check-requirement-brief.ps1``.

The gate decides whether a natural-language request has been shaped into
something an agent may pick up. Callers surface its single output line to the
user, so both the exit code and the message are part of the contract:

  * ``REQUIREMENT_BRIEF_VALID``            -- exit 0
  * ``REQUIREMENT_BRIEF_INVALID: <reason>`` -- exit 2

Measured behaviour worth keeping in mind (probed against the live script, not
inferred from reading it):

  * a blank / whitespace-only / BOM-only file is **not** "invalid json":
    ``ConvertFrom-Json ""`` returns ``$null`` without throwing, so the
    required-field loop runs first and reports ``missing field: schemaVersion``
  * any non-object document (array, ``null``, string, number) lands on the same
    ``missing field: schemaVersion`` branch for the same reason
  * a *directory* passes ``Test-Path`` and the throwing ``Get-Content -Raw``
    inside the ``try`` becomes ``invalid json``
  * property lookup on a ``ConvertFrom-Json`` object is case-insensitive, so a
    brief whose keys are mis-cased still validates
  * ``[string]$value`` joins arrays with a space, renders ``$true`` as
    ``"True"`` and an integral double as ``"10000000000"`` -- all of which feed
    the "at least 10 characters" gate
  * the item guard is
    ``$items.Count -lt 1 -or -not ($items | Where-Object { non-blank })``.
    ``-not`` applies PowerShell truthiness to the *raw* value, so a single
    ``0`` or ``$false`` item fails even though it survives the blank filter.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from .gate_support import (
    INVALID_JSON,
    GateResult,
    is_blank,
    load_document,
    ps_string,
    ps_truthy,
)

BRIEF_SCHEMA_VERSION = "requirement-brief/v1"
DEFAULT_SCHEMA_PATH = "./schemas/requirement-brief.schema.json"

REQUIRED_FIELDS: tuple[str, ...] = (
    "schemaVersion",
    "status",
    "userIntent",
    "productValue",
    "smallestUsefulSlice",
    "acceptanceCriteria",
    "nonGoals",
    "riskClassification",
    "affectedAreas",
    "suggestedAutomationProfile",
    "openQuestions",
    "recommendedNextStep",
)

STATUSES: tuple[str, ...] = (
    "demand:intake",
    "demand:needs-shaping",
    "demand:review-ready",
    "spec:ready",
)
RISK_CLASSES: tuple[str, ...] = ("low", "medium", "high")
PROFILES: tuple[str, ...] = ("autopilot-low", "autopilot-medium", "human-required")
NEXT_STEPS: tuple[str, ...] = ("create-issue", "continue-shaping", "split", "defer")

LONG_TEXT_FIELDS: tuple[str, ...] = ("userIntent", "productValue", "smallestUsefulSlice")
MIN_LONG_TEXT_LENGTH = 10

ALLOWED_AREAS: tuple[str, ...] = (
    "docs", "frontend", "backend", "router", "billing", "auth", "payment", "runtime",
    "customer data", "workflow", "tests", "tooling", "dashboard", "skills", "security",
    "migrations", "secrets", "sessions", "metering", "production deployment",
)
HIGH_RISK_AREAS: tuple[str, ...] = (
    "payment", "auth", "billing", "runtime", "customer data", "security", "migrations",
    "secrets", "sessions", "metering", "production deployment",
)
AUTOPILOT_LOW_AREAS: tuple[str, ...] = ("docs", "workflow", "tests", "tooling", "dashboard", "skills")


def _properties(doc: Any) -> dict[str, Any]:
    """A case-insensitive view of a parsed document's properties.

    PowerShell resolves ``$obj.Field`` and ``-contains`` case-insensitively, so
    a brief whose keys are mis-cased still validates against the reference.
    """
    if not isinstance(doc, dict):
        return {}
    return {str(key).lower(): value for key, value in doc.items()}


def _get(doc: Any, name: str) -> Any:
    return _properties(doc).get(name.lower())


def _has(doc: Any, name: str) -> bool:
    return name.lower() in _properties(doc)


def _array_values(value: Any) -> list[Any]:
    """``Get-ArrayValues``: ``$null`` -> empty, array -> itself, scalar -> [it]."""
    if value is None:
        return []
    if isinstance(value, list):
        return list(value)
    return [value]


def _items_guard_fails(value: Any) -> bool:
    """Reproduce ``$items.Count -lt 1 -or -not ($items | Where-Object { non-blank })``.

    ``$null -lt 1`` is ``$true``, so a missing field fails before the filter
    runs.  An object value is *not* special-cased here: ``Get-ArrayValues``
    wraps it in ``@()``, and ``.Count`` on the resulting single object is ``1``
    in pwsh 7, which is the host production runs on
    (https://github.com/PowerShell/PowerShell/issues/15021 -- "``.Count`` will
    be ``1`` for non-null objects").  Windows PowerShell 5.1 answers ``$null``
    instead, so a lone object item fails there and passes here; the parity
    matrix therefore carries no such case and
    ``test_single_object_item_is_host_dependent_and_pinned_to_pwsh_7`` pins
    this choice instead.
    """
    items = _array_values(value)
    if len(items) < 1:
        return True
    kept = [item for item in items if not is_blank(item)]
    if not kept:
        return True
    if len(kept) == 1:
        return not ps_truthy(kept[0])
    return False


def _fail(reason: str) -> GateResult:
    return GateResult(2, f"REQUIREMENT_BRIEF_INVALID: {reason}")


def _ci_in(value: Any, allowed: tuple[str, ...]) -> bool:
    """``-in`` / ``-notin`` compare strings case-insensitively."""
    return ps_string(value).lower() in {item.lower() for item in allowed}


def evaluate_requirement_brief(doc: Any) -> GateResult:
    """Validate an already-parsed brief document."""
    for field in REQUIRED_FIELDS:
        if not _has(doc, field):
            return _fail(f"missing field: {field}")

    if ps_string(_get(doc, "schemaVersion")) != BRIEF_SCHEMA_VERSION:
        return _fail("unsupported schemaVersion")
    if not _ci_in(_get(doc, "status"), STATUSES):
        return _fail("invalid status")
    if not _ci_in(_get(doc, "riskClassification"), RISK_CLASSES):
        return _fail("invalid riskClassification")
    if not _ci_in(_get(doc, "suggestedAutomationProfile"), PROFILES):
        return _fail("invalid suggestedAutomationProfile")
    if not _ci_in(_get(doc, "recommendedNextStep"), NEXT_STEPS):
        return _fail("invalid recommendedNextStep")

    for field in LONG_TEXT_FIELDS:
        text = ps_string(_get(doc, field))
        if text.strip() == "" or len(text.strip()) < MIN_LONG_TEXT_LENGTH:
            return _fail(f"{field} must be at least 10 non-whitespace characters")

    if _items_guard_fails(_get(doc, "acceptanceCriteria")):
        return _fail("acceptanceCriteria must contain at least one item")
    if _items_guard_fails(_get(doc, "nonGoals")):
        return _fail("nonGoals must contain at least one item")

    areas = [
        ps_string(item).strip().lower()
        for item in _array_values(_get(doc, "affectedAreas"))
    ]
    areas = [area for area in areas if area]
    if len(areas) < 1:
        return _fail("affectedAreas must contain at least one item")
    allowed = {item.lower() for item in ALLOWED_AREAS}
    for area in areas:
        if area not in allowed:
            return _fail(f"invalid affectedAreas item: {area}")

    high_risk = {item.lower() for item in HIGH_RISK_AREAS}
    touches_high_risk = any(area in high_risk for area in areas)
    risk = ps_string(_get(doc, "riskClassification"))
    profile = ps_string(_get(doc, "suggestedAutomationProfile"))
    if risk.lower() == "high" or touches_high_risk:
        if profile.lower() != "human-required":
            return _fail("high-risk briefs or high-risk affectedAreas must use human-required")

    if ps_string(_get(doc, "status")).lower() == "spec:ready":
        if ps_string(_get(doc, "recommendedNextStep")).lower() != "create-issue":
            return _fail("spec:ready briefs must recommend create-issue")
        questions = _array_values(_get(doc, "openQuestions"))
        if any(not is_blank(question) for question in questions):
            return _fail("spec:ready briefs must not have openQuestions")

    if profile.lower() == "autopilot-low":
        low_allowed = {item.lower() for item in AUTOPILOT_LOW_AREAS}
        for area in areas:
            if area not in low_allowed:
                return _fail(f"autopilot-low cannot be suggested for affected area: {area}")
        if risk.lower() != "low":
            return _fail("autopilot-low requires low riskClassification")

    return GateResult(0, "REQUIREMENT_BRIEF_VALID")


def check_requirement_brief(
    brief_path: str | Path,
    schema_path: str | Path = DEFAULT_SCHEMA_PATH,
) -> GateResult:
    """Load the brief and its schema, then validate."""
    target = Path(brief_path)
    if not target.exists():
        return _fail("missing brief file")
    if not Path(schema_path).exists():
        return _fail("missing schema file")

    doc, refusal = load_document(target)
    if refusal:
        return _fail(refusal)
    return evaluate_requirement_brief(doc)


__all__ = [
    "BRIEF_SCHEMA_VERSION",
    "DEFAULT_SCHEMA_PATH",
    "INVALID_JSON",
    "check_requirement_brief",
    "evaluate_requirement_brief",
]
