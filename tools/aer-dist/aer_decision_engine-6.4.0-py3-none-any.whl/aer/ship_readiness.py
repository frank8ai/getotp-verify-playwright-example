"""Ship-readiness merge gate, ported from `scripts/check-ship-readiness.ps1`.

This is one of the gates that stands between an agent-authored change and an
automatic merge, so it is exactly the kind of policy logic that belongs in the
tested Python engine rather than in a shell script that CI can only exercise
end-to-end.

Contract reproduced exactly from the PowerShell reference:

* stdin-free; takes a single path to a `ship-readiness/v1` document
* prints `SHIP_READINESS_BLOCK: <reason>` and exits 2 on any refusal
* prints `SHIP_READINESS_PASS` and exits 0 when every condition holds

Callers (`run-agent-auto-merge.ps1`, `check-pr-merge-readiness.ps1`,
`check-multi-agent-review-gate.ps1`, `handle-review-comments.ps1`) branch on the
exit code and surface the printed reason, so both the code and the message text
are part of the contract.

Deliberate fidelity choices:

* The reference checks `$doc.checks.<name> -ne $true`, which is also true when
  the field is missing (PowerShell `$null -ne $true`). A missing check is
  therefore a block, not a pass. `_is_true` mirrors that.
* `blockedReasons` is treated as a list and must be empty. The reference uses
  `@(...).Count -gt 0`, so a missing field is 0 elements and does not block.
* Order of evaluation is preserved, because the *first* failing condition
  determines the message the caller shows.
* Reading the file goes through the shared `load_document`, because the
  classification of odd inputs is not obvious: a blank file is *not* invalid
  JSON (`ConvertFrom-Json ""` returns `$null`), while a directory *is*
  (`Test-Path` accepts one and the throwing `Get-Content -Raw` is inside the
  reference's `try`/`catch`). See `core.aer.gate_support`.
"""

from __future__ import annotations

import sys
from pathlib import Path
from typing import Any

from .gate_support import GateResult, load_document

SCHEMA_VERSION = "ship-readiness/v1"
REQUIRED_PROFILE = "autopilot-low"
REQUIRED_RISK = "low"
REQUIRED_QA_SOURCE = "verification-evidence-collection/v1"

# Order matters: the reference evaluates these in sequence and blocks on the
# first one that is not exactly `$true`.
REQUIRED_CHECKS: tuple[str, ...] = (
    "prOpen",
    "notDraft",
    "orchestratorBranch",
    "requiredCheckPassed",
    "noUnresolvedReviewThreads",
    "riskLabelsCompatible",
    "noHighRiskPaths",
    "reviewEvidencePresent",
    "verificationEvidencePresent",
    "rollbackPlanPresent",
    "noForbiddenClaims",
)

EVIDENCE_FIELDS: tuple[str, ...] = ("ciEvidence", "reviewEvidence", "qaEvidence")

PASS_MARKER = "SHIP_READINESS_PASS"


def _block(reason: str) -> GateResult:
    return GateResult(exit_code=2, message=f"SHIP_READINESS_BLOCK: {reason}")


def _is_true(value: Any) -> bool:
    """Mirror PowerShell's `-ne $true`, where missing/null is NOT true."""
    return value is True


def _is_blank(value: Any) -> bool:
    """Mirror `[string]::IsNullOrWhiteSpace` on a coerced string."""
    if value is None:
        return True
    return str(value).strip() == ""


def _ps_str(value: Any) -> str:
    """Render a value the way PowerShell string interpolation does.

    `"decision is $($doc.decision)"` renders `$null` as the empty string, and
    renders booleans as `True`/`False` (capitalised). The blocked message is
    shown to users, so it has to match.
    """
    if value is None:
        return ""
    if value is True:
        return "True"
    if value is False:
        return "False"
    return str(value)


def evaluate_ship_readiness(doc: Any) -> GateResult:
    """Apply every ship-readiness condition; return the first refusal or PASS."""
    if not isinstance(doc, dict):
        # A JSON array or scalar parses fine, so the reference does not report
        # "invalid json" here -- it proceeds and fails on the schema check.
        return _block("unsupported schemaVersion")

    if doc.get("schemaVersion") != SCHEMA_VERSION:
        return _block("unsupported schemaVersion")

    if doc.get("decision") != "PASS":
        return _block(f"decision is {_ps_str(doc.get('decision'))}")

    if doc.get("profile") != REQUIRED_PROFILE:
        return _block(f"profile is {_ps_str(doc.get('profile'))}")

    if doc.get("risk") != REQUIRED_RISK:
        return _block("auto-merge ship readiness requires low risk")

    for field in EVIDENCE_FIELDS:
        evidence = doc.get(field)
        if not isinstance(evidence, dict) or evidence.get("status") != "pass":
            return _block(f"{field} is not pass")

    qa_evidence = doc.get("qaEvidence") or {}
    if str(qa_evidence.get("source") or "") != REQUIRED_QA_SOURCE:
        return _block("qaEvidence source must be verification-evidence-collection/v1")

    if _is_blank(doc.get("rollbackPlan")):
        return _block("rollback plan missing")

    checks = doc.get("checks")
    if not isinstance(checks, dict):
        # The reference guards with `if (-not $doc.checks)`, and an empty
        # hashtable `@{}` is *truthy* in PowerShell while a missing key is not.
        # So only a missing/null/non-object `checks` reports "checks missing";
        # an empty object falls through to the per-check loop below, which
        # correctly blocks with "prOpen is not true".
        return _block("checks missing")

    for check_name in REQUIRED_CHECKS:
        if not _is_true(checks.get(check_name)):
            return _block(f"{check_name} is not true")

    blocked_reasons = doc.get("blockedReasons")
    if blocked_reasons is None:
        # Counter-intuitive but verified against the reference: `@($null).Count`
        # is 1 in PowerShell, so a *missing or null* `blockedReasons` blocks,
        # while an explicit `[]` passes. Do not "fix" this into a truthiness
        # check -- it would let a malformed document through the merge gate.
        return _block("blockedReasons present")
    if isinstance(blocked_reasons, (str, bytes)):
        blocked_reasons = [blocked_reasons]
    if len(blocked_reasons) > 0:
        return _block("blockedReasons present")

    return GateResult(exit_code=0, message=PASS_MARKER)


def check_ship_readiness(path: str | Path) -> GateResult:
    """Load the document at `path` and evaluate it."""
    target = Path(path)
    if not target.exists():
        return _block("missing ship readiness file")

    doc, refusal = load_document(target)
    if refusal:
        return _block(refusal)

    return evaluate_ship_readiness(doc)


def main(argv: list[str] | None = None) -> int:
    import argparse

    parser = argparse.ArgumentParser(
        prog="python -m aer.ship_readiness",
        description="Ship-readiness merge gate (port of check-ship-readiness.ps1).",
    )
    parser.add_argument("--ship-readiness-path", required=True)
    args = parser.parse_args(argv)

    return check_ship_readiness(args.ship_readiness_path).emit()


if __name__ == "__main__":  # pragma: no cover - exercised via CLI tests
    sys.exit(main())
