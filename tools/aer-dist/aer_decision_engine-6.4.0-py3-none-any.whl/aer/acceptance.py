"""Acceptance-to-Evidence 1:1 Binding Verifier (AWR contract inspired).

Enforces the AWR completion rule:
Every declared acceptance criterion must be backed by a valid, verified evidence record
(command executed with exit code 0, artifact generated, or test passed).
Any unmapped or failing criterion blocks completion (verdict: BLOCKED).
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any


class AcceptanceVerificationError(RuntimeError):
    """Raised when acceptance criteria binding fails."""


@dataclass(frozen=True)
class AcceptanceBindingReport:
    is_fully_bound: bool
    total_criteria: int
    bound_count: int
    unbound_criteria: list[str]
    evidence_keys_used: list[str]
    missing_evidence_keys: list[str]

    def to_dict(self) -> dict[str, Any]:
        return {
            "isFullyBound": self.is_fully_bound,
            "totalCriteria": self.total_criteria,
            "boundCount": self.bound_count,
            "unboundCriteria": list(self.unbound_criteria),
            "evidenceKeysUsed": list(self.evidence_keys_used),
            "missingEvidenceKeys": list(self.missing_evidence_keys),
        }


def verify_acceptance_bindings(
    acceptance_criteria: list[str],
    evidence_bindings: list[dict[str, Any]],
    available_evidence_keys: set[str] | list[str],
) -> AcceptanceBindingReport:
    """Verify that every acceptance criterion is bound 1:1 to a valid evidence key.

    evidence_bindings structure:
    [
        {"criterion": "All unit tests pass", "evidence": ["test-suite::exec"]}
    ]
    """
    avail_set = set(available_evidence_keys)
    unbound: list[str] = []
    missing_keys: list[str] = []
    used_keys: list[str] = []
    bound_count = 0

    # Map criterion -> evidence keys
    mapping: dict[str, list[str]] = {}
    for binding in evidence_bindings:
        crit = str(binding.get("criterion", "")).strip()
        ev_list = [str(k).strip() for k in binding.get("evidence", []) if str(k).strip()]
        if crit:
            mapping[crit] = ev_list

    for criterion in acceptance_criteria:
        crit_clean = criterion.strip()
        keys = mapping.get(crit_clean, [])
        if not keys:
            unbound.append(crit_clean)
            continue

        # Check if all referenced evidence keys actually exist
        valid = True
        for k in keys:
            if k not in avail_set:
                missing_keys.append(k)
                valid = False
            else:
                used_keys.append(k)

        if valid:
            bound_count += 1
        else:
            unbound.append(crit_clean)

    is_fully_bound = (bound_count == len(acceptance_criteria)) and (len(missing_keys) == 0)

    return AcceptanceBindingReport(
        is_fully_bound=is_fully_bound,
        total_criteria=len(acceptance_criteria),
        bound_count=bound_count,
        unbound_criteria=unbound,
        evidence_keys_used=list(dict.fromkeys(used_keys)),
        missing_evidence_keys=list(dict.fromkeys(missing_keys)),
    )
