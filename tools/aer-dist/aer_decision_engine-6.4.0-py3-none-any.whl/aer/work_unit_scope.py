"""Python port of ``scripts/check-work-unit-scope.ps1``.

The gate answers "does this change stay inside the slice it declared?". It has
two distinct success lines and one failure line:

  * ``WORK_UNIT_SCOPE_VALID decision=<decision>``                    -- exit 0
  * ``WORK_UNIT_SCOPE_VALID changedFiles=.. diffLines=.. changedFilePaths=..``
  * ``WORK_UNIT_SCOPE_INVALID: <reason>``                            -- exit 2

Measured behaviour (probed against the live script, not inferred):

  * a blank / whitespace-only / BOM-only file, or any non-object document, is
    ``unsupported schemaVersion`` -- the schemaVersion check runs *before* any
    field lookup, so ``$null -ne "work-unit-decomposition/v1"`` is true
  * a *directory* is ``invalid json``
  * a ``decision`` other than ``READY`` is a *success*, and the decision is
    echoed back verbatim (a missing decision prints ``decision=``)
  * the per-unit thresholds are strict ``-gt``: 8 files and 300 lines pass for
    ``autopilot-low``, 9 and 301 do not
  * for changed paths the autopilot-low prefix check runs *before* the
    forbiddenPaths and ownedPaths checks, so ``src/a.md`` reports the
    product/runtime prefix rather than "outside ownedPaths"
  * every path comparison is case-insensitive and normalises ``\\`` to ``/``
    and a leading ``./``
"""

from __future__ import annotations

from pathlib import Path
from typing import Any, Iterable

from .gate_support import GateResult, is_blank, load_document, ps_string

WORK_UNIT_SCHEMA_VERSION = "work-unit-decomposition/v1"

AUTOPILOT_LOW_MAX_FILES = 8
AUTOPILOT_LOW_MAX_LINES = 300
AUTOPILOT_MEDIUM_MAX_FILES = 20
AUTOPILOT_MEDIUM_MAX_LINES = 800

RESTRICTED_PREFIXES: tuple[str, ...] = ("apps/", "packages/", "src/")


def _fail(reason: str) -> GateResult:
    return GateResult(2, f"WORK_UNIT_SCOPE_INVALID: {reason}")


def _get(doc: Any, name: str) -> Any:
    """Case-insensitive property lookup, matching PowerShell's own resolution."""
    if not isinstance(doc, dict):
        return None
    lowered = name.lower()
    for key, value in doc.items():
        if str(key).lower() == lowered:
            return value
    return None


def _units(doc: Any) -> list[Any]:
    """``@($doc.workUnits)`` -- one item for a scalar, none for a missing field."""
    value = _get(doc, "workUnits")
    if value is None:
        return []
    if isinstance(value, list):
        return list(value)
    return [value]


def _unit_profile(unit: Any) -> str:
    if not isinstance(unit, dict):
        return ""
    return ps_string(_get(unit, "profile"))


def _unit_paths(unit: Any, name: str) -> list[Any]:
    """``$unit.<name>`` flattened the way ``+= @(...)`` flattens it."""
    if not isinstance(unit, dict):
        return []
    value = _get(unit, name)
    if value is None:
        return [None]
    if isinstance(value, list):
        return list(value)
    return [value]


def normalize_repo_path(path: Any) -> str:
    """``Normalize-RepoPath``: forward slashes, no leading ``./`` or ``/``."""
    normalized = ps_string(path).replace("\\", "/").strip()
    while normalized.startswith("./"):
        normalized = normalized[2:]
    return normalized.lstrip("/")


def _path_under_prefix(changed_path: Any, prefix: Any) -> bool:
    """``Test-PathUnderPrefix``: the path equals the prefix or sits beneath it."""
    changed = normalize_repo_path(changed_path)
    prefix_path = normalize_repo_path(prefix).rstrip("/")
    if prefix_path == "":
        return False
    return changed.lower() == prefix_path.lower() or changed.lower().startswith(prefix_path.lower() + "/")


def _path_contains_segment_or_prefix(changed_path: Any, forbidden_path: Any) -> bool:
    """``Test-PathContainsSegmentOrPrefix``: equal, beneath, above, or anywhere inside."""
    changed = normalize_repo_path(changed_path)
    forbidden = normalize_repo_path(forbidden_path).strip("/")
    if forbidden == "":
        return False
    changed_lower = changed.lower()
    forbidden_lower = forbidden.lower()
    if changed_lower == forbidden_lower:
        return True
    if changed_lower.startswith(forbidden_lower + "/"):
        return True
    if changed_lower.endswith("/" + forbidden_lower):
        return True
    return f"/{forbidden_lower}/" in changed_lower


def evaluate_work_unit_scope(
    doc: Any,
    *,
    changed_files: int = 0,
    diff_lines: int = 0,
    changed_file_paths: Iterable[Any] = (),
) -> GateResult:
    """Validate an already-parsed work-unit document."""
    if ps_string(_get(doc, "schemaVersion")).lower() != WORK_UNIT_SCHEMA_VERSION:
        return _fail("unsupported schemaVersion")

    decision = _get(doc, "decision")
    if ps_string(decision).lower() != "ready":
        return GateResult(0, f"WORK_UNIT_SCOPE_VALID decision={ps_string(decision)}")

    for unit in _units(doc):
        profile = _unit_profile(unit).lower()
        if profile == "autopilot-low":
            if changed_files > AUTOPILOT_LOW_MAX_FILES:
                return _fail("autopilot-low changed files exceed 8")
            if diff_lines > AUTOPILOT_LOW_MAX_LINES:
                return _fail("autopilot-low diff lines exceed 300")
        elif profile == "autopilot-medium":
            if changed_files > AUTOPILOT_MEDIUM_MAX_FILES:
                return _fail("autopilot-medium changed files exceed 20")
            if diff_lines > AUTOPILOT_MEDIUM_MAX_LINES:
                return _fail("autopilot-medium diff lines exceed 800")

    normalized = [
        normalize_repo_path(path)
        for path in changed_file_paths
        if not is_blank(path)
    ]

    if normalized:
        owned_paths: list[Any] = []
        forbidden_paths: list[Any] = []
        has_autopilot_low_unit = False
        for unit in _units(doc):
            owned_paths.extend(_unit_paths(unit, "ownedPaths"))
            forbidden_paths.extend(_unit_paths(unit, "forbiddenPaths"))
            if _unit_profile(unit).lower() == "autopilot-low":
                has_autopilot_low_unit = True

        for changed_path in normalized:
            if has_autopilot_low_unit:
                for restricted in RESTRICTED_PREFIXES:
                    if _path_under_prefix(changed_path, restricted):
                        return _fail(
                            "autopilot-low changed file touches product/runtime "
                            f"prefix {restricted}: {changed_path}"
                        )

            for forbidden_path in forbidden_paths:
                if _path_contains_segment_or_prefix(changed_path, forbidden_path):
                    return _fail(
                        f"changed file matches forbiddenPaths entry {ps_string(forbidden_path)}: "
                        f"{changed_path}"
                    )

            if not any(_path_under_prefix(changed_path, owned) for owned in owned_paths):
                return _fail(f"changed file outside ownedPaths: {changed_path}")

    return GateResult(
        0,
        "WORK_UNIT_SCOPE_VALID "
        f"changedFiles={changed_files} diffLines={diff_lines} "
        f"changedFilePaths={len(normalized)}",
    )


def check_work_unit_scope(
    work_unit_path: str | Path,
    *,
    changed_files: int = 0,
    diff_lines: int = 0,
    changed_file_paths: Iterable[Any] = (),
) -> GateResult:
    """Load the work-unit document and validate it."""
    target = Path(work_unit_path)
    if not target.exists():
        return _fail("missing work-unit file")

    doc, refusal = load_document(target)
    if refusal:
        return _fail(refusal)
    return evaluate_work_unit_scope(
        doc,
        changed_files=changed_files,
        diff_lines=diff_lines,
        changed_file_paths=changed_file_paths,
    )


__all__ = [
    "WORK_UNIT_SCHEMA_VERSION",
    "check_work_unit_scope",
    "evaluate_work_unit_scope",
    "normalize_repo_path",
]
