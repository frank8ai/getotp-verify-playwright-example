"""Log Distiller: Distill verbose test/build logs into high-signal Failure Cards.

Reduces large error output (~10k-50k tokens) down to ~200-500 tokens containing:
- exact failing test / command
- root exception and message
- top frame / location of failure
- deterministic fingerprint for failure clustering and deduplication
"""

from __future__ import annotations

import hashlib
import re
from dataclasses import dataclass, field
from typing import Any


@dataclass(frozen=True)
class DistilledFailure:
    test_id: str
    error_type: str
    error_message: str
    location: str
    traceback_tail: list[str] = field(default_factory=list)
    fingerprint: str = ""

    def to_dict(self) -> dict[str, Any]:
        return {
            "testId": self.test_id,
            "errorType": self.error_type,
            "errorMessage": self.error_message,
            "location": self.location,
            "tracebackTail": self.traceback_tail,
            "fingerprint": self.fingerprint,
        }


@dataclass
class FailureCard:
    total_failures: int = 0
    failures: list[DistilledFailure] = field(default_factory=list)
    summary_digest: str = ""

    def to_dict(self) -> dict[str, Any]:
        return {
            "totalFailures": self.total_failures,
            "summaryDigest": self.summary_digest,
            "failures": [f.to_dict() for f in self.failures],
        }

    def render_markdown(self) -> str:
        lines = [
            f"### Failure Card (Total: {self.total_failures})",
            f"**Summary Digest**: {self.summary_digest}",
            "",
        ]
        for idx, f in enumerate(self.failures, start=1):
            lines.extend([
                f"#### {idx}. {f.test_id or 'Command Failure'}",
                f"- **Location**: {f.location}",
                f"- **Error**: {f.error_type}: {f.error_message}",
                f"- **Fingerprint**: {f.fingerprint}",
            ])
            if f.traceback_tail:
                lines.append("```text")
                lines.extend(f.traceback_tail)
                lines.append("```")
            lines.append("")
        return "\n".join(lines).strip()


_PYTEST_FAIL_HEADER_RE = re.compile(r"_{4,}\s+([^\s]+)\s+_{4,}")
_TRACEBACK_FILE_RE = re.compile(r'File "([^"]+)", line (\d+), in (\w+)')
_EXCEPTION_LINE_RE = re.compile(r"^([A-Z][A-Za-z0-9_.]*(?:Error|Exception|AssertionError)):?\s*(.*)$")


def distill_pytest_log(raw_log: str, *, max_failures: int = 5) -> FailureCard:
    """Extract structured failures from pytest output."""
    failures: list[DistilledFailure] = []
    lines = raw_log.splitlines()

    # Split into failure sections
    current_test_id = ""
    current_block: list[str] = []
    in_failures = False

    for line in lines:
        if "=== FAILURES ===" in line or "=== ERRORS ===" in line:
            in_failures = True
            continue
        if in_failures and re.match(r"^===+ .* ===+$", line):
            if current_test_id and current_block:
                f = _parse_failure_block(current_test_id, current_block)
                if f:
                    failures.append(f)
                current_test_id = ""
                current_block = []
            break

        header_match = _PYTEST_FAIL_HEADER_RE.search(line)
        if header_match:
            if current_test_id and current_block:
                f = _parse_failure_block(current_test_id, current_block)
                if f:
                    failures.append(f)
            current_test_id = header_match.group(1).strip()
            current_block = []
        elif current_test_id:
            current_block.append(line)

    if current_test_id and current_block:
        f = _parse_failure_block(current_test_id, current_block)
        if f:
            failures.append(f)

    # If no standard pytest failure blocks matched, fallback to generic trace extract
    if not failures:
        generic = _parse_generic_log(lines)
        if generic:
            failures.append(generic)

    failures = failures[:max_failures]
    summary_src = "|".join(f"{f.test_id}:{f.error_type}:{f.location}" for f in failures)
    summary_digest = "sha256:" + hashlib.sha256(summary_src.encode("utf-8")).hexdigest()[:16]

    return FailureCard(
        total_failures=len(failures),
        failures=failures,
        summary_digest=summary_digest,
    )


def _parse_failure_block(test_id: str, lines: list[str]) -> DistilledFailure | None:
    location = "unknown"
    error_type = "AssertionError"
    error_message = ""
    tail: list[str] = []

    # Search for files and exceptions
    for line in lines:
        file_match = _TRACEBACK_FILE_RE.search(line)
        if file_match:
            location = f"{file_match.group(1)}:{file_match.group(2)} ({file_match.group(3)})"

        exc_match = _EXCEPTION_LINE_RE.match(line.strip())
        if exc_match:
            error_type = exc_match.group(1)
            error_message = exc_match.group(2).strip()
        elif line.strip().startswith("E   "):
            err_body = line.strip()[4:].strip()
            if not error_message:
                error_message = err_body
            if ":" in err_body and not exc_match:
                possible_type, possible_msg = err_body.split(":", 1)
                if possible_type.endswith(("Error", "Exception")):
                    error_type = possible_type.strip()
                    error_message = possible_msg.strip()

    # Capture last 6 informative lines
    tail_candidates = [l for l in lines if l.strip() and not l.startswith("---")]
    tail = tail_candidates[-6:] if len(tail_candidates) > 6 else tail_candidates

    fp_src = f"{test_id}|{error_type}|{location}|{error_message}"
    fingerprint = "fp:" + hashlib.sha256(fp_src.encode("utf-8")).hexdigest()[:16]

    return DistilledFailure(
        test_id=test_id,
        error_type=error_type,
        error_message=error_message,
        location=location,
        traceback_tail=tail,
        fingerprint=fingerprint,
    )


def _parse_generic_log(lines: list[str]) -> DistilledFailure | None:
    location = "unknown"
    error_type = "Error"
    error_message = ""
    tail: list[str] = []

    for line in lines:
        file_match = _TRACEBACK_FILE_RE.search(line)
        if file_match:
            location = f"{file_match.group(1)}:{file_match.group(2)} ({file_match.group(3)})"
        exc_match = _EXCEPTION_LINE_RE.match(line.strip())
        if exc_match:
            error_type = exc_match.group(1)
            error_message = exc_match.group(2).strip()

    if not error_message and not location != "unknown":
        return None

    tail = [l for l in lines[-10:] if l.strip()]
    fp_src = f"generic|{error_type}|{location}|{error_message}"
    fingerprint = "fp:" + hashlib.sha256(fp_src.encode("utf-8")).hexdigest()[:16]

    return DistilledFailure(
        test_id="generic",
        error_type=error_type,
        error_message=error_message or "Unknown failure",
        location=location,
        traceback_tail=tail,
        fingerprint=fingerprint,
    )


def distill_failure_summary(text: str) -> str:
    """Produce a concise Failure Card string from any raw error text or log."""
    card = distill_pytest_log(text)
    return card.render_markdown()
