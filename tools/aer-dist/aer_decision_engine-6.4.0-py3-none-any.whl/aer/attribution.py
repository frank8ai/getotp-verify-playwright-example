"""Differential attribution between a trusted baseline and a candidate run."""

from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Any, Iterable


@dataclass(frozen=True)
class CandidateSurface:
    test_ids: tuple[str, ...] = ()
    failures: tuple[dict[str, Any], ...] = ()

    @classmethod
    def from_mapping(cls, value: dict[str, Any] | None) -> "CandidateSurface":
        value = value or {}
        return cls(
            test_ids=tuple(str(item) for item in value.get("testIds") or ()),
            failures=tuple(value.get("failures") or ()),
        )


def build_evidence(
    baseline: dict[str, Any],
    candidate: CandidateSurface | dict[str, Any] | None,
    *,
    candidate_sha: str,
    environment_digest: str,
    modified_files: Iterable[str] = (),
    protected_surface: Iterable[str] = (),
    secrets_found: bool = False,
    scan_engine: str = "aer",
    timestamp: str = "",
    allow_protected: bool = False,
) -> dict[str, Any]:
    """Return verification evidence using the same verdict equation as RVCE v2."""
    candidate = (
        candidate
        if isinstance(candidate, CandidateSurface)
        else CandidateSurface.from_mapping(candidate)
    )

    base_test_ids = tuple(str(item) for item in baseline.get("testIds") or ())
    removed_test_ids = [
        test_id for test_id in base_test_ids if test_id not in candidate.test_ids
    ]

    base_failures = {
        str(failure["testId"]): failure
        for failure in baseline.get("failures") or ()
        if failure.get("testId")
    }
    new_failures: list[dict[str, Any]] = []
    candidate_failure_ids: list[str] = []
    for failure in candidate.failures:
        test_id = str(failure.get("testId") or "")
        if not test_id:
            continue
        candidate_failure_ids.append(test_id)
        baseline_failure = base_failures.get(test_id)
        if baseline_failure is None:
            new_failures.append(dict(failure))
        elif baseline_failure.get("fingerprint") != failure.get("fingerprint"):
            new_failures.append({**failure, "reason": "FINGERPRINT_MODIFIED"})

    resolved_failures = [
        baseline_failure
        for test_id, baseline_failure in base_failures.items()
        if test_id not in candidate_failure_ids
    ]

    environment_equivalent = (
        str(baseline.get("environmentDigest") or "") == environment_digest
    )
    surface_intact = not removed_test_ids
    protected_touched = _protected_touched(modified_files, protected_surface)

    if not environment_equivalent:
        verdict = "BLOCKED"
    elif protected_touched and not allow_protected:
        verdict = "HUMAN_REQUIRED"
    elif not surface_intact or new_failures or secrets_found:
        verdict = "FAIL"
    else:
        verdict = "PASS"

    return {
        "schemaVersion": "verification-evidence/v2",
        "runId": baseline.get("runId", ""),
        "candidateSha": candidate_sha,
        "timestamp": timestamp,
        "verdict": verdict,
        "causalAttribution": {
            "failureDeltaCount": len(new_failures),
            "newFailures": new_failures,
            "resolvedFailures": resolved_failures,
            "surfaceDelta": {
                "baseCount": len(base_test_ids),
                "candidateCount": len(candidate.test_ids),
                "removedTestIds": removed_test_ids,
                "isSurfaceIntact": surface_intact,
            },
            "environmentDelta": {
                "baseDigest": str(baseline.get("environmentDigest") or ""),
                "candidateDigest": environment_digest,
                "isEquivalent": environment_equivalent,
            },
        },
        "scopeCheck": {
            "isScopeClean": not protected_touched,
            "protectedSurfaceTouched": protected_touched,
            "modifiedFiles": [str(path).replace("\\", "/") for path in modified_files],
        },
        "securityCheck": {
            "secretsFound": secrets_found,
            "scanEngine": scan_engine,
        },
    }


def _protected_touched(
    modified_files: Iterable[str],
    protected_surface: Iterable[str],
) -> bool:
    for modified in modified_files:
        normalized = str(modified).replace("\\", "/")
        for pattern in protected_surface:
            if _matches_glob(normalized, str(pattern)):
                return True
    return False


def _matches_glob(path: str, pattern: str) -> bool:
    """Match the manifest's two wildcard forms: ** and *."""
    regex: list[str] = []
    index = 0
    while index < len(pattern):
        char = pattern[index]
        if char == "*" and index + 1 < len(pattern) and pattern[index + 1] == "*":
            regex.append(".*")
            index += 2
            continue
        if char == "*":
            regex.append("[^/]*")
        else:
            regex.append(re.escape(char))
        index += 1
    return bool(re.fullmatch("".join(regex), path))
