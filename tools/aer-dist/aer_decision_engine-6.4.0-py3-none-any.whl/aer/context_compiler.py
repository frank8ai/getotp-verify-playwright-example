"""L0/L1 Budget-Driven Context Compiler (AWR contract inspired).

L0 Context (Bootstrap):
- Orientation only (Goals, Global Rules, Work Items Summary).
- Strict Token Budget (default 1,000 tokens).
- Explicitly incomplete for execution (execution_context_complete: False).

L1 Context (Task Execution):
- Task-scoped execution pack (Goal, Acceptance Criteria, Dependencies, Latest Checkpoint, Code Context).
- Token Budget (default 5,000 tokens).
- Fail-closed: raises BudgetExceededError when mandatory facts exceed budget.
"""

from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from .checkpoint import SessionCheckpoint


class ContextError(RuntimeError):
    """Base error for context compilation."""


class BudgetExceededError(ContextError):
    """Raised when hard facts exceed the specified token budget (fail-closed)."""

    def __init__(self, required_tokens: int, budget: int):
        super().__init__(
            f"Hard context facts ({required_tokens} tokens) exceed budget ({budget} tokens). "
            "Increase budget or scope task explicitly; never silently truncate facts."
        )
        self.required_tokens = required_tokens
        self.budget = budget


def estimate_tokens(text: str) -> int:
    """Fast, conservative token estimate (~4 characters per token for English/code)."""
    if not text:
        return 0
    # Add safety margin for non-ascii / formatting tokens
    ascii_len = sum(1 for c in text if ord(c) < 128)
    non_ascii_len = len(text) - ascii_len
    return int((ascii_len / 3.8) + (non_ascii_len * 1.2)) + 1


@dataclass(frozen=True)
class ContextPacket:
    level: str  # "L0" or "L1"
    token_estimate: int
    budget: int
    rendered_context: str
    completeness: dict[str, Any]
    work_key: str = ""
    timestamp: str = ""
    schema_version: str = "context-packet/v1"

    @property
    def context_hash(self) -> str:
        digest = hashlib.sha256(self.rendered_context.encode("utf-8")).hexdigest()
        return f"sha256:{digest}"

    def to_dict(self) -> dict[str, Any]:
        ts = self.timestamp or datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")
        return {
            "schemaVersion": self.schema_version,
            "level": self.level,
            "workKey": self.work_key,
            "tokenEstimate": self.token_estimate,
            "budget": self.budget,
            "renderedContext": self.rendered_context,
            "completeness": dict(self.completeness),
            "timestamp": ts,
            "metadata": {
                "contextHash": self.context_hash,
            },
        }


def compile_l0_context(
    *,
    project_goal: str,
    rules: list[str],
    work_items: list[dict[str, str]],
    budget: int = 1000,
) -> ContextPacket:
    """Compile orientation-only L0 context (target < 1,000 tokens)."""
    lines = [
        "# Project Orientation (L0 Bootstrap Context)",
        "",
        f"## Goal\n{project_goal.strip()}",
        "",
        "## Core Engineering Rules",
    ]
    for rule in rules:
        lines.append(f"- {rule.strip()}")

    lines.append("")
    lines.append("## Planned Work Items")
    for item in work_items:
        wid = item.get("id", "UNKNOWN")
        title = item.get("title", "")
        status = item.get("status", "planned")
        lines.append(f"- [{status}] {wid}: {title}")

    lines.append("")
    lines.append("> NOTE: L0 context is for orientation only; request L1 task context before execution.")
    rendered = "\n".join(lines)
    tokens = estimate_tokens(rendered)

    if tokens > budget:
        raise BudgetExceededError(required_tokens=tokens, budget=budget)

    return ContextPacket(
        level="L0",
        token_estimate=tokens,
        budget=budget,
        rendered_context=rendered,
        completeness={
            "complete": True,
            "missing": [],
            "execution_context_complete": False,
        },
    )


def compile_l1_context(
    *,
    work_item: dict[str, Any],
    project_goal: str,
    rules: list[str],
    latest_checkpoint: SessionCheckpoint | None = None,
    code_snippets: list[tuple[str, str]] | None = None,
    causal_slice: dict[str, Any] | None = None,
    raw_failure_log: str | None = None,
    budget: int = 5000,
) -> ContextPacket:
    """Compile task execution L1 context with mandatory facts and fail-closed budget check."""
    wid = work_item.get("id", "UNKNOWN")
    title = work_item.get("title", "")
    acceptance = work_item.get("acceptance", [])
    dependencies = work_item.get("dependencies", [])

    lines = [
        f"# Task Execution Context (L1): [{wid}] {title}",
        "",
        f"## Project Goal Reference\n{project_goal.strip()}",
        "",
        "## Acceptance Criteria (Hard Verification Gate)",
    ]
    for ac in acceptance:
        lines.append(f"- [ ] {ac.strip()}")

    if dependencies:
        lines.append("")
        lines.append("## Dependencies")
        for dep in dependencies:
            lines.append(f"- Dependency: {dep}")

    if causal_slice:
        lines.append("")
        lines.append("## Causal Execution Slice (High-Signal Failure Evidence)")
        try:
            from harness.slicing.extractor import BackwardSliceExtractor
            lines.append(BackwardSliceExtractor().render_markdown(causal_slice))
        except Exception:
            lines.append(f"```json\n{json.dumps(causal_slice, indent=2)}\n```")
    elif raw_failure_log:
        lines.append("")
        lines.append("## Raw Failure Evidence")
        try:
            from core.aer.distiller import distill_failure_summary
            lines.append(distill_failure_summary(raw_failure_log))
        except Exception:
            lines.append(f"```\n{raw_failure_log[-2000:]}\n```")

    if latest_checkpoint:
        lines.append("")
        lines.append("## Resume from Session Checkpoint")
        lines.append(f"- Prior Digest: {latest_checkpoint.digest}")
        lines.append(f"- Immediate Next Action: {latest_checkpoint.next_action}")
        if latest_checkpoint.open_loops:
            lines.append("- Open Loops:")
            for loop in latest_checkpoint.open_loops:
                lines.append(f"  * {loop}")

    lines.append("")
    lines.append("## Applicable Rules")
    for r in rules:
        lines.append(f"- {r.strip()}")

    if code_snippets:
        lines.append("")
        lines.append("## Focused Code References")
        for filepath, snippet in code_snippets:
            lines.append(f"### {filepath}")
            lines.append("```")
            lines.append(snippet.strip())
            lines.append("```")

    rendered = "\n".join(lines)
    tokens = estimate_tokens(rendered)

    if tokens > budget:
        raise BudgetExceededError(required_tokens=tokens, budget=budget)

    missing = []
    if not acceptance:
        missing.append("acceptance_criteria")

    return ContextPacket(
        level="L1",
        work_key=wid,
        token_estimate=tokens,
        budget=budget,
        rendered_context=rendered,
        completeness={
            "complete": len(missing) == 0,
            "missing": missing,
            "execution_context_complete": True,
        },
    )
