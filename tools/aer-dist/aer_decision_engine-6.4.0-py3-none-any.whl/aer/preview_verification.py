"""Port of ``run-preview-verification.ps1``.

Runs the preview create / smoke / teardown commands and folds their exit codes
and output into one ``verification-evidence/v1`` document, which the evidence
collector then reads.  ``PASS`` is exit 0, everything else is exit 2, and a
command that cannot be *started* at all is exit 1 with the reason on stderr and
no document on stdout.

The reference shells out, so most of what it contracts is about the hand-off.
Four things are load-bearing and were measured rather than read.

**The summary keeps the last 1200 UTF-16 code units.**  ``New-Summary`` joins
stdout and stderr with ``\\n`` -- stdout first, whatever order the child wrote
them in -- trims, and then calls ``Substring($text.Length - 1200)``.  That is
the *tail*, not the head, and ``Length`` counts UTF-16 code units, so a cut can
land between the halves of an astral character.  It then does: the reference
writes the lone surrogate to its stdout and the host encoder replaces it with
U+FFFD.  Measured with 601 emoji and an odd number of trailing bytes, the
summary came back starting ``'\\ufffd\\U0001F600\\U0001F600'`` and 1200 units
long.  :func:`summarise` slices the UTF-16 encoding and decodes with
``errors="replace"``, which reproduces both halves of that.

**Quoted commands are broken, and the port reproduces the breakage.**  The
reference escapes with ``$Command.Replace('"', '\\"')`` before handing the
string to ``cmd.exe /d /s /c``.  ``\\"`` is the C runtime's escape, not cmd's:
``cmd /s /c`` strips the outer quotes and takes the rest verbatim, so the
backslashes survive as literal characters.  Measured: ``echo "hello world"``
produces the summary ``\\"hello world\\"``, and ``call "C:\\dir\\x.cmd"`` fails
with *is not recognized as an internal or external command*.  This is a defect,
not a contract -- but the shell original is still what the orchestrator runs
until that orchestrator is ported too, so the port matches it instead of
silently changing which commands pass.  See :func:`_shell_argv`.

**The reference deadlocks on a command that fills the stderr pipe.**  It calls
``StandardOutput.ReadToEnd()`` and only then ``StandardError.ReadToEnd()``, so a
child that writes more than a pipe buffer to stderr blocks forever and takes the
parent with it.  Measured: 4000 lines on stderr was still hung after 25s, while
the same volume on stdout finished.  Reproducing a hang is not worth preserving,
so the port drains both streams concurrently and
:func:`_run_command` documents the divergence.

**Decoding is UTF-8 with replacement.**  ``ProcessStartInfo`` without
``StandardOutputEncoding`` uses .NET's console encoding; measured on this host
it decodes valid UTF-8 correctly and turns stray high bytes into U+FFFD
(``caf\\xe9`` became ``caf\\ufffd``).  The port asks for the same thing
explicitly, which is also what the Linux runner would do.

Two ways the reference dies, both modelled
------------------------------------------

``-WorkingDirectory`` that does not exist.  ``Process.Start`` throws
``Win32Exception: The directory name is invalid`` and the script exits 1 with an
empty stdout -- before any check is recorded, so nothing is written either.

``-OutputPath`` that cannot be written.  A directory, or a denied path, makes
``Set-Content`` throw under ``$ErrorActionPreference = "Stop"``.  The document
is written *before* it is printed, so this too is exit 1 with an empty stdout.
Measured against a directory: ``Set-Content : Access to the path ... is denied.``

What is deliberately *not* modelled
-----------------------------------

``ConvertTo-Json``'s exact bytes.  PowerShell 5.1 indents with four spaces,
aligns array elements oddly, puts two spaces after each colon, escapes non-ASCII
as ``\\uXXXX`` and writes ``-Encoding UTF8`` with a BOM; pwsh 7 differs.  The
parity test compares *parsed* documents and the port emits plain
``json.dumps(..., indent=2)`` UTF-8 without a BOM, like every other port here.

The text of the two thrown errors above, which comes from the host
(``Win32Exception``, ``Set-Content``) and is localised.  Both implementations
exit 1 with the reason on stderr and nothing on stdout.

``durationMs``.  It is a wall-clock measurement, so the parity test compares
every other field and only asserts the shape of this one.
"""

from __future__ import annotations

import json
import os
import subprocess
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable, Sequence

from .gate_support import (
    GateResult,
    dotnet_trim,
    is_blank,
    ps_string,
    write_json_report,
)

EVIDENCE_SCHEMA_VERSION = "verification-evidence/v1"
READY_MARKER = "PREVIEW_VERIFICATION_READY"

# `Substring($text.Length - 1200)`, in UTF-16 code units.
SUMMARY_LIMIT = 1200
NO_INPUT_REASON = "No preview URL or verification command supplied."

PREVIEW_URL_CHECK = "preview-url"
CREATE_CHECK = "create-preview"
SMOKE_CHECK = "smoke"
TEARDOWN_CHECK = "teardown"


@dataclass(frozen=True)
class CommandOutcome:
    """What one shelled-out command produced."""

    exit_code: int
    stdout: str
    stderr: str
    duration_ms: int


# ``(command, working_directory) -> CommandOutcome``.  Injectable so the document
# assembly can be tested without a shell; the parity test uses the real one.
CommandRunner = Callable[[str, str], CommandOutcome]


def summarise(stdout: str, stderr: str) -> str:
    """``New-Summary``: join both streams, trim, keep the last 1200 units.

    ``stdout`` comes first because the reference joins ``($Stdout, $Stderr)``,
    not because of any ordering the child controls -- measured with a command
    that wrote to stderr first, the summary still read ``out-second`` then
    ``err-first``.
    """
    text = dotnet_trim("\n".join((stdout, stderr)))
    if not text:
        return ""
    units = text.encode("utf-16-le")
    if len(units) // 2 <= SUMMARY_LIMIT:
        return text
    # A cut that lands between the halves of an astral character leaves a lone
    # surrogate, which the reference then hands to its stdout encoder; the
    # encoder replaces it with U+FFFD, and so does `errors="replace"` here.
    return units[-SUMMARY_LIMIT * 2:].decode("utf-16-le", errors="replace")


def _check(
    name: str,
    command: str,
    exit_code: int,
    duration_ms: int,
    status: str,
    summary: str,
) -> dict[str, Any]:
    """One entry of ``checks``, in the reference's property order."""
    return {
        "name": name,
        "command": command,
        "exitCode": exit_code,
        "durationMs": duration_ms,
        "status": status,
        "summary": summary,
    }


def _planned_checks(
    create_command: str,
    smoke_commands: Sequence[str],
    teardown_command: str,
) -> list[tuple[str, str]]:
    """``(name, command)`` in the order the reference builds them.

    Create first, then every non-blank smoke command in the order given, then
    teardown.  A blank command of any kind produces no check at all rather than
    a check that trivially passes -- which is why passing only blanks gives
    ``NOT_RUN`` instead of ``PASS``.
    """
    plan: list[tuple[str, str]] = []
    if not is_blank(create_command):
        plan.append((CREATE_CHECK, create_command))
    for command in smoke_commands:
        text = ps_string(command)
        if is_blank(text):
            continue
        plan.append((SMOKE_CHECK, text))
    if not is_blank(teardown_command):
        plan.append((TEARDOWN_CHECK, teardown_command))
    return plan


def run_preview_verification(
    preview_url: str = "",
    create_command: str = "",
    smoke_commands: Sequence[str] = (),
    teardown_command: str = "",
    working_directory: str = "",
    output_path: str | Path = "",
    runner: CommandRunner | None = None,
) -> GateResult:
    """Run the preview commands and return the evidence document.

    Exit 0 when every check passed, 2 for ``FAIL`` and for ``NOT_RUN`` (the
    reference does ``if ($decision -eq "PASS") { exit 0 } else { exit 2 }``), and
    1 with the reason on stderr when a command cannot be started or the document
    cannot be written.

    ``runner`` exists so the decision logic can be exercised without a shell.
    """
    # PowerShell binds these as `[string]`, which turns `$null` into `""`; doing
    # it here keeps a `None` from reaching the document as JSON `null`.
    preview_url = ps_string(preview_url)
    create_command = ps_string(create_command)
    teardown_command = ps_string(teardown_command)
    working_directory = ps_string(working_directory)

    run = runner or _run_command

    checks: list[dict[str, Any]] = []
    if not is_blank(preview_url):
        # A supplied URL is recorded as a check that cannot fail, so the
        # document always has at least one entry when QA was actually pointed at
        # something.
        checks.append(
            _check(
                PREVIEW_URL_CHECK,
                "",
                0,
                0,
                "pass",
                f"Preview URL supplied for QA: {preview_url}",
            )
        )

    for name, command in _planned_checks(create_command, smoke_commands, teardown_command):
        try:
            outcome = run(command, working_directory)
        except OSError as exc:
            # The reference reaches this through a throwing `Process.Start`.
            return _thrown(f"cannot start {name} command: {command} ({exc})")
        checks.append(
            _check(
                name,
                command,
                outcome.exit_code,
                outcome.duration_ms,
                "pass" if outcome.exit_code == 0 else "fail",
                summarise(outcome.stdout, outcome.stderr),
            )
        )

    failed = [check for check in checks if check["status"] == "fail"]
    if not checks:
        decision = "NOT_RUN"
    elif failed:
        decision = "FAIL"
    else:
        decision = "PASS"

    blocked: list[str] = []
    if not checks:
        blocked.append(NO_INPUT_REASON)
    for check in failed:
        blocked.append(
            f"{check['name']} command failed with exit code "
            f"{check['exitCode']}: {check['command']}"
        )

    document = {
        "schemaVersion": EVIDENCE_SCHEMA_VERSION,
        "decision": decision,
        "previewUrl": preview_url,
        "checks": checks,
        "blockedReasons": blocked,
    }
    text = json.dumps(document, indent=2, ensure_ascii=False)

    if output_path:
        try:
            write_json_report(output_path, text)
        except OSError as exc:
            # `Set-Content` under `$ErrorActionPreference = "Stop"`.  The
            # document is written before it is printed, so stdout stays empty.
            return _thrown(f"cannot write {output_path} ({exc})")

    return GateResult(0 if decision == "PASS" else 2, text, extra_lines=(READY_MARKER,))


def _shell_argv(command: str) -> str | list[str]:
    """How the host shell is asked to run ``command``.

    Windows reproduces the reference byte for byte, including the
    ``Replace('"', '\\\\"')`` step and the ``/d /s /c`` switch -- see the module
    docstring for why that step is a defect the port nevertheless copies.

    POSIX has no reference to match: ``$env:ComSpec`` is unset and ``cmd.exe``
    does not exist there, so the reference throws before it runs anything.  The
    port uses ``/bin/sh -c`` instead, which is what the Linux runner the
    orchestrator actually deploys to needs.
    """
    if os.name == "nt":
        executable = os.environ.get("ComSpec") or "cmd.exe"
        escaped = command.replace('"', '\\"')
        # `ProcessStartInfo` concatenates FileName and Arguments; a string argv
        # is passed to CreateProcess verbatim, so the executable has to be
        # quoted here or a `ComSpec` containing a space would break.
        if " " in executable and not executable.startswith('"'):
            executable = f'"{executable}"'
        return f'{executable} /d /s /c "{escaped}"'
    return ["/bin/sh", "-c", command]


def _run_command(command: str, working_directory: str) -> CommandOutcome:
    """Run one command, capturing both streams and the wall-clock duration.

    ``subprocess.run`` drains stdout and stderr concurrently, which is the one
    deliberate divergence from the reference: it reads stdout to end and only
    then stderr, so a command that fills the stderr pipe deadlocks it.  See the
    module docstring for the measurement.

    Decoding is UTF-8 with replacement, matching what ``ProcessStartInfo`` does
    without an explicit ``StandardOutputEncoding`` on this host.  The capture is
    deliberately left in bytes and decoded here rather than passing ``text=True``:
    the text wrapper applies universal-newline translation, which would collapse
    the ``\\r\\n`` a Windows child writes into ``\\n`` and change where the
    1200-unit summary cut lands.  Measured -- it was the only divergence left in
    a 25-case differential run.
    """
    directory = None
    if not is_blank(working_directory):
        # `[IO.Path]::GetFullPath`, which resolves a relative path against the
        # process's current directory.
        directory = os.path.abspath(ps_string(working_directory))

    started = time.monotonic()
    completed = subprocess.run(_shell_argv(command), cwd=directory, capture_output=True)
    elapsed_ms = int((time.monotonic() - started) * 1000)
    return CommandOutcome(
        exit_code=completed.returncode,
        stdout=completed.stdout.decode("utf-8", errors="replace"),
        stderr=completed.stderr.decode("utf-8", errors="replace"),
        duration_ms=elapsed_ms,
    )


def _thrown(reason: str) -> GateResult:
    """An uncaught ``throw``: the reason on stderr, exit 1, empty stdout."""
    return GateResult(1, reason, to_stderr=True)
