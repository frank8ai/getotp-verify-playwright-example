"""Command-permission guard, ported from `scripts/guard-command-permissions.ps1`.

This is the authorization gate for the interactive surface: a comment on a PR
can ask the bot to `review`, `fix`, `explain`, `ignore`, or `merge`. Only
`OWNER` / `MEMBER` / `COLLABORATOR` associations may drive it, so a bug here is
a privilege-escalation bug -- exactly the logic that should live in the tested
engine instead of a shell script.

Contract reproduced exactly from the PowerShell reference:

* Accepts either a webhook payload path or the fields directly.
* `GUARD: Checking permissions for author='<author>', association='<ASSOC>'...`
  is printed before the decision.
* Unauthorized: writes to *stderr* `GUARD: DENIED. User '<author>' (<ASSOC>) is
  not an authorized collaborator.` and exits 2.
* Authorized: prints `GUARD: AUTHORIZED (<ASSOC>)`, then `GUARD_COMMAND_RESULT:`
  followed by the JSON result object, and exits 0.

Payload-file failures are a *third* outcome, and not an exit-2 refusal. The
reference reads the payload outside any `try`/`catch`:

    if ($PayloadPath) {
        if (-not (Test-Path -LiteralPath $PayloadPath)) {
            throw "Payload file not found: $PayloadPath"
        }
        $payload = Get-Content -Raw -LiteralPath $PayloadPath -Encoding UTF8 | ConvertFrom-Json
    }

An uncaught `throw` in a `-File` script terminates with exit **1** and the
message on stderr. `GuardInputError` carries that outcome so the CLI can report
it without a traceback. A blank payload file is *not* a failure: the reference's
`ConvertFrom-Json ""` yields `$null`, so the payload simply contributes no
fields and the run continues on the explicit arguments.

Parsing rules, in the reference's order:

1. `@aer-bot <verb> <rest...>` (case-insensitive, multiline) -> verb lowercased,
   remaining whitespace-split into arguments.
2. otherwise the literal `[x] Apply fix` fallback -> command `fix`,
   arguments `["all"]`.
3. otherwise the command is null and arguments are empty.

`-match` in PowerShell is case-insensitive *by default*, so step 2 accepts
`[X] APPLY FIX` too -- the reference never opts into `-cmatch`. This was
verified against the running reference rather than inferred from reading it
(see `test_apply_fix_match_is_case_insensitive`); it is a real widening of the
`fix` surface, so the parity gate pins it explicitly.
"""

from __future__ import annotations

import json
import re
import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

ALLOWED_ASSOCIATIONS: tuple[str, ...] = ("OWNER", "MEMBER", "COLLABORATOR")

# Exit code the reference produces when the payload cannot be read or parsed:
# an uncaught terminating error in a `-File` script. Distinct from the exit-2
# refusal used for an unauthorized association.
INPUT_ERROR_EXIT = 1


class GuardInputError(Exception):
    """The payload file could not be read or parsed (reference exit code 1)."""


# `(?im)` equivalents: case-insensitive, multiline (so `$` can end a line).
COMMAND_RE = re.compile(r"@aer-bot\s+(review|fix|explain|ignore|merge)\b(.*)$", re.I | re.M)
# `-match` is case-insensitive by default in PowerShell, so `[X] APPLY FIX`
# matches too. Do not "tighten" this to `[x]`/`Apply fix` -- it would silently
# stop the bot from acting on checkboxes the reference does act on.
APPLY_FIX_RE = re.compile(r"\[x\]\s*Apply fix", re.I)

RESULT_MARKER = "GUARD_COMMAND_RESULT:"


@dataclass
class GuardResult:
    """Outcome of the guard."""

    exit_code: int
    stdout_lines: list[str] = field(default_factory=list)
    stderr_lines: list[str] = field(default_factory=list)
    payload: dict[str, Any] | None = None

    def emit(self) -> int:
        for line in self.stdout_lines:
            print(line)
        for line in self.stderr_lines:
            print(line, file=sys.stderr)
        if self.payload is not None:
            print(json.dumps(self.payload, indent=4, ensure_ascii=False))
        return self.exit_code


def parse_command(comment_body: str | None) -> tuple[str | None, list[str]]:
    """Extract the bot command and its arguments from a comment body."""
    body = comment_body or ""

    match = COMMAND_RE.search(body)
    if match:
        command = match.group(1).lower()
        raw_args = (match.group(2) or "").strip()
        args = raw_args.split() if raw_args else []
        return command, args

    if APPLY_FIX_RE.search(body):
        return "fix", ["all"]

    return None, []


def evaluate_guard(
    *,
    comment_author: str = "",
    author_association: str = "",
    comment_body: str = "",
) -> GuardResult:
    """Apply the authorization + parsing rules; never raises for a denial."""
    association = (author_association or "").upper()

    lines = [
        f"GUARD: Checking permissions for author='{comment_author}', "
        f"association='{association}'..."
    ]

    if association not in ALLOWED_ASSOCIATIONS:
        return GuardResult(
            exit_code=2,
            stdout_lines=lines,
            stderr_lines=[
                f"GUARD: DENIED. User '{comment_author}' ({association}) "
                "is not an authorized collaborator."
            ],
        )

    lines.append(f"GUARD: AUTHORIZED ({association})")

    command, args = parse_command(comment_body)

    payload = {
        "authorized": True,
        "author": comment_author,
        "association": association,
        "command": command,
        "arguments": args,
    }

    lines.append(RESULT_MARKER)
    return GuardResult(exit_code=0, stdout_lines=lines, payload=payload)


def guard_from_payload(payload: Any, **overrides) -> GuardResult:
    """Derive author/association/body from a webhook payload, then evaluate."""
    comment = payload.get("comment") if isinstance(payload, dict) else None
    if not isinstance(comment, dict):
        comment = payload if isinstance(payload, dict) else {}

    author = overrides.get("comment_author") or ""
    association = overrides.get("author_association") or ""
    body = overrides.get("comment_body") or ""

    if not author:
        user = comment.get("user")
        if isinstance(user, dict):
            author = str(user.get("login") or "")

    if not association:
        association = str(comment.get("author_association") or "")

    if not body:
        body = str(comment.get("body") or "")

    return evaluate_guard(
        comment_author=author,
        author_association=association,
        comment_body=body,
    )


def run_guard(
    *,
    payload_path: str | Path | None = None,
    comment_author: str = "",
    author_association: str = "",
    comment_body: str = "",
) -> GuardResult:
    """Entry point mirroring the reference's parameter set."""
    if payload_path:
        payload = _load_payload(Path(payload_path))
        return guard_from_payload(
            payload,
            comment_author=comment_author,
            author_association=author_association,
            comment_body=comment_body,
        )

    return evaluate_guard(
        comment_author=comment_author,
        author_association=author_association,
        comment_body=comment_body,
    )


def _load_payload(target: Path) -> Any:
    """Read the webhook payload, mapping every failure to `GuardInputError`.

    The reference distinguishes only two things here: a missing file (its own
    explicit `throw`) and everything else (an uncaught read/parse error). Both
    end as exit 1, so both are one exception type with the reference's wording
    for the case it has wording for.

    A blank file parses to `None` rather than failing, because
    `ConvertFrom-Json ""` returns `$null` without throwing.
    """
    if not target.exists():
        raise GuardInputError(f"Payload file not found: {target}")
    try:
        text = target.read_text(encoding="utf-8-sig")
    except (OSError, UnicodeDecodeError) as exc:
        raise GuardInputError(f"Payload file could not be read: {target}") from exc
    if not text.strip():
        return None
    try:
        return json.loads(text)
    except json.JSONDecodeError as exc:
        raise GuardInputError(f"Payload file is not valid JSON: {target}") from exc


def main(argv: list[str] | None = None) -> int:
    import argparse

    parser = argparse.ArgumentParser(
        prog="python -m aer.command_guard",
        description="Authorize @aer-bot commands (port of guard-command-permissions.ps1).",
    )
    parser.add_argument("--payload-path", default="")
    parser.add_argument("--comment-author", default="")
    parser.add_argument("--author-association", default="")
    parser.add_argument("--comment-body", default="")
    args = parser.parse_args(argv)

    try:
        result = run_guard(
            payload_path=args.payload_path or None,
            comment_author=args.comment_author,
            author_association=args.author_association,
            comment_body=args.comment_body,
        )
    except GuardInputError as exc:
        print(str(exc), file=sys.stderr)
        return INPUT_ERROR_EXIT

    return result.emit()


if __name__ == "__main__":  # pragma: no cover - exercised via CLI tests
    sys.exit(main())
