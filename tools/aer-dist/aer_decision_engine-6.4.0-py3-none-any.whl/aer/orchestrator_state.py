"""Persistent orchestrator state store, ported from `scripts/agent-orchestrator-state.ps1`.

This module is the Python-side counterpart of the PowerShell state store that
`agent-orchestrator.yml` drives through `scripts/agent-orchestrator-state.ps1`.
It exists so the orchestrator's persisted state can move off a PowerShell-only
implementation without changing any observable behaviour.

The PowerShell script is the reference. Its contract, reproduced here exactly:

Actions
    Validate           create the state/lock roots; print VALID; exit 0
    Get                print FOUND plus the state JSON, or MISSING and exit 1
    Set                create or update the record; print SET plus the JSON
    IncrementAttempt   bump `attempts`; print ATTEMPT plus the JSON;
                       exit 2 once `attempts` exceeds `maxAttempts`
    AcquireLock        create the lock file; print ACQUIRED,
                       or HELD and exit 1 when it already exists
    ReleaseLock        delete the lock file if present; print RELEASED

The status vocabulary here is deliberately the orchestrator's own
(DISCOVERED/STARTED/.../FAILED) and is *not* the same as the eight-state
execution FSM in `harness/agent/state.py`. They model different things: this is
the durable per-issue record, that one is the in-memory execution cycle. Do not
collapse them.

Note on fidelity: `Set` does not validate that a transition is legal. The
PowerShell reference accepts any status in the allow-list from any prior status,
and callers depend on that (for example re-entering WAITING_CI after FIXING_CI).
Adding transition validation here would be a behaviour change, not a port.
"""

from __future__ import annotations

import json
import re
import sys
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

SCHEMA_VERSION = "agent-orchestrator-state/v1"

DEFAULT_STATE_ROOT = Path(".agent-orchestrator") / "state"
DEFAULT_LOCK_ROOT = Path(".agent-orchestrator") / "locks"
DEFAULT_MAX_ATTEMPTS = 2

# Mirrors $AllowedStatuses in the PowerShell reference. Order is preserved so
# error output and any future enumeration stay stable.
ALLOWED_STATUSES: tuple[str, ...] = (
    "DISCOVERED",
    "STARTED",
    "IMPLEMENTING",
    "PR_OPENED",
    "WAITING_CI",
    "FIXING_CI",
    "ADDRESSING_REVIEW",
    "READY_TO_MERGE",
    "MERGED",
    "NEED_USER_ACTION",
    "FAILED",
)


class OrchestratorStateError(ValueError):
    """Raised for contract violations the reference script reports as errors."""


def now_utc() -> str:
    """Timestamp in the reference's exact wire format: 2026-01-01T00:00:00Z."""
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


_SAFE_KEY_RE = re.compile(r"[^A-Za-z0-9_.-]")


def safe_key(value: str) -> str:
    """Reproduce `ConvertTo-SafeKey`: every unsafe character becomes `_`."""
    return _SAFE_KEY_RE.sub("_", value)


def state_path(state_root: Path, repo_key: str, issue_number: int) -> Path:
    return Path(state_root) / f"{safe_key(repo_key)}-issue-{issue_number}.json"


def lock_path(lock_root: Path, repo_key: str, issue_number: int) -> Path:
    return Path(lock_root) / f"{safe_key(repo_key)}-issue-{issue_number}.lock"


@dataclass
class OrchestratorState:
    """The durable per-issue record."""

    repoKey: str
    issueNumber: int
    status: str
    attempts: int = 0
    maxAttempts: int = DEFAULT_MAX_ATTEMPTS
    reason: str = ""
    schemaVersion: str = SCHEMA_VERSION
    createdAt: str = ""
    updatedAt: str = ""
    history: list[dict[str, Any]] = field(default_factory=list)

    @classmethod
    def new(
        cls,
        repo_key: str,
        issue_number: int,
        status: str,
        reason: str,
        max_attempts: int = DEFAULT_MAX_ATTEMPTS,
    ) -> "OrchestratorState":
        stamp = now_utc()
        return cls(
            repoKey=repo_key,
            issueNumber=issue_number,
            status=status,
            attempts=0,
            maxAttempts=max_attempts,
            reason=reason,
            createdAt=stamp,
            updatedAt=stamp,
            history=[{"at": stamp, "status": status, "reason": reason}],
        )

    @classmethod
    def from_dict(cls, payload: dict[str, Any]) -> "OrchestratorState":
        known = {f for f in cls.__dataclass_fields__}
        return cls(**{k: v for k, v in payload.items() if k in known})

    def apply_status(self, status: str, reason: str) -> None:
        stamp = now_utc()
        self.status = status
        self.reason = reason
        self.updatedAt = stamp
        self.history.append({"at": stamp, "status": status, "reason": reason})

    def to_dict(self) -> dict[str, Any]:
        # Field order mirrors the PowerShell object so emitted JSON is diffable
        # against the reference output.
        return {
            "schemaVersion": self.schemaVersion,
            "repoKey": self.repoKey,
            "issueNumber": self.issueNumber,
            "status": self.status,
            "attempts": self.attempts,
            "maxAttempts": self.maxAttempts,
            "reason": self.reason,
            "createdAt": self.createdAt,
            "updatedAt": self.updatedAt,
            "history": list(self.history),
        }

    def to_json(self) -> str:
        return json.dumps(self.to_dict(), indent=2, ensure_ascii=False) + "\n"


def read_state(path: Path) -> OrchestratorState | None:
    if not path.exists():
        return None
    # utf-8-sig tolerates the BOM the PowerShell `Set-Content -Encoding UTF8`
    # writes on Windows.
    payload = json.loads(path.read_text(encoding="utf-8-sig"))
    return OrchestratorState.from_dict(payload)


def write_state(path: Path, state: OrchestratorState) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(state.to_json(), encoding="utf-8")


def assert_repo_issue(action: str, repo_key: str | None, issue_number: int | None) -> None:
    if not repo_key:
        raise OrchestratorStateError(f"RepoKey is required for action {action}")
    if issue_number is None or issue_number <= 0:
        raise OrchestratorStateError(
            f"IssueNumber must be positive for action {action}"
        )


def validate_state_root(state_root: Path, lock_root: Path) -> None:
    Path(state_root).mkdir(parents=True, exist_ok=True)
    Path(lock_root).mkdir(parents=True, exist_ok=True)


@dataclass
class ActionResult:
    """Outcome of one action: message lines, exit code, optional JSON body."""

    exit_code: int = 0
    lines: list[str] = field(default_factory=list)
    payload: dict[str, Any] | None = None

    def emit(self) -> int:
        for line in self.lines:
            print(line)
        if self.payload is not None:
            print(json.dumps(self.payload, indent=2, ensure_ascii=False))
        return self.exit_code


def action_validate(state_root: Path, lock_root: Path) -> ActionResult:
    validate_state_root(state_root, lock_root)
    return ActionResult(lines=["AGENT_ORCHESTRATOR_STATE: VALID"])


def action_get(state_root: Path, lock_root: Path, repo_key: str, issue_number: int) -> ActionResult:
    assert_repo_issue("Get", repo_key, issue_number)
    state = read_state(state_path(state_root, repo_key, issue_number))
    if state is None:
        return ActionResult(exit_code=1, lines=["AGENT_ORCHESTRATOR_STATE: MISSING"])
    return ActionResult(lines=["AGENT_ORCHESTRATOR_STATE: FOUND"], payload=state.to_dict())


def action_set(
    state_root: Path,
    lock_root: Path,
    repo_key: str,
    issue_number: int,
    status: str,
    reason: str = "",
    max_attempts: int = DEFAULT_MAX_ATTEMPTS,
) -> ActionResult:
    assert_repo_issue("Set", repo_key, issue_number)
    if status not in ALLOWED_STATUSES:
        raise OrchestratorStateError(f"Invalid orchestrator status: {status}")

    target = state_path(state_root, repo_key, issue_number)
    state = read_state(target)
    if state is None:
        state = OrchestratorState.new(repo_key, issue_number, status, reason, max_attempts)
    else:
        state.apply_status(status, reason)

    write_state(target, state)
    return ActionResult(lines=["AGENT_ORCHESTRATOR_STATE: SET"], payload=state.to_dict())


def action_increment_attempt(
    state_root: Path,
    lock_root: Path,
    repo_key: str,
    issue_number: int,
    max_attempts: int = DEFAULT_MAX_ATTEMPTS,
) -> ActionResult:
    assert_repo_issue("IncrementAttempt", repo_key, issue_number)

    target = state_path(state_root, repo_key, issue_number)
    state = read_state(target)
    if state is None:
        state = OrchestratorState.new(
            repo_key, issue_number, "DISCOVERED", "created during attempt increment", max_attempts
        )

    state.attempts = int(state.attempts) + 1
    state.maxAttempts = max_attempts
    state.updatedAt = now_utc()
    exceeded = state.attempts > max_attempts
    if exceeded:
        state.status = "NEED_USER_ACTION"
        state.reason = "max attempts exceeded"

    write_state(target, state)
    return ActionResult(
        exit_code=2 if exceeded else 0,
        lines=["AGENT_ORCHESTRATOR_STATE: ATTEMPT"],
        payload=state.to_dict(),
    )


def action_acquire_lock(state_root: Path, lock_root: Path, repo_key: str, issue_number: int) -> ActionResult:
    assert_repo_issue("AcquireLock", repo_key, issue_number)

    target = lock_path(lock_root, repo_key, issue_number)
    target.parent.mkdir(parents=True, exist_ok=True)
    if target.exists():
        return ActionResult(exit_code=1, lines=["AGENT_ORCHESTRATOR_LOCK: HELD"])

    target.write_text(
        json.dumps(
            {"repoKey": repo_key, "issueNumber": issue_number, "acquiredAt": now_utc()},
            ensure_ascii=False,
        ),
        encoding="utf-8",
    )
    return ActionResult(lines=["AGENT_ORCHESTRATOR_LOCK: ACQUIRED"])


def action_release_lock(state_root: Path, lock_root: Path, repo_key: str, issue_number: int) -> ActionResult:
    assert_repo_issue("ReleaseLock", repo_key, issue_number)

    target = lock_path(lock_root, repo_key, issue_number)
    if target.exists():
        target.unlink()
    return ActionResult(lines=["AGENT_ORCHESTRATOR_LOCK: RELEASED"])


def run_action(
    action: str,
    *,
    repo_key: str = "",
    issue_number: int = 0,
    status: str = "",
    reason: str = "",
    state_root: Path | str = DEFAULT_STATE_ROOT,
    lock_root: Path | str = DEFAULT_LOCK_ROOT,
    max_attempts: int = DEFAULT_MAX_ATTEMPTS,
) -> ActionResult:
    """Dispatch one action. Raises OrchestratorStateError on contract violation."""
    state_root = Path(state_root)
    lock_root = Path(lock_root)

    if action == "Validate":
        return action_validate(state_root, lock_root)
    if action == "Get":
        return action_get(state_root, lock_root, repo_key, issue_number)
    if action == "Set":
        return action_set(
            state_root, lock_root, repo_key, issue_number, status, reason, max_attempts
        )
    if action == "IncrementAttempt":
        return action_increment_attempt(
            state_root, lock_root, repo_key, issue_number, max_attempts
        )
    if action == "AcquireLock":
        return action_acquire_lock(state_root, lock_root, repo_key, issue_number)
    if action == "ReleaseLock":
        return action_release_lock(state_root, lock_root, repo_key, issue_number)
    raise OrchestratorStateError(f"Unknown action: {action}")


def main(argv: list[str] | None = None) -> int:
    import argparse

    parser = argparse.ArgumentParser(
        prog="python -m aer.orchestrator_state",
        description="Persistent orchestrator state store (port of agent-orchestrator-state.ps1).",
    )
    parser.add_argument("--action", required=True, choices=[
        "Get", "Set", "IncrementAttempt", "AcquireLock", "ReleaseLock", "Validate",
    ])
    parser.add_argument("--repo-key", default="")
    parser.add_argument("--issue-number", type=int, default=0)
    parser.add_argument("--status", default="")
    parser.add_argument("--reason", default="")
    parser.add_argument("--state-root", default=str(DEFAULT_STATE_ROOT))
    parser.add_argument("--lock-root", default=str(DEFAULT_LOCK_ROOT))
    parser.add_argument("--max-attempts", type=int, default=DEFAULT_MAX_ATTEMPTS)

    args = parser.parse_args(argv)

    try:
        result = run_action(
            args.action,
            repo_key=args.repo_key,
            issue_number=args.issue_number,
            status=args.status,
            reason=args.reason,
            state_root=args.state_root,
            lock_root=args.lock_root,
            max_attempts=args.max_attempts,
        )
    except OrchestratorStateError as exc:
        print(str(exc), file=sys.stderr)
        return 1

    return result.emit()


if __name__ == "__main__":  # pragma: no cover - exercised via CLI tests
    sys.exit(main())
