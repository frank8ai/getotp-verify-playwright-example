"""Deterministic CI and test failure classification before agent invocation."""

from __future__ import annotations

import hashlib
import re
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Sequence

TRIAGE_SCHEMA_VERSION = "ci-triage/v1"

# Transient infrastructure signals: do not modify code, request rerun
_TRANSIENT_PATTERNS = [
    re.compile(r"(?i)\b(connection\s+reset|socket\s+timeout|econnreset|etimedout)\b"),
    re.compile(r"(?i)\b(rate\s+limit|too\s+many\s+requests|429\s+Too\s+Many\s+Requests)\b"),
    re.compile(r"(?i)\b(runner\s+has\s+lost\s+communication|worker\s+process\s+terminated\s+abnormally)\b"),
    re.compile(r"(?i)\b(temporary\s+failure\s+in\s+name\s+resolution|getaddrinfo\s+ENOTFOUND)\b"),
    re.compile(r"(?i)\b(github-hosted-runner-unavailable|github-actions-spending-limit)\b"),
]

# Policy and security blocks: never auto-fix, fail-closed to human
_POLICY_PATTERNS = [
    re.compile(r"(?i)\b(secret-scan|secret-detected|committed\s+secret|authorization\s*:\s*bearer)\b"),
    re.compile(r"(?i)\b(protected-surface-touched|protected-path-violated|workflow-modified)\b"),
    re.compile(r"(?i)\b(high-risk\s+label|high-risk\s+path|auth|payment|billing|ledger|settlement)\b"),
    re.compile(r"(?i)\b(diff\s+budget\s+exceeded|diff-budget-exceeded)\b"),
]

# Code defects: syntax, assertions, imports, test failures that can be repaired
_CODE_DEFECT_PATTERNS = [
    re.compile(r"(?i)\b(assertionerror|failed\s+test|pytest\.fail|failurereason)\b"),
    re.compile(r"(?i)\b(syntaxerror|indentationerror|nameerror|typeerror|attributeerror)\b"),
    re.compile(r"(?i)\b(importerror|modulenotfounderror|cannot\s+import\s+name)\b"),
    re.compile(r"(?i)\b(compilation\s+error|compile-error|ts\(\d+\)|syntax\s+error)\b"),
    re.compile(r"(?i)\b(exit\s+code\s+1\b|exit\s+code\s+2\b)"),
    re.compile(r'(?i)\\b(pr_ready:\\s*no|pr readiness watcher|required check)\\b'),
]

_REVIEW_COMMENT_PATTERNS = [
    re.compile(r"(?i)\b(unresolved\s+review\s+thread|changes_requested|review\s+comment)\b"),
]


@dataclass
class TriageDecision:
    category: str
    action: str
    fingerprint: str
    summary: str
    matched_patterns: list[str] = field(default_factory=list)
    can_auto_fix: bool = False
    timestamp: str = field(
        default_factory=lambda: datetime.now(timezone.utc).isoformat()
    )

    def to_dict(self) -> dict:
        return {
            "schemaVersion": TRIAGE_SCHEMA_VERSION,
            "category": self.category,
            "action": self.action,
            "fingerprint": self.fingerprint,
            "summary": self.summary,
            "matched_patterns": self.matched_patterns,
            "can_auto_fix": self.can_auto_fix,
            "timestamp": self.timestamp,
        }


def compute_fingerprint(text: str, category: str) -> str:
    normalized = re.sub(r"\s+", " ", text).strip().lower()
    # Strip volatile tokens like dates/timestamps
    normalized = re.sub(r"\d{4}-\d{2}-\d{2}t\d{2}:\d{2}:\d{2}[^\s]*", "", normalized)
    raw = f"{category}::{normalized[:500]}"
    sha = hashlib.sha256(raw.encode("utf-8")).hexdigest()
    return f"sha256:{sha}"


def triage_failure(text: str, *, causal_slice: dict | None = None) -> TriageDecision:
    if not text or not text.strip():
        return TriageDecision(
            category="unknown",
            action="need-user-action",
            fingerprint=compute_fingerprint("empty-trace", "unknown"),
            summary="Empty failure trace provided",
            matched_patterns=[],
            can_auto_fix=False,
        )

    matched_policy = [p.pattern for p in _POLICY_PATTERNS if p.search(text)]
    if matched_policy:
        return TriageDecision(
            category="policy-block",
            action="need-user-action",
            fingerprint=compute_fingerprint(text, "policy-block"),
            summary="Safety or security policy violation detected",
            matched_patterns=matched_policy,
            can_auto_fix=False,
        )

    matched_transient = [p.pattern for p in _TRANSIENT_PATTERNS if p.search(text)]
    if matched_transient:
        return TriageDecision(
            category="transient-infra",
            action="rerun",
            fingerprint=compute_fingerprint(text, "transient-infra"),
            summary="Transient infrastructure failure; safe to rerun without code patch",
            matched_patterns=matched_transient,
            can_auto_fix=False,
        )

    matched_review = [p.pattern for p in _REVIEW_COMMENT_PATTERNS if p.search(text)]
    if matched_review:
        return TriageDecision(
            category="review-comment",
            action="auto-fix",
            fingerprint=compute_fingerprint(text, "review-comment"),
            summary="Review comments or changes requested by reviewer",
            matched_patterns=matched_review,
            can_auto_fix=True,
        )

    if causal_slice and causal_slice.get("failureAnchor"):
        anchor = causal_slice["failureAnchor"]
        exc = anchor.get("exceptionType", "")
        return TriageDecision(
            category="code-defect",
            action="auto-fix",
            fingerprint=compute_fingerprint(f"{anchor.get('file')}::{anchor.get('line')}::{exc}", "code-defect"),
            summary=f"Causal execution slice isolated {exc} at {anchor.get('file')}:{anchor.get('line')}",
            matched_patterns=[f"causal-slice:{exc}"],
            can_auto_fix=True,
        )

    matched_code = [p.pattern for p in _CODE_DEFECT_PATTERNS if p.search(text)]
    if matched_code:
        return TriageDecision(
            category="code-defect",
            action="auto-fix",
            fingerprint=compute_fingerprint(text, "code-defect"),
            summary="Deterministically detected code, compile, or test assertion failure",
            matched_patterns=matched_code,
            can_auto_fix=True,
        )

    return TriageDecision(
        category="unknown",
        action="need-user-action",
        fingerprint=compute_fingerprint(text, "unknown"),
        summary="Unclassified failure; fail-closed to user",
        matched_patterns=[],
        can_auto_fix=False,
    )

