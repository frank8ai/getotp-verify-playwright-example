"""Port of ``run-learning-loop.ps1``.

The loop reads a JSON-lines file of ``failure-event/v1`` records, finds the most
frequent ``category``, and emits a *proposal* -- never an action.  ``autoApplied``
is hard-coded ``false`` in both branches; the whole point of the stage is that a
human reviews the suggestion.  Two branches:

  * fewer than two occurrences of the top category -> ``NO_ACTION``, exit 0
  * otherwise -> ``PROPOSE`` with four canned proposals, exit 0

Everything here was measured against the running reference.  The parts that are
not obvious from reading it:

**``Group-Object`` is case-insensitive and reports the first spelling.**  ``CI``
and ``ci`` land in one group, and ``failurePattern`` carries whichever casing
appeared first -- so ``["CI", "ci"]`` proposes about ``'CI'`` while ``["ci",
"CI"]`` proposes about ``'ci'``.  The grouping *key* is the lowercased
``Group-Object`` name, which is also why the integer ``7`` and the string
``"7"`` group together.

**A line is not necessarily one event.**  ``$events += $event`` concatenates, so
a JSON line holding an *array* contributes every element.  A line ``[1, 2]``
therefore adds two events, and since neither has a ``category`` they join the
empty-named group and can carry a ``PROPOSE`` on their own -- measured: ``[1,2]``
followed by one ``ci`` event proposes about ``''`` with two occurrences.

**``Add-Member`` throws on a falsy-but-present ``schemaVersion``.**  The guard is
``-not $event.schemaVersion``, which is true for ``""``, ``null``, ``0`` and
``false`` -- and ``Add-Member`` then refuses because the property already exists,
so the script dies with exit 1 and no output rather than defaulting the version.
The schema requires ``schemaVersion`` to be the const ``failure-event/v1``, so
this is only reachable from a hand-written events file, but a caller branches on
the exit code and the port has to fail too.

**A ``null`` line is fatal.**  ``$null | Add-Member`` cannot bind its
``InputObject``.  Every other scalar shape (``5``, ``"hello"``, ``true``, ``[]``,
``{}``) is accepted and simply has no ``category``.

What is deliberately *not* reproduced
-------------------------------------

**The tie-break order.**  ``Sort-Object Count -Descending`` is **not stable**:
with equal counts the winner follows .NET's introspective sort, and the order is
chaotic and unrelated to the input order -- measured on Windows PowerShell
5.1.26100.9444 for four equally-sized groups ``a b c d``, the sorted order is
``c d a b``; for eight it is ``f e h g b a d c``.  It is the same ascending or
descending, and it depends only on the sort implementation, not on the data.
Reproducing it would mean reimplementing ``ArraySortHelper`` in Python and
pinning the port to one .NET build, so this port instead applies a **stable**
sort: ties keep first-appearance order.  A tie cannot change the *decision*
(the top count is the same either way), only which tied category is named in
``failurePattern`` and which group's items land in ``evidence``.  Tied inputs
are therefore absent from the parity matrix and pinned by
``test_ties_keep_first_appearance_order`` instead.

**``ConvertTo-Json``'s exact bytes** (BOM, CRLF, ``\\u0027`` for an apostrophe).
Callers parse the document; see ``gate_support.write_json_report``.
"""

from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any

from .gate_support import (
    GateResult,
    parse_document,
    ps_element_string,
    ps_has_member,
    ps_member,
    ps_string,
    ps_truthy,
    write_json_report,
)

LEARNING_PROPOSAL_SCHEMA_VERSION = "learning-proposal/v1"
FAILURE_EVENT_SCHEMA_VERSION = "failure-event/v1"
NO_ACTION_MARKER = "LEARNING_LOOP_NO_ACTION"
PROPOSAL_READY_MARKER = "LEARNING_LOOP_PROPOSAL_READY"
BLOCKED_REASON = (
    "Need at least two occurrences before proposing a learning change."
)

# `Get-Content` splits on CRLF, LF, or CR.  `str.splitlines()` is wider than
# that -- it also breaks on \v, \f, \x1c-\x1e, \x85, \u2028 and \u2029, any of
# which is legal inside a JSON string -- so the split is spelled out.
_LINE_BREAK = re.compile(r"\r\n|\r|\n")

PROPOSAL_KINDS = (
    (
        "agents-rule",
        "Strengthen readiness instructions for repeated '{pattern}' evidence "
        "before PR readiness.",
    ),
    (
        "skill-update",
        "Propose a human-reviewed skill update documenting '{pattern}' "
        "detection and mitigation evidence.",
    ),
    (
        "eval-case",
        "Add an eval fixture with two '{pattern}' failure events and require a "
        "proposal-only output.",
    ),
    (
        "ci-gate",
        "Propose a stronger closure check for unresolved '{pattern}' evidence "
        "gaps.",
    ),
)


def group_name_string(value: Any) -> str:
    """``Group-Object``'s ``Name`` for one property value.

    Not ``[string]$value``, even though the property is a ``string`` on the way
    out.  For a collection the two disagree, and the reference sees the
    ``Group-Object`` spelling because it always reads the property off a parsed
    object::

        [string]@("x","y")            -> 'x y'
        (Group-Object).Name for it    -> '{x, y}'

    The brace form only appears once the array has been wrapped by a property
    access; a bare ``ConvertFrom-Json '["x","y"]'`` renders as ``x y``.  That
    unwrapped shape is unreachable here, because ``$event.category`` always goes
    through a property.  Everything that is not a collection is plain
    ``[string]``, so the shared helper is reused rather than copied.
    """
    if isinstance(value, list):
        return "{" + ", ".join(ps_element_string(item) for item in value) + "}"
    return ps_string(value)


def _describe(event: Any) -> str:
    """``"$($_.source): $($_.summary)"`` -- a missing field interpolates empty."""
    return f"{ps_string(ps_member(event, 'source'))}: {ps_string(ps_member(event, 'summary'))}"


def _group(events: list[Any]) -> list[tuple[str, list[Any]]]:
    """``Group-Object -Property category``, preserving first-appearance order.

    The key is the lowercased name and the reported name is the first spelling
    seen, which is what makes ``CI``/``ci`` one group named ``CI``.
    """
    order: list[str] = []
    names: dict[str, str] = {}
    members: dict[str, list[Any]] = {}
    for event in events:
        name = group_name_string(ps_member(event, "category"))
        key = name.lower()
        if key not in members:
            order.append(key)
            names[key] = name
            members[key] = []
        members[key].append(event)
    # A stable sort is the port's own choice; see the module docstring.
    ordered = sorted(order, key=lambda key: -len(members[key]))
    return [(names[key], members[key]) for key in ordered]


def _proposals(pattern: str) -> list[dict[str, str]]:
    return [
        {"kind": kind, "summary": template.format(pattern=pattern)}
        for kind, template in PROPOSAL_KINDS
    ]


def run_learning_loop(
    failure_events_path: str | Path,
    output_path: str | Path = "",
) -> GateResult:
    """Aggregate failure events into a learning proposal.

    Exit 0 with a marker for both branches -- ``NO_ACTION`` is a normal outcome,
    not a failure -- and exit 1 (reason on stderr, empty stdout) when the events
    file is missing, unreadable, malformed, or holds an event that already
    declares a falsy ``schemaVersion``.
    """
    source = Path(failure_events_path)
    if not source.exists():
        return _thrown(f"Failure events not found: {failure_events_path}")

    try:
        text = source.read_text(encoding="utf-8-sig", errors="replace")
    except OSError as exc:
        # `Get-Content` on a directory throws; `Test-Path` said it existed.
        return _thrown(f"cannot read failure events: {failure_events_path} ({exc})")

    events: list[Any] = []
    for line in _LINE_BREAK.split(text):
        if line.strip() == "":
            continue
        event, parse_error = parse_document(line)
        if parse_error:
            return _thrown(f"invalid json: {failure_events_path}")
        if not ps_truthy(ps_member(event, "schemaVersion")):
            if event is None:
                # `$null | Add-Member` cannot bind InputObject.
                return _thrown(f"failure event is null: {failure_events_path}")
            if isinstance(event, dict) and ps_has_member(event, "schemaVersion"):
                # Add-Member refuses to overwrite an existing property.
                return _thrown(
                    f"failure event already declares schemaVersion: {failure_events_path}"
                )
            if isinstance(event, dict):
                event = {**event, "schemaVersion": FAILURE_EVENT_SCHEMA_VERSION}
        # `$events += $event` concatenates, so an array line adds every element.
        if isinstance(event, list):
            events.extend(event)
        else:
            events.append(event)

    groups = _group(events)
    if groups:
        pattern, top_members = groups[0]
        occurrences = len(top_members)
    else:
        pattern, top_members, occurrences = "", [], 0

    if not groups or occurrences < 2:
        document: dict[str, Any] = {
            "schemaVersion": LEARNING_PROPOSAL_SCHEMA_VERSION,
            "decision": "NO_ACTION",
            "failurePattern": pattern,
            "occurrences": occurrences,
            "proposals": [],
            "autoApplied": False,
            # The no-action branch reports *every* event, not the top group.
            "evidence": [_describe(event) for event in events],
            "blockedReasons": [BLOCKED_REASON],
        }
        marker = NO_ACTION_MARKER
    else:
        document = {
            "schemaVersion": LEARNING_PROPOSAL_SCHEMA_VERSION,
            "decision": "PROPOSE",
            "failurePattern": pattern,
            "occurrences": occurrences,
            "proposals": _proposals(pattern),
            "autoApplied": False,
            "evidence": [_describe(event) for event in top_members],
            "blockedReasons": [],
        }
        marker = PROPOSAL_READY_MARKER

    rendered = json.dumps(document, indent=2, ensure_ascii=False)
    if output_path:
        write_json_report(output_path, rendered)
    return GateResult(0, rendered, extra_lines=(marker,))


def _thrown(reason: str) -> GateResult:
    """An uncaught ``throw``: the reason on stderr, exit 1, empty stdout.

    The reference's text for the two ``Add-Member`` failures is the host's own
    message ("Cannot add a member with the name ..."), which is localised and
    therefore not a contract; the parity test asserts the exit code and the
    stream instead.
    """
    return GateResult(1, reason, to_stderr=True)
