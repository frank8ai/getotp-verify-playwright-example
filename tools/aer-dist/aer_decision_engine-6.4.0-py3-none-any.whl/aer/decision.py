"""Deterministic policy decision engine.

This is a narrow Python port of scripts/evaluate-policy-decision.ps1. The
PowerShell implementation remains the reference until equivalence across the
golden baseline is verified.
"""

from __future__ import annotations

import hashlib
from dataclasses import dataclass
from datetime import datetime, timezone
from enum import StrEnum
from pathlib import Path
from typing import Any


class Decision(StrEnum):
    ALLOW = "ALLOW"
    DENY = "DENY"
    RETRY = "RETRY"
    HUMAN_REQUIRED = "HUMAN_REQUIRED"


@dataclass(frozen=True)
class TaskContract:
    job_id: str = ""
    epoch: int = 1
    profile: str = "autopilot-low"
    risk: str = "low"
    base_sha: str = ""
    diff_budgets: dict[str, int] | None = None

    @classmethod
    def from_mapping(cls, value: dict[str, Any] | None) -> "TaskContract":
        if not value:
            return cls()
        capabilities = value.get("capabilities") or {}
        policy = value.get("policy") or {}
        profile = (
            value.get("profile")
            or value.get("riskProfile")
            or policy.get("profile")
            or "autopilot-low"
        )
        return cls(
            job_id=str(value.get("jobId") or ""),
            epoch=int(value.get("epoch") or 1),
            profile=str(profile),
            risk=str(value.get("risk") or "low"),
            base_sha=str(value.get("baseSha") or ""),
            diff_budgets=capabilities.get("diffBudgets") or {},
        )


@dataclass(frozen=True)
class EvidenceBundle:
    job_id: str = ""
    epoch: int = 1
    head_sha: str = ""
    verifier_signature: str = ""
    secret_scan_passed: bool = False
    infrastructure_untouched: bool = False
    dependency_untouched: bool = False
    test_exit_codes: tuple[int, ...] = ()
    files_changed: int | None = None
    insertions: int | None = None
    deletions: int | None = None

    @classmethod
    def from_mapping(cls, value: dict[str, Any] | None) -> "EvidenceBundle":
        if not value:
            return cls()
        audit = value.get("securityAudit") or {}
        diff = value.get("diffMetrics") or {}
        tests = value.get("testResults") or []
        return cls(
            job_id=str(value.get("jobId") or ""),
            epoch=int(value.get("epoch") or 1),
            head_sha=str(value.get("headSha") or ""),
            verifier_signature=str(value.get("verifierSignature") or ""),
            secret_scan_passed=bool(audit.get("secretScanPassed")),
            infrastructure_untouched=bool(audit.get("infrastructureUntouched")),
            dependency_untouched=bool(audit.get("dependencyUntouched")),
            test_exit_codes=tuple(int(test.get("exitCode") or 0) for test in tests),
            files_changed=_optional_int(diff.get("filesChanged")),
            insertions=_optional_int(diff.get("insertions")),
            deletions=_optional_int(diff.get("deletions")),
        )


@dataclass(frozen=True)
class DecisionResult:
    job_id: str
    epoch: int
    head_sha: str
    policy_hash: str
    evaluation_timestamp: str
    decision: Decision
    passed_rules: tuple[str, ...]
    failed_rules: tuple[str, ...]

    def to_dict(self) -> dict[str, Any]:
        return {
            "jobId": self.job_id,
            "epoch": self.epoch,
            "headSha": self.head_sha,
            "policyHash": self.policy_hash,
            "evaluationTimestamp": self.evaluation_timestamp,
            "decision": self.decision.value,
            "passedRules": list(self.passed_rules),
            "failedRules": list(self.failed_rules),
        }


def _optional_int(value: Any) -> int | None:
    if value is None:
        return None
    return int(value)


def policy_hash(policy_path: Path) -> str:
    if not policy_path.exists():
        return "sha256:0000000000000000"
    return "sha256:" + hashlib.sha256(policy_path.read_bytes()).hexdigest()


def evaluate_decision(
    task_contract: TaskContract | None,
    evidence: EvidenceBundle | None,
    policy_digest: str,
    *,
    timestamp: str | None = None,
) -> DecisionResult:
    """Evaluate the same deterministic rules as the PowerShell reference."""
    contract = task_contract or TaskContract()
    job_id = contract.job_id or (evidence.job_id if evidence else "") or "job-shadow-eval"
    epoch = evidence.epoch if evidence and evidence.epoch else contract.epoch or 1
    head_sha = (
        (evidence.head_sha if evidence else "")
        or contract.base_sha
        or "head-sha-unknown"
    )

    passed: list[str] = []
    failed: list[str] = []
    decision = Decision.ALLOW

    if task_contract:
        if contract.profile == "human-required" or contract.risk == "high":
            failed.append("RULE_INTENT_REQUIRES_HUMAN")
            decision = Decision.HUMAN_REQUIRED
        else:
            passed.append("RULE_INTENT_ADMISSIBLE")

    if decision is not Decision.HUMAN_REQUIRED:
        if evidence is None:
            failed.append("RULE_EVIDENCE_MISSING")
            decision = Decision.DENY
        else:
            if not evidence.verifier_signature or evidence.verifier_signature == "INVALID_SIGNATURE":
                failed.append("RULE_VERIFIER_SIGNATURE_INVALID")
            else:
                passed.append("RULE_VERIFIER_SIGNATURE_VALID")

            _check_security_audit(evidence, passed, failed)
            _check_diff_budget(contract, evidence, passed, failed)

            test_failed = any(code != 0 for code in evidence.test_exit_codes)
            if failed:
                decision = Decision.DENY
            elif test_failed:
                if epoch >= 3:
                    decision = Decision.HUMAN_REQUIRED
                    failed.append("RULE_MAX_REPAIRS_EXHAUSTED")
                else:
                    decision = Decision.RETRY
                    passed.append("RULE_TEST_FAILURE_RETRYABLE")
            else:
                decision = Decision.ALLOW
                passed.append("RULE_ALL_TESTS_PASSED")

    return DecisionResult(
        job_id=job_id,
        epoch=epoch,
        head_sha=head_sha,
        policy_hash=policy_digest,
        evaluation_timestamp=timestamp or _utc_timestamp(),
        decision=decision,
        passed_rules=tuple(passed),
        failed_rules=tuple(failed),
    )


def _check_security_audit(
    evidence: EvidenceBundle,
    passed: list[str],
    failed: list[str],
) -> None:
    if not evidence.secret_scan_passed:
        failed.append("RULE_SECRET_SCAN_FAILED")
    else:
        passed.append("RULE_SECRET_SCAN_PASSED")

    if not evidence.infrastructure_untouched:
        failed.append("RULE_PROTECTED_INFRA_VIOLATION")
    else:
        passed.append("RULE_PROTECTED_INFRA_UNTOUCHED")

    if not evidence.dependency_untouched:
        failed.append("RULE_DEPENDENCY_VIOLATION")
    else:
        passed.append("RULE_DEPENDENCY_UNTOUCHED")


def _check_diff_budget(
    contract: TaskContract,
    evidence: EvidenceBundle,
    passed: list[str],
    failed: list[str],
) -> None:
    budgets = contract.diff_budgets or {}
    max_files = int(budgets.get("maxFiles") or 15)
    max_additions = int(budgets.get("maxAdditions") or 300)
    max_deletions = int(budgets.get("maxDeletions") or 150)
    if evidence.files_changed is None:
        return
    if (
        evidence.files_changed > max_files
        or (evidence.insertions or 0) > max_additions
        or (evidence.deletions or 0) > max_deletions
    ):
        failed.append("RULE_DIFF_BUDGET_EXCEEDED")
    else:
        passed.append("RULE_DIFF_BUDGET_RESPECTED")


def _utc_timestamp() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
