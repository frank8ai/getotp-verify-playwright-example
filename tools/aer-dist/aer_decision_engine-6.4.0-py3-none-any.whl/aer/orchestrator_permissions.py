"""Port of ``resolve-orchestrator-permissions.ps1``.

The script answers one question for the service orchestrator: *which GitHub App
identity, environment, and contents permission does this (profile, mode) pair
get?*  It is the token-selection decision, so the port reproduces both failure
channels exactly:

  * a deliberate refusal is ``Write-Host`` + ``exit 2`` -- stdout, no exception
  * a broken manifest is an uncaught ``throw`` -- stderr, exit 1, empty stdout

Measured behaviours encoded here
--------------------------------

``throw`` is not ``exit 2``.  A missing manifest, an unparseable manifest, and
a missing ``serviceOrchestrator`` all exit **1** with the reason on **stderr**
and nothing on stdout.  A caller that greps stdout for a marker would miss
them, which is why ``GateResult`` grew a stream flag for this port.

``ConvertFrom-Json ""`` returns ``$null`` without throwing, so a blank manifest
is *not* "invalid json" -- it falls through to
``serviceOrchestrator configuration missing``.  ``null`` and ``[]`` do the
same, because reading a property off them yields ``$null``.

``ValidateSet`` is case-insensitive, so ``-Profile Autopilot-Low`` is accepted
and behaves as ``autopilot-low``; ``switch`` is case-insensitive too, which is
why the environment still resolves.

Two name-dependent cases fall out of that comparison and are worth naming:

  * a missing ``runner.name`` leaves ``app_name`` empty, which does *not* equal
    the reviewer's name, so the runner's permission is still read -- the report
    shows an empty ``ORCHESTRATOR_PERMISSION_APP`` next to the runner's
    ``contentsPermission``
  * when **both** names are empty (or equal) the comparison succeeds and the
    reviewer's permission is used instead, even though the runner App was
    selected.  With a write-capable runner and a read-only reviewer that is a
    silent downgrade; with the entries swapped it would be a silent upgrade,
    which is the direction that matters.

The second case is a real fail-open in the reference.  The port reproduces it
rather than quietly fixing it, and
``test_both_names_missing_downgrades_to_reviewer_permission`` pins it so the
behaviour cannot change unnoticed.

What is deliberately *not* modelled
-----------------------------------

``ValidateSet`` and the parameter binder reject an unknown profile or mode
before the script body runs: exit 1, a binding exception on stderr, no marker.
There is therefore no script-level contract to copy.  The library raises
``ValueError`` for an unknown value (a caller bug) and the CLI rejects it with
argparse's exit 2; both fail closed.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

from .gate_support import GateResult, load_document, ps_member, ps_string

DEFAULT_MANIFEST_PATH = "./agent-workflow.yml"

PROFILES = ("autopilot-low", "autopilot-medium", "human-required")

MODES = (
    "discover",
    "triage",
    "decompose",
    "implement",
    "verify",
    "monitor",
    "rollback",
    "learn",
    "steward",
    "review",
    "merge",
)

# Modes the reference treats as observation-only.  They get the reviewer App
# regardless of profile.
READ_ONLY_MODES = ("triage", "decompose", "verify", "monitor", "rollback", "learn", "review")

# Modes that receive an execution token, which human-required must never get.
EXECUTION_MODES = ("implement", "merge", "steward")

ENVIRONMENTS = {
    "autopilot-low": "autopilot-low-write",
    "autopilot-medium": "autopilot-medium-write",
    "human-required": "human-required-readonly",
}

PASS_MARKER = "ORCHESTRATOR_PERMISSION: PASS"
DENY_MARKER = "ORCHESTRATOR_PERMISSION: DENY"
APP_PREFIX = "ORCHESTRATOR_PERMISSION_APP:"
ENVIRONMENT_PREFIX = "ORCHESTRATOR_PERMISSION_ENVIRONMENT:"
CONTENTS_PREFIX = "ORCHESTRATOR_PERMISSION_CONTENTS:"
REASON_PREFIX = "ORCHESTRATOR_PERMISSION_REASON:"

EXECUTION_TOKEN_REASON = "human-required cannot receive execution token"
AUTO_MERGE_REASON = "auto-merge is limited to autopilot-low"
WRITE_TOKEN_REASON = "human-required resolved to a write-capable token"
MISSING_SERVICE_REASON = "serviceOrchestrator configuration missing"


def _deny(reason: str) -> GateResult:
    """A deliberate refusal: the marker and the reason on stdout, exit 2."""
    return GateResult(2, DENY_MARKER, extra_lines=(f"{REASON_PREFIX} {reason}",))


def _thrown(reason: str) -> GateResult:
    """An uncaught ``throw``: the reason on stderr, exit 1, empty stdout."""
    return GateResult(1, reason, to_stderr=True)


def resolve_permissions(manifest: Any, profile: str, mode: str) -> GateResult:
    """Resolve the identity, environment, and contents permission to use.

    ``profile`` and ``mode`` are compared case-insensitively, matching
    ``ValidateSet`` and PowerShell's ``-eq``/``-in``/``switch``.
    """
    profile = ps_string(profile).lower()
    mode = ps_string(mode).lower()
    if profile not in PROFILES:
        raise ValueError(f"profile must be one of {PROFILES}, got {profile!r}")
    if mode not in MODES:
        raise ValueError(f"mode must be one of {MODES}, got {mode!r}")

    service = ps_member(manifest, "serviceOrchestrator")
    if service is None:
        return _thrown(MISSING_SERVICE_REASON)

    # A human never receives a token that could execute or merge.
    if profile == "human-required" and mode in EXECUTION_MODES:
        return _deny(EXECUTION_TOKEN_REASON)

    # Auto-merge is the narrowest capability in the system.
    if mode == "merge" and profile != "autopilot-low":
        return _deny(AUTO_MERGE_REASON)

    apps = ps_member(service, "githubApps")
    reviewer = ps_member(apps, "reviewer")
    runner = ps_member(apps, "runner")
    reviewer_name = ps_string(ps_member(reviewer, "name"))
    runner_name = ps_string(ps_member(runner, "name"))

    wants_reviewer = mode in READ_ONLY_MODES or profile == "human-required"
    app_name = reviewer_name if wants_reviewer else runner_name

    environment = ENVIRONMENTS[profile]

    # The reference re-derives the branch by comparing names rather than
    # remembering the choice, so two equal (or two empty) names both land on
    # the reviewer's permission.
    if app_name.lower() == reviewer_name.lower():
        contents_permission = ps_string(ps_member(reviewer, "contentsPermission"))
    else:
        contents_permission = ps_string(ps_member(runner, "contentsPermission"))

    if profile == "human-required" and contents_permission.lower() == "write":
        return _deny(WRITE_TOKEN_REASON)

    return GateResult(
        0,
        PASS_MARKER,
        extra_lines=(
            f"{APP_PREFIX} {app_name}",
            f"{ENVIRONMENT_PREFIX} {environment}",
            f"{CONTENTS_PREFIX} {contents_permission}",
        ),
    )


def check_orchestrator_permissions(
    profile: str,
    mode: str,
    manifest_path: str | Path = DEFAULT_MANIFEST_PATH,
) -> GateResult:
    """Load the manifest, then resolve permissions for ``profile`` + ``mode``."""
    target = Path(manifest_path)
    if not target.exists():
        return _thrown(f"Manifest not found: {manifest_path}")

    manifest, parse_error = load_document(target)
    if parse_error:
        # The reference surfaces the .NET serializer's own text here, which is
        # not reproducible and not something a caller can branch on.  Both
        # implementations exit 1 with the reason on stderr.
        return _thrown(f"invalid json: {manifest_path}")

    return resolve_permissions(manifest, profile, mode)
