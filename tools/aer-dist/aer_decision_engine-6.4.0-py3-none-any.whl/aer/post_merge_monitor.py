"""Port of ``run-post-merge-monitor.ps1``.

After a merge the monitor turns the verification outcome into one of two event
documents and exits accordingly:

  * ``pass`` -> a ``release-event/v1`` with ``status: "healthy"``, marker
    ``POST_MERGE_MONITOR_PASS``, exit 0
  * anything else -> an ``incident-event/v1``, marker
    ``POST_MERGE_MONITOR_INCIDENT``, exit 2

The release document is written *before* the branch, so a failing verification
produces **two** files when both paths are supplied -- the release event (with
``status: "incident"``) and the incident event.  The incident goes to
``IncidentEventPath`` when given and to ``OutputPath`` otherwise, which is why
``OutputPath`` stays unwritten in that case.

Measured behaviours worth knowing
---------------------------------

**``-VerificationStatus`` is case-insensitive but its casing survives.**  A
``ValidateSet`` accepts ``PASS``, and ``$VerificationStatus`` then keeps that
spelling: the branch still compares equal (PowerShell string ``-eq`` ignores
case) but the fallback evidence line reads ``post-merge verification status:
PASS``.  So the port validates case-insensitively, compares case-insensitively,
and echoes the argument as given.

**``-Profile`` is not defaulted, ``-AutoMergedBy`` is.**  A blank ``-Profile``
lands in the document as ``""`` even though the schema wants ``minLength: 1``,
while a blank ``-AutoMergedBy`` becomes ``"unknown"``.

**Blank entries are filtered, not trimmed.**  ``-Evidence`` and ``-Labels`` drop
whitespace-only items; ``-ChangedPaths`` additionally splits each item on commas
and trims the pieces, so ``"a/b,c/d"`` becomes two paths and ``"  , g/h "``
becomes one.

What is deliberately *not* reproduced
-------------------------------------

``ConvertTo-Json``'s bytes and ``Set-Content``'s BOM/CRLF, as everywhere else in
this package -- see ``gate_support.write_json_report``.  The ``createdAt``
format is reproduced as far as it is observable: ``Get-Date).ToUniversalTime()
.ToString("o")`` emits seven fractional digits, so the port emits six from
``datetime`` plus a trailing ``0`` rather than ``isoformat()``'s six and an
offset.  The parity test normalises the field, since no caller can depend on the
instant it was written.
"""

from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable

from .gate_support import GateResult, is_blank, ps_string, write_json_report

RELEASE_SCHEMA_VERSION = "release-event/v1"
INCIDENT_SCHEMA_VERSION = "incident-event/v1"
PASS_MARKER = "POST_MERGE_MONITOR_PASS"
INCIDENT_MARKER = "POST_MERGE_MONITOR_INCIDENT"

# `ValidateSet("pass", "fail", "inconclusive")` -- matched case-insensitively.
VERIFICATION_STATUSES = ("pass", "fail", "inconclusive")

UNKNOWN_ACTOR = "unknown"
DEFAULT_ROLLBACK_TEMPLATE = (
    "Open a rollback PR for {commit_sha} after human review if the incident is "
    "confirmed."
)


def _utc_now() -> str:
    """``[DateTime]::UtcNow.ToString("o")`` -- seven fractional digits, ``Z``."""
    now = datetime.now(timezone.utc)
    return f"{now.strftime('%Y-%m-%dT%H:%M:%S')}.{now.microsecond:06d}0Z"


def _split_paths(items: Iterable[str]) -> list[str]:
    """``$ChangedPaths | % { ([string]$_).Split(",") } | % { $_.Trim() }`` + filter."""
    paths: list[str] = []
    for item in items:
        for piece in ps_string(item).split(","):
            trimmed = piece.strip()
            if not is_blank(trimmed):
                paths.append(trimmed)
    return paths


def run_post_merge_monitor(
    repo: str,
    pr_number: int,
    commit_sha: str,
    verification_status: str = "inconclusive",
    failed_command: str = "",
    evidence: Iterable[str] = (),
    rollback_recommendation: str = "",
    profile: str = UNKNOWN_ACTOR,
    labels: Iterable[str] = (),
    changed_paths: Iterable[str] = (),
    auto_merged_by: str = UNKNOWN_ACTOR,
    release_event_path: str | Path = "",
    incident_event_path: str | Path = "",
    output_path: str | Path = "",
) -> GateResult:
    """Emit the release or incident event for one merged pull request.

    Raises ``ValueError`` for a status outside :data:`VERIFICATION_STATUSES`;
    the reference rejects it at the parameter binder, so no body behaviour
    exists to copy.
    """
    status = str(verification_status)
    if status.lower() not in VERIFICATION_STATUSES:
        raise ValueError(
            f"verification_status must be one of {VERIFICATION_STATUSES}, got {status!r}"
        )
    passed = status.lower() == "pass"

    evidence_items = [item for item in evidence if not is_blank(item)]
    if not evidence_items:
        # The fallback echoes the argument's own casing, not the canonical one.
        evidence_items = [f"post-merge verification status: {status}"]

    rollback = (
        DEFAULT_ROLLBACK_TEMPLATE.format(commit_sha=commit_sha)
        if is_blank(rollback_recommendation)
        else rollback_recommendation
    )
    label_items = [item for item in labels if not is_blank(item)]
    auto_merge_actor = UNKNOWN_ACTOR if is_blank(auto_merged_by) else auto_merged_by

    release: dict[str, Any] = {
        "schemaVersion": RELEASE_SCHEMA_VERSION,
        "repo": repo,
        "prNumber": pr_number,
        "commitSha": commit_sha,
        "status": "healthy" if passed else "incident",
        "checks": evidence_items,
        "profile": profile,
        "labels": label_items,
        "rollbackRecommendation": "" if passed else rollback,
        "createdAt": _utc_now(),
    }
    release_text = json.dumps(release, indent=2, ensure_ascii=False)
    if release_event_path:
        write_json_report(release_event_path, release_text)

    if passed:
        if output_path:
            write_json_report(output_path, release_text)
        return GateResult(0, release_text, extra_lines=(PASS_MARKER,))

    incident: dict[str, Any] = {
        "schemaVersion": INCIDENT_SCHEMA_VERSION,
        "repo": repo,
        "prNumber": pr_number,
        "commitSha": commit_sha,
        "severity": "high" if status.lower() == "fail" else "medium",
        "summary": f"Post-merge verification did not pass for {repo}#{pr_number}.",
        "failedCommand": failed_command,
        "evidence": evidence_items,
        "rollbackRecommendation": rollback,
        "profile": profile,
        "labels": label_items,
        "changedPaths": _split_paths(changed_paths),
        "autoMergedBy": auto_merge_actor,
        "createdAt": _utc_now(),
    }
    incident_text = json.dumps(incident, indent=2, ensure_ascii=False)
    target = incident_event_path or output_path
    if target:
        write_json_report(target, incident_text)
    return GateResult(2, incident_text, extra_lines=(INCIDENT_MARKER,))
