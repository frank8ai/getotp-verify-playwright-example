"""Port of ``collect-verification-evidence.ps1``.

The collector folds one or more ``verification-evidence/v1`` documents into a
single ``verification-evidence-collection/v1`` report: counts per status, a
PASS/FAIL decision, and the list of inputs that were not a pass.  Two things
about it are load-bearing.

**It redacts before it parses.**  The raw file text goes through five regexes
first, so a secret that appears inside a JSON string is already replaced by the
time ``ConvertFrom-Json`` runs -- the parsed value differs from what is on
disk, on purpose.  The patterns never consume a quote, so the redaction is
supposed to leave the document parseable.  It does not always: a value preceded
by an escaped quote, as in ``"note": "password: \\"x\\""``, matches the
key/value pattern up to the backslash and leaves an unterminated string, and
the reference then fails with a JSON error.  The port reproduces that, because
a caller must not start seeing a pass where the reference refused.

**``@($value).Count`` is not ``len``.**  A *missing* ``checks`` key becomes a
one-element array holding ``$null``, and piping that array to ``Where-Object``
does deliver the ``$null`` -- so a document with no ``checks`` at all reports
``checkCount = 1`` **and** ``failedCount = 1``, rather than zero checks.  The
same ``$null`` makes ``$checks.Count -eq 0`` false, so the "no checks" block is
reached by an *empty array*, not by a missing key.

**A blank file is not "invalid json".**  ``ConvertFrom-Json ""`` returns
``$null`` without throwing, so an empty, whitespace-only, or BOM-only file
falls through to the schemaVersion check and is reported as ``Unsupported
verification evidence schema``.  So are ``null``, ``[]``, a bare string, and a
bare number: reading a property off any of them yields ``$null``, which is not
the expected version.

Measured behaviours encoded here
--------------------------------

Aggregation, with the check-status comparisons taken from
``gate_support.ps_equals`` (PowerShell's ``-eq`` takes its type from the left
operand, and on a collection it filters):

    check                              passed  failed  notRun  inconclusive
    ---------------------------------  ------  ------  ------  ------------
    {"status":"pass","exitCode":0}     1       0       0       0
    {"status":"pass"}                  0       1       0       0
    {"status":"pass","exitCode":false} 1       0       0       0
    {"status":"pass","exitCode":true}  0       1       0       0
    {"status":"pass","exitCode":"0"}   1       0       0       0
    {"status":"pass","exitCode":"00"}  0       1       0       0
    {"status":"fail","exitCode":0}     0       1       0       0
    {"status":["pass"],"exitCode":0}   1       0       0       0
    {"status":1,"exitCode":0}          0       0       0       0
    {"status":null,"exitCode":0}       0       0       0       0
    {"status":"PASS","exitCode":0}     1       0       0       0
    null (a missing element)           0       1       0       0

A check with no ``exitCode`` therefore counts as *failed* (``$null -ne 0`` is
true), while one with no ``status`` counts as *neither* -- a hole that lets an
unlabelled check through when the document decision is PASS.

``decision`` is compared with ``-ne``, so ``true`` and ``["PASS"]`` both count
as a pass (the right operand is coerced to the left's type), while ``1`` and
``{}`` do not.

What is deliberately *not* modelled
-----------------------------------

``ConvertTo-Json``'s exact bytes.  PowerShell 5.1 indents with four spaces,
puts two spaces after each colon, escapes non-ASCII as ``\\uXXXX`` and writes
``-Encoding UTF8`` with a BOM; pwsh 7 differs on all four.  None of that is a
contract a caller can rely on, so the parity test compares *parsed* documents
(with ``generatedAt`` normalised) and the port emits plain
``json.dumps(..., indent=2)`` UTF-8 without a BOM.

The text of a JSON parse failure, for the same reason: the reference reports
the .NET serializer's message.  Both implementations exit 1 with the reason on
stderr.

An empty ``-EvidencePaths``.  The reference's parameter binder rejects it
before the body runs ("Cannot bind argument to parameter 'EvidencePaths'
because it is an empty array"), so the body's zero-path behaviour is
unreachable and there is nothing to copy.  :func:`collect_verification_evidence`
raises ``ValueError`` and the CLI requires at least one path.
"""

from __future__ import annotations

import json
import os
import re
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from .gate_support import (
    GateResult,
    parse_document,
    ps_equals,
    ps_member,
    ps_not_equals,
    write_json_report,
)

EVIDENCE_SCHEMA_VERSION = "verification-evidence/v1"
COLLECTION_SCHEMA_VERSION = "verification-evidence-collection/v1"
COLLECTED_MARKER = "VERIFICATION_EVIDENCE_COLLECTED"

# Applied in this order, to the raw text, before parsing.  Kept as literals
# rather than rewritten, so a future reader can diff them against the shell
# original line by line.
REDACTIONS: tuple[tuple[re.Pattern[str], str], ...] = (
    (
        re.compile(r"(?i)Authorization\s*:\s*Bearer\s+[A-Za-z0-9._~+/=-]+"),
        "Authorization: Bearer [REDACTED]",
    ),
    (
        re.compile(r"(?i)\bBearer\s+[A-Za-z0-9._~+/=-]{8,}"),
        "Bearer [REDACTED]",
    ),
    # Case-sensitive in the reference: no (?i) on this one.
    (
        re.compile(r"\bsk-[A-Za-z0-9_-]{8,}"),
        "sk-[REDACTED]",
    ),
    (
        re.compile(r"(?i)\b(ghp|github_pat)_[A-Za-z0-9_]{8,}"),
        r"\1_[REDACTED]",
    ),
    (
        re.compile(r'(?i)\b(api[_-]?key|token|secret|password)\s*[:=]\s*["\x27]?[^"\x27,\s}\]]+'),
        r"\1=[REDACTED]",
    ),
)


def redact_secret_like_text(text: str | None) -> str:
    """Replace credential-shaped substrings the way the reference does."""
    if text is None:
        return ""
    safe = text
    for pattern, replacement in REDACTIONS:
        safe = pattern.sub(replacement, safe)
    return safe


def _checks_of(document: Any) -> list[Any]:
    """``@($item.checks)`` -- a missing key is a one-element array of ``$null``.

    That single fact is why a document without a ``checks`` key reports one
    check, and one failure, instead of zero of each.
    """
    value = ps_member(document, "checks")
    if value is None:
        return [None]
    if isinstance(value, list):
        return list(value)
    return [value]


def _is_passed(check: Any) -> bool:
    """``$_.status -eq "pass" -and $_.exitCode -eq 0``."""
    return ps_equals(ps_member(check, "status"), "pass") and ps_equals(
        ps_member(check, "exitCode"), 0
    )


def _is_failed(check: Any) -> bool:
    """``$_.status -eq "fail" -or $_.exitCode -ne 0``."""
    return ps_equals(ps_member(check, "status"), "fail") or ps_not_equals(
        ps_member(check, "exitCode"), 0
    )


def _generated_at() -> str:
    """``[DateTimeOffset]::Now.ToString("o")``."""
    return datetime.now(timezone.utc).astimezone().isoformat()


def collect_verification_evidence(
    evidence_paths: list[str] | tuple[str, ...],
    output_path: str | Path = "",
) -> GateResult:
    """Collect evidence documents into one report, optionally writing it out.

    Returns exit 0 for a clean collection, exit 2 when any input was not a
    pass, and exit 1 (reason on stderr) when an input could not be used at all.
    """
    paths = [str(path) for path in evidence_paths]
    if not paths:
        raise ValueError("evidence_paths must contain at least one path")

    items: list[Any] = []
    non_pass: list[str] = []
    source_paths: list[str] = []
    check_count = 0
    passed_count = 0
    failed_count = 0
    not_run_count = 0
    inconclusive_count = 0

    for path in paths:
        target = Path(path)
        if not target.exists():
            return _thrown(f"Missing verification evidence: {path}")

        source_paths.append(os.path.abspath(path))

        try:
            text = target.read_text(encoding="utf-8-sig", errors="replace")
        except OSError as exc:
            # The reference reaches this through a throwing `Get-Content -Raw`
            # (a directory, a permission failure); the message is the host's.
            return _thrown(f"cannot read verification evidence: {path} ({exc})")

        # `parse_document` keeps the blank-file case honest: `ConvertFrom-Json ""`
        # returns `$null` without throwing, so an empty file reaches the
        # schemaVersion check rather than being called malformed JSON.
        item, parse_error = parse_document(redact_secret_like_text(text))
        if parse_error:
            return _thrown(f"invalid json: {path}")

        if ps_not_equals(ps_member(item, "schemaVersion"), EVIDENCE_SCHEMA_VERSION):
            return _thrown(f"Unsupported verification evidence schema: {path}")

        items.append(item)

        checks = _checks_of(item)
        check_count += len(checks)
        passed_count += sum(1 for check in checks if _is_passed(check))
        failed_checks = [check for check in checks if _is_failed(check)]
        failed_count += len(failed_checks)
        not_run_count += sum(
            1 for check in checks if ps_equals(ps_member(check, "status"), "not_run")
        )
        inconclusive_count += sum(
            1 for check in checks if ps_equals(ps_member(check, "status"), "inconclusive")
        )

        if (
            ps_not_equals(ps_member(item, "decision"), "PASS")
            or failed_checks
            or len(checks) == 0
        ):
            non_pass.append(path)

    document = {
        "schemaVersion": COLLECTION_SCHEMA_VERSION,
        "generatedAt": _generated_at(),
        "decision": "PASS" if not non_pass else "FAIL",
        "summary": {
            "evidenceCount": len(items),
            "checkCount": check_count,
            "passedCount": passed_count,
            "failedCount": failed_count,
            "notRunCount": not_run_count,
            "inconclusiveCount": inconclusive_count,
            "sourcePaths": source_paths,
        },
        "evidence": items,
        "blockedReasons": [f"non-pass verification evidence: {path}" for path in non_pass],
    }

    text = json.dumps(document, indent=2, ensure_ascii=False)

    if output_path:
        # `Set-Content` appends a line terminator; the BOM it also writes in
        # PowerShell 5.1 is deliberately dropped (see the module docstring).
        write_json_report(output_path, text)

    return GateResult(0 if not non_pass else 2, text, extra_lines=(COLLECTED_MARKER,))


def _thrown(reason: str) -> GateResult:
    """An uncaught ``throw``: the reason on stderr, exit 1, empty stdout."""
    return GateResult(1, reason, to_stderr=True)
