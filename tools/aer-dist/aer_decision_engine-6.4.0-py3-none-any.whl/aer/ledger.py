"""Known-failure ledger audit, ported from scripts/audit-known-failures.ps1.

The ledger records time-boxed test exemptions. This module validates the
mandatory fields and, when enforcing expiry, rejects any record whose
expiresAt has passed.
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path

LEDGER_SCHEMA_VERSION = "known-failure-ledger/v1"
_VALID_STATUSES = {"ACTIVE_EXEMPTION", "EXPIRED_EXEMPTION", "RESOLVED"}


class LedgerError(ValueError):
    """Raised when the ledger is malformed or has expired exemptions."""


@dataclass(frozen=True)
class LedgerAudit:
    active_count: int
    expired_count: int
    path: str


def _parse_timestamp(value: str) -> datetime:
    text = value.strip()
    if text.endswith("Z"):
        text = text[:-1] + "+00:00"
    parsed = datetime.fromisoformat(text)
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=timezone.utc)
    return parsed


def audit_ledger(
    ledger_path: str | Path = "config/known-failures.json",
    *,
    enforce_expiry: bool = False,
    now: datetime | None = None,
) -> LedgerAudit:
    path = Path(ledger_path)
    if not path.exists():
        raise LedgerError(f"Ledger not found: {ledger_path}")

    with path.open("r", encoding="utf-8") as handle:
        ledger = json.load(handle)

    if ledger.get("schemaVersion") != LEDGER_SCHEMA_VERSION:
        raise LedgerError(f"Unsupported schemaVersion: {ledger.get('schemaVersion')}")

    records = ledger.get("records")
    if not isinstance(records, list):
        raise LedgerError("Ledger 'records' must be a list")

    moment = now or datetime.now(timezone.utc)
    active_count = 0
    expired_count = 0

    for record in records:
        for field in ("testId", "failureFingerprint", "expiresAt"):
            if not record.get(field):
                raise LedgerError(f"Record missing mandatory field '{field}': {record}")
        status = record.get("status")
        if status not in _VALID_STATUSES:
            raise LedgerError(f"Record has invalid status '{status}': {record}")

        expires = _parse_timestamp(record["expiresAt"])
        if moment > expires:
            expired_count += 1
        else:
            active_count += 1

    if enforce_expiry and expired_count > 0:
        raise LedgerError(
            "KNOWN_FAILURE_LEDGER_HAS_EXPIRED_RECORDS: "
            f"count={expired_count} (requires human audit or resolution)"
        )

    return LedgerAudit(active_count=active_count, expired_count=expired_count, path=str(path))
