"""Command line entry point: python -m aer evaluate ..."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from .antithesis import analyze_diff_files, analyze_git_diff, load_added_test_files
from .closure import ClosureError, run_closure, verify_gate_logs, write_evidence
from .distiller import distill_pytest_log
from .orchestrator_permissions import (
    DEFAULT_MANIFEST_PATH,
    MODES,
    PROFILES,
)
from .post_merge_monitor import VERIFICATION_STATUSES
from .repomap import build_repo_map
from .review.engine import analyze as review_analyze
from .review.engine import adjudicate as review_adjudicate
from .review.engine import render_evidence as review_render_evidence
from .review.perspective import build_perspective_report
from .review.adapters.ocr import (
    cross_check_selection as ocr_cross_check_selection,
)
from .decision import (
    EvidenceBundle,
    TaskContract,
    evaluate_decision,
    policy_hash,
)


def _read_json(path: str | None) -> dict | None:
    if not path:
        return None
    return json.loads(Path(path).read_text(encoding="utf-8-sig"))


def _write_json(path: str, payload: dict) -> None:
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(
        json.dumps(payload, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )


def antithesis(args: argparse.Namespace) -> int:
    if args.base_sha:
        try:
            report = analyze_git_diff(
                args.base_sha,
                cwd=args.cwd,
                allow_protected=args.allow_protected,
            )
        except Exception as exc:  # pragma: no cover - exercised via CLI tests
            print(f"Unable to inspect git diff: {exc}", file=sys.stderr)
            return 2
        if args.touched_path:
            # `git diff BASE...HEAD` and the caller-supplied path list are both
            # authoritative signals; merge them so neither source hides the other.
            path_report = analyze_diff_files(
                touched_paths=args.touched_path,
                allow_protected=args.allow_protected,
            )
            report.findings.extend(path_report.findings)
            if path_report.status == "HUMAN_REQUIRED":
                report.status = "HUMAN_REQUIRED"
            elif path_report.status == "DENY" and report.status == "PASS":
                report.status = "DENY"
    else:
        added_tests = load_added_test_files(args.test_file)
        report = analyze_diff_files(
            added_test_files=added_tests,
            touched_paths=args.touched_path,
            allow_protected=args.allow_protected,
        )

    payload = report.to_dict()
    payload["decision"] = report.status
    if args.output:
        _write_json(args.output, payload)

    print(f"ANTITHESIS: {report.status}")
    print(json.dumps(payload, ensure_ascii=False))
    if report.status == "PASS":
        return 0
    # DENY and HUMAN_REQUIRED both stop automation; they differ in routing.
    return 1


def evaluate(args: argparse.Namespace) -> int:
    policy_path = Path(args.policy)
    if not policy_path.exists():
        print(f"Policy file not found: {policy_path}", file=sys.stderr)
        return 2

    contract = TaskContract.from_mapping(_read_json(args.task_contract))
    evidence = EvidenceBundle.from_mapping(_read_json(args.evidence))
    result = evaluate_decision(contract, evidence, policy_hash(policy_path))
    payload = result.to_dict()

    if args.output:
        _write_json(args.output, payload)

    prefix = "[SHADOW_MODE] DECISION: " if args.shadow_mode else "DECISION: "
    print(f"{prefix}{result.decision.value} | Job: {result.job_id}")
    print(json.dumps(payload, ensure_ascii=False))
    return 0


def verify(args: argparse.Namespace) -> int:
    """Run the manifest gates and write full verification-closure evidence."""
    try:
        run = run_closure(
            repo=args.repo,
            baseline_path=args.baseline or None,
            tier=args.tier,
            secrets_found=args.secrets_found,
            sandbox_driver=getattr(args, "sandbox_driver", None) or None,
            customer_code_mode=getattr(args, "customer_code", False),
        )
    except ClosureError as exc:
        print(f"aer verify: {exc}", file=sys.stderr)
        return 2

    output = args.output or f".verification/evidence-{run.evidence['runId'] or 'local'}.json"
    write_evidence(run.evidence, output)

    surface = run.evidence["causalAttribution"]["surfaceDelta"]
    print(
        "RVCE_VERIFICATION_COMPLETE: "
        f"verdict={run.verdict} "
        f"(newFailures={run.evidence['causalAttribution']['failureDeltaCount']}, "
        f"surfaceIntact={surface['isSurfaceIntact']}, "
        f"envEquivalent={run.evidence['causalAttribution']['environmentDelta']['isEquivalent']})"
    )
    print(json.dumps(run.evidence, ensure_ascii=False))
    return run.exit_code


def gate(args: argparse.Namespace) -> int:
    """CI entry point: emit the verdict and exit non-zero unless it is PASS.

    When ``--evidence`` points at an already-produced evidence document the
    verdict is recomputed from it instead of re-running the gates, so a CI job
    can gate on a verified artifact without paying for a second full run.
    """
    if args.evidence:
        evidence_path = Path(args.evidence)
        if not evidence_path.is_file():
            print(f"Evidence file not found: {evidence_path}", file=sys.stderr)
            return 2
        evidence = json.loads(evidence_path.read_text(encoding="utf-8-sig"))
        verdict = str(evidence.get("verdict") or "")
        log_findings = verify_gate_logs(evidence, base_dir=args.repo)
        if log_findings and verdict == "PASS":
            verdict = "FAIL"
            evidence["verdict"] = "FAIL"
    else:
        try:
            run = run_closure(
                repo=args.repo,
                baseline_path=args.baseline or None,
                tier=args.tier,
                secrets_found=args.secrets_found,
                sandbox_driver=getattr(args, "sandbox_driver", None) or None,
                customer_code_mode=getattr(args, "customer_code", False),
                allow_protected=getattr(args, "allow_protected", False),
            )
        except ClosureError as exc:
            print(f"aer gate: {exc}", file=sys.stderr)
            return 2
        evidence = run.evidence
        verdict = run.verdict
        if args.output:
            write_evidence(evidence, args.output)

    print(f"AER_GATE: {verdict}")
    print(json.dumps(evidence, ensure_ascii=False))
    return 0 if verdict == "PASS" else 1


def accept(args: argparse.Namespace) -> int:
    """Run baseline vs candidate change acceptance (Task E2) and emit evidence."""
    if args.evidence:
        evidence_path = Path(args.evidence)
        if not evidence_path.is_file():
            print(f"Evidence file not found: {evidence_path}", file=sys.stderr)
            return 2
        payload = json.loads(evidence_path.read_text(encoding="utf-8-sig"))
        verdict = str(payload.get("verdict") or "UNKNOWN")
    else:
        from .change_acceptance import run_change_acceptance

        try:
            report = run_change_acceptance(
                repo=args.repo,
                base_ref=args.base,
                candidate_ref=args.candidate,
                reproduce_command=args.reproduce_command,
                contract_path=getattr(args, "contract_path", None) or None,
                tier=args.tier,
                sandbox_driver=args.sandbox_driver or "docker",
                customer_code_mode=args.customer_code,
                docker_image=getattr(args, "docker_image", "python:3.12-slim"),
            )
        except Exception as exc:
            print(f"aer accept: {exc}", file=sys.stderr)
            return 2

        payload = report.to_dict()
        verdict = report.verdict
        if args.output:
            out_path = Path(args.output)
            out_path.parent.mkdir(parents=True, exist_ok=True)
            out_path.write_text(json.dumps(payload, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")

        if getattr(args, 'brief', None):
            brief_text = report.render_brief()
            brief_path = Path(args.brief)
            brief_path.parent.mkdir(parents=True, exist_ok=True)
            brief_path.write_text(brief_text + '\n', encoding='utf-8')

        if getattr(args, 'telemetry', None):
            from .telemetry import record_acceptance_telemetry
            record_acceptance_telemetry(
                report,
                output_path=args.telemetry,
                human_decision=getattr(args, 'human_decision', None),
                human_override=getattr(args, 'human_override', False),
                reviewer_acceptance_minutes=getattr(args, 'reviewer_minutes', None),
                override_reason=getattr(args, 'override_reason', None),
            )

    reasons_str = f" reasons={payload.get('reasons')}" if payload.get("reasons") else ""
    print(f"AER_ACCEPTANCE: {verdict}{reasons_str}")
    print(json.dumps(payload, ensure_ascii=False))
    if verdict == "PASS":
        return 0
    elif verdict == "FAIL":
        return 1
    else:
        return 2


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="python -m aer")
    subparsers = parser.add_subparsers(dest="command", required=True)

    evaluate_parser = subparsers.add_parser(
        "evaluate",
        help="Evaluate one task contract and evidence bundle.",
    )
    evaluate_parser.add_argument("--task-contract", default="")
    evaluate_parser.add_argument("--evidence", default="")
    evaluate_parser.add_argument(
        "--policy",
        default="policies/relayon-automation-policy.json",
    )
    evaluate_parser.add_argument("--output", default="")
    evaluate_parser.add_argument("--shadow-mode", action="store_true")
    evaluate_parser.set_defaults(handler=evaluate)

    antithesis_parser = subparsers.add_parser(
        "antithesis",
        help="Reject added tests that cannot fail (anti-tautology guard).",
    )
    antithesis_parser.add_argument(
        "--base-sha",
        default="",
        help="Inspect git diff BASE_SHA...HEAD for added tests and touched paths.",
    )
    antithesis_parser.add_argument(
        "--test-file",
        action="append",
        default=[],
        help="Added test file to inspect; repeat for multiple files.",
    )
    antithesis_parser.add_argument(
        "--touched-path",
        action="append",
        default=[],
        help="Touched path to screen for protected surfaces; repeat as needed.",
    )
    antithesis_parser.add_argument("--cwd", default=".")
    antithesis_parser.add_argument("--output", default="")
    antithesis_parser.add_argument(
        "--allow-protected",
        action="store_true",
        help="Report protected surfaces without failing (audit mode).",
    )
    antithesis_parser.set_defaults(handler=antithesis)

    verify_parser = subparsers.add_parser(
        "verify",
        help="Run the manifest gates and write verification-closure evidence.",
    )
    verify_parser.add_argument("--repo", default=".")
    verify_parser.add_argument(
        "--baseline",
        default="",
        help="Trusted baseline JSON; its tier overrides --tier when present.",
    )
    verify_parser.add_argument("--tier", default="cheap", choices=["cheap", "full"])
    verify_parser.add_argument("--output", default="")
    verify_parser.add_argument(
        "--secrets-found",
        action="store_true",
        help="Mark the security check as failed (scan runs outside this command).",
    )
    verify_parser.add_argument(
        "--sandbox-driver",
        default="",
        help="Sandbox driver to execute gates (docker, worktree, local).",
    )
    verify_parser.add_argument(
        "--customer-code",
        action="store_true",
        help="Customer code mode: strictly enforce container isolation and fail closed.",
    )
    verify_parser.set_defaults(handler=verify)

    gate_parser = subparsers.add_parser(
        "gate",
        help="CI gate entry point: exit non-zero unless the verdict is PASS.",
    )
    gate_parser.add_argument("--repo", default=".")
    gate_parser.add_argument("--baseline", default="")
    gate_parser.add_argument("--tier", default="cheap", choices=["cheap", "full"])
    gate_parser.add_argument(
        "--evidence",
        default="",
        help="Gate on an existing evidence document instead of re-running gates.",
    )
    gate_parser.add_argument("--output", default="")
    gate_parser.add_argument(
        "--secrets-found",
        action="store_true",
        help="Mark the security check as failed (scan runs outside this command).",
    )
    gate_parser.add_argument(
        "--sandbox-driver",
        default="",
        help="Sandbox driver to execute gates (docker, worktree, local).",
    )
    gate_parser.add_argument(
        "--customer-code",
        action="store_true",
        help="Customer code mode: strictly enforce container isolation and fail closed.",
    )
    gate_parser.add_argument(
        "--allow-protected",
        action="store_true",
        help="Allow human-reviewed changes to protected surfaces.",
    )
    gate_parser.set_defaults(handler=gate)

    accept_parser = subparsers.add_parser(
        "accept",
        help="Verify executable change acceptance (baseline vs candidate differential).",
    )
    accept_parser.add_argument("--repo", default=".")
    accept_parser.add_argument("--base", default="", help="Base commit SHA or ref")
    accept_parser.add_argument("--candidate", default="", help="Candidate commit SHA or ref")
    accept_parser.add_argument("--reproduce-command", default="", help="Reproduction command (internal/fallback use)")
    accept_parser.add_argument("--contract-path", default="", help="Path to trusted acceptance contract YAML")
    accept_parser.add_argument("--tier", default="cheap", choices=["cheap", "full"])
    accept_parser.add_argument("--evidence", default="", help="Evaluate existing acceptance evidence")
    accept_parser.add_argument("--output", default="", help="Output evidence JSON path")
    accept_parser.add_argument("--sandbox-driver", default="docker", help="Sandbox driver (docker, worktree, local)")
    accept_parser.add_argument("--customer-code", action="store_true", help="Enforce customer code container isolation")
    accept_parser.add_argument("--docker-image", default="python:3.12-slim", help="Docker image for sandbox")
    accept_parser.add_argument("--brief", default="", help="Path to write Markdown Acceptance Brief")
    accept_parser.add_argument("--telemetry", default="", help="Path to append JSONL pilot telemetry")
    accept_parser.add_argument("--reviewer-minutes", type=float, default=None, help="Reviewer duration in minutes")
    accept_parser.add_argument("--human-decision", default=None, help="Human reviewer decision (ACCEPTED, REJECTED)")
    accept_parser.add_argument("--human-override", action="store_true", help="Flag as human override")
    accept_parser.add_argument("--override-reason", default=None, help="Reason for human override")
    accept_parser.set_defaults(handler=accept)
    distill_parser = subparsers.add_parser(
        "distill",
        help="Distill verbose test output into a structured Failure Card.",
    )
    distill_parser.add_argument("log_file", nargs="?", default="", help="Path to raw failure log")
    distill_parser.add_argument("--text", default="", help="Raw error text to distill directly")
    distill_parser.add_argument("--output", default="", help="Optional JSON output path")
    distill_parser.add_argument("--max-failures", type=int, default=5, help="Max failure blocks to extract")
    distill_parser.set_defaults(handler=distill)

    repomap_parser = subparsers.add_parser(
        "repomap",
        help="Generate lightweight static AST Repo Map without background daemons.",
    )
    repomap_parser.add_argument("--repo", default=".", help="Repository root directory")
    repomap_parser.add_argument(
        "--target",
        action="append",
        default=[],
        help="Target file(s) to prioritize in the map",
    )
    repomap_parser.add_argument(
        "--budget-tokens",
        type=int,
        default=1500,
        help="Token budget limit for skeleton extraction",
    )
    repomap_parser.add_argument("--output", default="", help="Output path for the generated map")
    repomap_parser.set_defaults(handler=repomap)

    triage_parser = subparsers.add_parser(
        "triage",
        help="Deterministically classify a failure trace before model invocation.",
    )
    triage_parser.add_argument("log_file", nargs="?", default="", help="Path to failure log file")
    triage_parser.add_argument("--text", default="", help="Raw error text to triage directly")
    triage_parser.add_argument("--output", default="", help="Optional JSON output destination")
    triage_parser.set_defaults(handler=triage)

    review_parser = subparsers.add_parser(
        "review",
        help="Run the deterministic AER review engine over a change set.",
    )
    review_parser.add_argument(
        "review_action",
        choices=["analyze", "adjudicate", "evidence", "perspective"],
        help=(
            "analyze: deterministic, no model call. "
            "adjudicate: deterministic only in this CLI (host agent runs outside). "
            "evidence: emit a review-evidence/v1 document."
        ),
    )
    review_parser.add_argument(
        "--mode",
        default="workspace",
        choices=["workspace", "range", "commit", "scan"],
    )
    review_parser.add_argument("--from", dest="from_ref", default="")
    review_parser.add_argument("--to", dest="to_ref", default="")
    review_parser.add_argument("--commit", default="")
    review_parser.add_argument("--repo", default=".")
    review_parser.add_argument(
        "--path",
        action="append",
        default=[],
        help="Restrict review to a path; repeat for multiple paths.",
    )
    review_parser.add_argument(
        "--exclude",
        action="append",
        default=[],
        help="Additional exclusion pattern; repeat for multiple patterns.",
    )
    review_parser.add_argument("--rule", dest="rule_path", default="")
    review_parser.add_argument(
        "--role",
        default="scope-safety",
        help="Role recorded in the emitted review-evidence document.",
    )
    review_parser.add_argument(
        "--ocr-cross-check",
        action="store_true",
        help="Cross-check selection with the optional ocr CLI when available.",
    )
    review_parser.add_argument("--output", default="")
    review_parser.add_argument("--format", choices=["markdown", "json"], default="markdown")
    review_parser.set_defaults(handler=review)

    state_parser = subparsers.add_parser(
        "state",
        help=(
            "Drive the durable orchestrator state store "
            "(Python replacement for agent-orchestrator-state.ps1)."
        ),
    )
    state_parser.add_argument(
        "state_action",
        choices=[
            "Get", "Set", "IncrementAttempt", "AcquireLock", "ReleaseLock", "Validate",
        ],
        help="Action to perform against the per-issue state record.",
    )
    state_parser.add_argument("--repo-key", default="")
    state_parser.add_argument("--issue-number", type=int, default=0)
    state_parser.add_argument("--status", default="")
    state_parser.add_argument("--reason", default="")
    state_parser.add_argument(
        "--state-root",
        default=".agent-orchestrator/state",
        help="Directory holding per-issue state JSON documents.",
    )
    state_parser.add_argument(
        "--lock-root",
        default=".agent-orchestrator/locks",
        help="Directory holding per-issue lock files.",
    )
    state_parser.add_argument("--max-attempts", type=int, default=2)
    state_parser.set_defaults(handler=state)

    readiness_parser = subparsers.add_parser(
        "ship-readiness",
        help="Merge gate: block unless ci/review/qa evidence is complete.",
    )
    readiness_parser.add_argument(
        "--ship-readiness-path",
        default="",
        help="Path to the ship-readiness document; omit for the default location.",
    )
    readiness_parser.set_defaults(handler=ship_readiness)

    guard_parser = subparsers.add_parser(
        "command-guard",
        help="Authorize an @aer-bot command comment before acting on it.",
    )
    guard_parser.add_argument("--payload-path", default="")
    guard_parser.add_argument("--comment-author", default="")
    guard_parser.add_argument("--author-association", default="")
    guard_parser.add_argument("--comment-body", default="")
    guard_parser.set_defaults(handler=command_guard)

    evidence_parser = subparsers.add_parser(
        "evidence-gate",
        help="Validate a review / tdd / debugging evidence document.",
    )
    evidence_parser.add_argument(
        "kind",
        choices=["review", "tdd", "debugging"],
        help="Which evidence schema to validate.",
    )
    evidence_parser.add_argument("--path", required=True)
    evidence_parser.set_defaults(handler=evidence_gate)

    brief_parser = subparsers.add_parser(
        "requirement-brief",
        help="Validate a requirement brief before it enters the agent workflow.",
    )
    brief_parser.add_argument("--brief-path", required=True)
    brief_parser.add_argument(
        "--schema-path",
        default="./schemas/requirement-brief.schema.json",
        help="Schema the reference checks for existence before reading the brief.",
    )
    brief_parser.set_defaults(handler=requirement_brief)

    scope_parser = subparsers.add_parser(
        "work-unit-scope",
        help="Check that a change stays inside its declared work-unit slice.",
    )
    scope_parser.add_argument("--work-unit-path", required=True)
    scope_parser.add_argument("--changed-files", type=int, default=0)
    scope_parser.add_argument("--diff-lines", type=int, default=0)
    scope_parser.add_argument(
        "--changed-file-path",
        action="append",
        default=[],
        help="Repeatable; the reference also accepts these as trailing arguments.",
    )
    scope_parser.set_defaults(handler=work_unit_scope)

    permissions_parser = subparsers.add_parser(
        "orchestrator-permissions",
        help="Resolve the GitHub App identity and permission for a profile + mode.",
    )
    # `ValidateSet` in the reference is case-insensitive, so lowercase the
    # value before argparse checks it against the choices.
    permissions_parser.add_argument("--profile", required=True, type=str.lower,
                                    choices=sorted(PROFILES))
    permissions_parser.add_argument("--mode", required=True, type=str.lower,
                                    choices=sorted(MODES))
    permissions_parser.add_argument(
        "--manifest-path",
        default=DEFAULT_MANIFEST_PATH,
        help="Manifest the reference resolves the App configuration from.",
    )
    permissions_parser.set_defaults(handler=orchestrator_permissions)

    collect_parser = subparsers.add_parser(
        "evidence-collect",
        help="Fold verification-evidence documents into one collection report.",
    )
    collect_parser.add_argument(
        "--evidence-path",
        dest="evidence_paths",
        action="append",
        required=True,
        help="Repeatable. The reference rejects an empty list at the parameter binder.",
    )
    collect_parser.add_argument("--output-path", default="")
    collect_parser.set_defaults(handler=evidence_collect)

    learning_parser = subparsers.add_parser(
        "learning-loop",
        help="Aggregate failure events into a reviewable learning proposal.",
    )
    learning_parser.add_argument(
        "--failure-events-path",
        required=True,
        help="JSON-lines file of failure-event/v1 records.",
    )
    learning_parser.add_argument("--output-path", default="")
    learning_parser.set_defaults(handler=learning_loop)

    monitor_parser = subparsers.add_parser(
        "post-merge-monitor",
        help="Emit the release or incident event for one merged pull request.",
    )
    monitor_parser.add_argument("--repo", required=True)
    monitor_parser.add_argument("--pr-number", required=True, type=int)
    monitor_parser.add_argument("--commit-sha", required=True)
    # `ValidateSet` matches case-insensitively, and the given casing reaches the
    # output document, so the value must not be lowercased on the way in.
    monitor_parser.add_argument(
        "--verification-status",
        default="inconclusive",
        type=_status_argument,
        metavar="STATUS",
        help="One of pass|fail|inconclusive (case-insensitive).",
    )
    monitor_parser.add_argument("--failed-command", default="")
    monitor_parser.add_argument("--evidence", action="append", default=[])
    monitor_parser.add_argument("--rollback-recommendation", default="")
    monitor_parser.add_argument("--profile", default="unknown")
    monitor_parser.add_argument("--labels", action="append", default=[])
    monitor_parser.add_argument("--changed-paths", action="append", default=[])
    monitor_parser.add_argument("--auto-merged-by", default="unknown")
    monitor_parser.add_argument("--release-event-path", default="")
    monitor_parser.add_argument("--incident-event-path", default="")
    monitor_parser.add_argument("--output-path", default="")
    monitor_parser.set_defaults(handler=post_merge_monitor)

    preview_parser = subparsers.add_parser(
        "preview-verification",
        help="Run the preview create/smoke/teardown commands and emit evidence.",
    )
    preview_parser.add_argument("--preview-url", default="")
    preview_parser.add_argument("--create-command", default="")
    # The reference's `[string[]]$SmokeCommand` cannot be reached from a
    # command line at all: `-File` binds it one token and spills the rest into
    # the next unbound scalars, while repeating the switch is a binder error.
    # Repeated flags are the port's own shape, so a command may contain commas.
    preview_parser.add_argument(
        "--smoke-command",
        action="append",
        default=[],
        metavar="COMMAND",
        help="Repeat for each smoke command; blanks are skipped.",
    )
    preview_parser.add_argument("--teardown-command", default="")
    preview_parser.add_argument("--working-directory", default="")
    preview_parser.add_argument("--output-path", default="")
    preview_parser.set_defaults(handler=preview_verification)

    return parser


def _status_argument(value: str) -> str:
    """Accept any casing of a verification status, keeping the value as given.

    The reference's ``ValidateSet`` matches case-insensitively but does not
    normalise, and the argument's own spelling reaches the emitted document, so
    lowercasing here would change the output.
    """
    if value.lower() not in VERIFICATION_STATUSES:
        # argparse already prefixes the option name, so this must not repeat it.
        raise argparse.ArgumentTypeError(
            f"{value!r} does not belong to the set {','.join(VERIFICATION_STATUSES)}"
        )
    return value


def learning_loop(args: argparse.Namespace) -> int:
    """Delegate to the ported learning loop."""
    from .learning_loop import run_learning_loop

    return run_learning_loop(args.failure_events_path, args.output_path).emit()


def post_merge_monitor(args: argparse.Namespace) -> int:
    """Delegate to the ported post-merge monitor."""
    from .post_merge_monitor import run_post_merge_monitor

    return run_post_merge_monitor(
        repo=args.repo,
        pr_number=args.pr_number,
        commit_sha=args.commit_sha,
        verification_status=args.verification_status,
        failed_command=args.failed_command,
        evidence=args.evidence,
        rollback_recommendation=args.rollback_recommendation,
        profile=args.profile,
        labels=args.labels,
        changed_paths=args.changed_paths,
        auto_merged_by=args.auto_merged_by,
        release_event_path=args.release_event_path,
        incident_event_path=args.incident_event_path,
        output_path=args.output_path,
    ).emit()


def preview_verification(args: argparse.Namespace) -> int:
    """Delegate to the ported preview verification runner."""
    from .preview_verification import run_preview_verification

    return run_preview_verification(
        preview_url=args.preview_url,
        create_command=args.create_command,
        smoke_commands=args.smoke_command,
        teardown_command=args.teardown_command,
        working_directory=args.working_directory,
        output_path=args.output_path,
    ).emit()


def evidence_gate(args: argparse.Namespace) -> int:
    """Delegate to the ported evidence-document gates."""
    from .evidence_gates import KINDS

    return KINDS[args.kind](args.path).emit()


def requirement_brief(args: argparse.Namespace) -> int:
    """Delegate to the ported requirement-brief gate."""
    from .requirement_brief import check_requirement_brief

    return check_requirement_brief(args.brief_path, args.schema_path).emit()


def work_unit_scope(args: argparse.Namespace) -> int:
    """Delegate to the ported work-unit scope gate."""
    from .work_unit_scope import check_work_unit_scope

    return check_work_unit_scope(
        args.work_unit_path,
        changed_files=args.changed_files,
        diff_lines=args.diff_lines,
        changed_file_paths=args.changed_file_path,
    ).emit()


def orchestrator_permissions(args: argparse.Namespace) -> int:
    """Delegate to the ported orchestrator permission resolver."""
    from .orchestrator_permissions import check_orchestrator_permissions

    return check_orchestrator_permissions(
        args.profile,
        args.mode,
        args.manifest_path,
    ).emit()


def evidence_collect(args: argparse.Namespace) -> int:
    """Delegate to the ported verification-evidence collector."""
    from .evidence_collection import collect_verification_evidence

    return collect_verification_evidence(args.evidence_paths, args.output_path).emit()


def ship_readiness(args: argparse.Namespace) -> int:
    """Delegate to the ported merge gate, keeping its exit-code contract."""
    from .ship_readiness import check_ship_readiness

    result = check_ship_readiness(args.ship_readiness_path or "")
    return result.emit()


def command_guard(args: argparse.Namespace) -> int:
    """Delegate to the ported authorization gate."""
    from .command_guard import INPUT_ERROR_EXIT, GuardInputError, run_guard

    try:
        result = run_guard(
            payload_path=args.payload_path or None,
            comment_author=args.comment_author,
            author_association=args.author_association,
            comment_body=args.comment_body,
        )
    except GuardInputError as exc:
        # A payload that cannot be read or parsed is not an exit-2 refusal in
        # the reference: it is an uncaught terminating error, which exits 1.
        print(str(exc), file=sys.stderr)
        return INPUT_ERROR_EXIT
    return result.emit()


def review(args: argparse.Namespace) -> int:
    """Run the AER native review engine."""

    try:
        if args.review_action == "adjudicate":
            # The host agent supplies analysis outside this CLI process; the
            # deterministic pass still runs so CI gets a complete coverage
            # record and positioning for every deterministic finding.
            run = review_adjudicate(
                agent_runner=lambda _context, _file: [],
                repo=args.repo,
                mode=args.mode,
                from_ref=args.from_ref,
                to_ref=args.to_ref,
                commit=args.commit,
                paths=args.path or None,
                exclude=args.exclude or None,
                rule_path=args.rule_path,
            )
        else:
            run = review_analyze(
                repo=args.repo,
                mode=args.mode,
                from_ref=args.from_ref,
                to_ref=args.to_ref,
                commit=args.commit,
                paths=args.path or None,
                exclude=args.exclude or None,
                rule_path=args.rule_path,
            )
    except Exception as exc:
        print(f"aer review: {exc}", file=sys.stderr)
        return 2

    if args.ocr_cross_check:
        adapter = ocr_cross_check_selection(run.selection)
        if adapter.fallback_reason:
            run.adapter_fallback = adapter.fallback_reason
            run.warnings.append(adapter.fallback_reason)
        run.warnings.extend(adapter.raw_warnings)

    if args.review_action == "evidence":
        payload = review_render_evidence(run, role=args.role)
        if args.output:
            _write_json(args.output, payload)
        print(json.dumps(payload, ensure_ascii=False))
    elif args.review_action == "perspective":
        rep = build_perspective_report(run)
        if getattr(args, "format", "markdown") == "json":
            payload = rep.to_dict()
            if args.output:
                _write_json(args.output, payload)
            print(json.dumps(payload, ensure_ascii=False))
        else:
            md_text = rep.to_markdown()
            if args.output:
                Path(args.output).write_text(md_text, encoding="utf-8")
            print(md_text)
    else:
        payload = run.to_dict()
        if args.output:
            _write_json(args.output, payload)
        print(json.dumps(payload, ensure_ascii=False))
    blocking = run.blocking_findings
    if blocking:
        print(
            f"REVIEW: CHANGES_REQUESTED ({len(blocking)} blocking finding(s))",
            file=sys.stderr,
        )
        return 1
    print(
        f"REVIEW: PASS ({run.reviewed_count} reviewed, {run.skipped_count} skipped)",
        file=sys.stderr,
    )
    return 0



def repomap(args: argparse.Namespace) -> int:
    """Generate lightweight static AST Repo Map for target files or repository."""
    result = build_repo_map(
        repo_dir=args.repo,
        target_files=args.target,
        budget_tokens=args.budget_tokens,
    )
    if args.output:
        Path(args.output).write_text(result, encoding="utf-8")
    print(result)
    return 0


def triage(args: argparse.Namespace) -> int:
    from .triage import triage_failure
    if getattr(args, "text", None):
        raw = args.text
    elif getattr(args, "log_file", None) and args.log_file != "-":
        path = Path(args.log_file)
        if not path.is_file():
            print(f"Log file not found: {path}", file=sys.stderr)
            return 2
        raw = path.read_text(encoding="utf-8-sig", errors="replace")
    else:
        raw = sys.stdin.read()

    decision = triage_failure(raw)
    payload = decision.to_dict()
    if args.output:
        _write_json(args.output, payload)
    print(json.dumps(payload, ensure_ascii=False, indent=2))
    return 0 if decision.action in ("rerun", "auto-fix") else 1


def state(args: argparse.Namespace) -> int:
    """Drive the durable orchestrator state store.

    This is the Python replacement path for `scripts/agent-orchestrator-state.ps1`.
    Marker strings and exit codes are preserved exactly, because the PowerShell
    callers (`run-agent-work-start.ps1`, `run-agent-pr-steward-loop.ps1`) branch
    on `$LASTEXITCODE` and match on the printed markers.
    """
    from .orchestrator_state import OrchestratorStateError, run_action

    try:
        result = run_action(
            args.state_action,
            repo_key=args.repo_key or "",
            issue_number=args.issue_number or 0,
            status=args.status or "",
            reason=args.reason or "",
            state_root=args.state_root,
            lock_root=args.lock_root,
            max_attempts=args.max_attempts,
        )
    except OrchestratorStateError as exc:
        print(str(exc), file=sys.stderr)
        return 1

    return result.emit()


def distill(args: argparse.Namespace) -> int:
    if getattr(args, "text", None):
        raw = args.text
    elif getattr(args, "log_file", None) and args.log_file != "-":
        path = Path(args.log_file)
        if not path.is_file():
            print(f"Log file not found: {path}", file=sys.stderr)
            return 2
        raw = path.read_text(encoding="utf-8-sig", errors="replace")
    else:
        raw = sys.stdin.read()

    card = distill_pytest_log(raw, max_failures=args.max_failures)
    if args.output:
        _write_json(args.output, card.to_dict())
    print(card.render_markdown())
    return 0


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    return args.handler(args)


if __name__ == "__main__":
    raise SystemExit(main())
