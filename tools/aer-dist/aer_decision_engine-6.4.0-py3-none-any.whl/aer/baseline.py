"""Trusted baseline capture and machine result-card rendering."""

from __future__ import annotations

import hashlib
import json
import subprocess
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable

from .environment import (
    compute_environment_digest,
    environment_payload_from_parts,
    sha256_text,
)


def _sha256_bytes(value: bytes) -> str:
    return "sha256:" + hashlib.sha256(value).hexdigest()


def environment_digest(runtime: str, required_version: str) -> str:
    """Digest for an explicit runtime pair.

    Delegates to the shared canonical implementation so this module cannot
    drift from ``core/aer/closure.py`` or the PowerShell verifiers.
    """
    return sha256_text(environment_payload_from_parts(runtime, required_version))


def capture_baseline(
    repo_path: Path,
    *,
    tier: str = "cheap",
    run_id: str,
    candidate_surface: dict[str, Any] | None = None,
    failures: Iterable[dict[str, Any]] = (),
    timestamp: str = "",
) -> dict[str, Any]:
    """Build a verification baseline.

    Command execution stays outside this function. Production callers pass the
    already observed candidate surface so the document logic is deterministic
    and testable on any runner.
    """
    manifest_path = repo_path / "config" / "verification-manifest.json"
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    manifest_hash = _sha256_bytes(manifest_path.read_bytes())
    surface = candidate_surface or _surface_from_gates(manifest, tier)
    policy = manifest["baselinePolicy"]
    policy_hash = sha256_text(
        f"{policy['tierDefault']}|{policy['allowKnownFailures']}|"
        f"{policy['maxNewFailures']}"
    )
    return {
        "schemaVersion": "verification-baseline/v2",
        "runId": run_id,
        "repoKey": manifest["repoKey"],
        "baselineSha": _git_sha(repo_path),
        "policyHash": policy_hash,
        "verifierVersion": "rvce-v6.0.0",
        "environmentDigest": compute_environment_digest(manifest),
        "verificationManifestHash": manifest_hash,
        "capturedAt": timestamp or _utc_timestamp(),
        "tier": tier,
        "surface": surface,
        "failures": list(failures),
    }


def render_result_card(evidence: dict[str, Any], evidence_path: str) -> str:
    if evidence.get("schemaVersion") != "verification-evidence/v2":
        raise ValueError(
            f"Unsupported evidence schema version: {evidence.get('schemaVersion')}"
        )

    causal = evidence["causalAttribution"]
    surface = causal["surfaceDelta"]
    environment = causal["environmentDelta"]
    scope = evidence["scopeCheck"]
    security = evidence["securityCheck"]
    risk = (
        f"* verdict_blocked_reason: verdict is {evidence['verdict']}"
        if evidence["verdict"] != "PASS"
        else "* remaining_risk: none observed under active verification manifest"
    )
    return "\n".join(
        [
            "## Result Card (Machine Generated)",
            "",
            "### conclusion",
            str(evidence["verdict"]),
            "",
            "### evidence",
            f"* run_id: {evidence['runId']}",
            f"* candidate_sha: {evidence['candidateSha']}",
            f"* failure_delta_count: {causal['failureDeltaCount']}",
            f"* surface_intact: {surface['isSurfaceIntact']} "
            f"(tests: {surface['baseCount']} -> {surface['candidateCount']})",
            f"* environment_equivalent: {environment['isEquivalent']}",
            f"* scope_clean: {scope['isScopeClean']} "
            f"(modified: {len(scope['modifiedFiles'])} files)",
            f"* secrets_found: {security['secretsFound']} "
            f"(engine: {security['scanEngine']})",
            "",
            "### state_updates",
            f"* verified_at: {evidence['timestamp']}",
            f"* protected_surface_touched: {scope['protectedSurfaceTouched']}",
            f"* removed_test_ids: {_join_ids(surface['removedTestIds'])}",
            f"* new_failures: {_join_ids([item['testId'] for item in causal['newFailures']])}",
            f"* resolved_failures: {_join_ids([item['testId'] for item in causal['resolvedFailures']])}",
            "",
            "### risks",
            risk,
            "",
            "### raw_artifact_refs",
            f"* evidence_path: {evidence_path}",
            "",
        ]
    )


def _surface_from_gates(manifest: dict[str, Any], tier: str) -> dict[str, Any]:
    gates = [
        gate
        for gate in manifest["gates"]
        if tier != "cheap" or gate["tier"] == "cheap"
    ]
    return {
        "testCount": len(gates),
        "testFiles": [f"gate:{gate['id']}" for gate in gates],
        "testIds": [f"{gate['id']}::exec" for gate in gates],
    }


def _git_sha(repo_path: Path) -> str:
    result = subprocess.run(
        ["git", "-C", str(repo_path), "rev-parse", "HEAD"],
        capture_output=True,
        text=True,
        check=False,
    )
    return result.stdout.strip() if result.returncode == 0 else "0" * 40


def _join_ids(values: Iterable[str]) -> str:
    items = [str(value) for value in values]
    return ", ".join(items) if items else "none"


def _utc_timestamp() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")
