"""Lightweight, deterministic AST-based code map generator.

Extracts symbol signatures, classes, functions, and import relationships
without running heavy background LSP daemons or external language servers.
"""

from __future__ import annotations

import ast
import os
from pathlib import Path
from typing import Sequence

# Common noise directories to exclude from repo scanning
EXCLUDED_DIRS = {
    ".git",
    "__pycache__",
    ".pytest_cache",
    "node_modules",
    ".venv",
    "venv",
    ".aer-review",
    ".verification",
    ".wrangler",
    "dist",
    "build",
}


def _clean_docstring(doc: str | None) -> str:
    if not doc:
        return ""
    line = doc.strip().splitlines()[0].strip()
    if len(line) > 80:
        line = line[:77] + "..."
    return f'    """{line}"""'


def _format_args(args: ast.arguments) -> str:
    parts = []
    # Positional only args (Python 3.8+)
    posonly = getattr(args, "posonlyargs", [])
    for a in posonly:
        ann = f": {ast.unparse(a.annotation)}" if a.annotation else ""
        parts.append(f"{a.arg}{ann}")
    if posonly:
        parts.append("/")

    # Regular args
    defaults_offset = len(args.args) - len(args.defaults)
    for i, a in enumerate(args.args):
        ann = f": {ast.unparse(a.annotation)}" if a.annotation else ""
        default_idx = i - defaults_offset
        if default_idx >= 0:
            def_str = f" = {ast.unparse(args.defaults[default_idx])}"
        else:
            def_str = ""
        parts.append(f"{a.arg}{ann}{def_str}")

    # Vararg (*args)
    if args.vararg:
        ann = f": {ast.unparse(args.vararg.annotation)}" if args.vararg.annotation else ""
        parts.append(f"*{args.vararg.arg}{ann}")
    elif args.kwonlyargs:
        parts.append("*")

    # Keyword-only args
    kw_defaults = args.kw_defaults
    for i, a in enumerate(args.kwonlyargs):
        ann = f": {ast.unparse(a.annotation)}" if a.annotation else ""
        d = kw_defaults[i]
        def_str = f" = {ast.unparse(d)}" if d is not None else ""
        parts.append(f"{a.arg}{ann}{def_str}")

    # Kwarg (**kwargs)
    if args.kwarg:
        ann = f": {ast.unparse(args.kwarg.annotation)}" if args.kwarg.annotation else ""
        parts.append(f"**{args.kwarg.arg}{ann}")

    return ", ".join(parts)


def extract_file_skeleton(source_code: str, file_path: str = "") -> list[str]:
    """Extract class, method, function signatures and docstrings from Python source."""
    try:
        tree = ast.parse(source_code, filename=file_path)
    except Exception:
        return []

    lines: list[str] = []

    for node in tree.body:
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            prefix = "async def " if isinstance(node, ast.AsyncFunctionDef) else "def "
            ret = f" -> {ast.unparse(node.returns)}" if node.returns else ""
            arg_str = _format_args(node.args)
            lines.append(f"{prefix}{node.name}({arg_str}){ret}: ...")
            doc = ast.get_docstring(node)
            if doc:
                first_line = _clean_docstring(doc)
                if first_line:
                    lines.append(f"    {first_line.strip()}")

        elif isinstance(node, ast.ClassDef):
            bases = [ast.unparse(b) for b in node.bases]
            base_str = f"({', '.join(bases)})" if bases else ""
            lines.append(f"class {node.name}{base_str}:")
            doc = ast.get_docstring(node)
            if doc:
                lines.append(_clean_docstring(doc))
            
            method_count = 0
            for item in node.body:
                if isinstance(item, (ast.FunctionDef, ast.AsyncFunctionDef)):
                    prefix = "async def " if isinstance(item, ast.AsyncFunctionDef) else "def "
                    ret = f" -> {ast.unparse(item.returns)}" if item.returns else ""
                    arg_str = _format_args(item.args)
                    lines.append(f"    {prefix}{item.name}({arg_str}){ret}: ...")
                    doc_item = ast.get_docstring(item)
                    if doc_item:
                        first_line = _clean_docstring(doc_item)
                        if first_line:
                            lines.append(f"        {first_line.strip()}")
                    method_count += 1
                elif isinstance(item, ast.AnnAssign) and isinstance(item.target, ast.Name):
                    val = f" = {ast.unparse(item.value)}" if item.value else ""
                    lines.append(f"    {item.target.id}: {ast.unparse(item.annotation)}{val}")
            if method_count == 0 and not doc:
                lines.append("    ...")

        elif isinstance(node, ast.AnnAssign) and isinstance(node.target, ast.Name):
            # Module-level annotated variable
            val = f" = {ast.unparse(node.value)}" if node.value else ""
            lines.append(f"{node.target.id}: {ast.unparse(node.annotation)}{val}")

    return lines


def extract_file_imports(source_code: str) -> set[str]:
    """Extract imported module names from source."""
    try:
        tree = ast.parse(source_code)
    except Exception:
        return set()

    imported = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for n in node.names:
                imported.add(n.name)
        elif isinstance(node, ast.ImportFrom):
            if node.module:
                imported.add(node.module)
    return imported


def build_repo_map(
    repo_dir: str | Path,
    target_files: Sequence[str] = (),
    budget_tokens: int = 1500,
) -> str:
    """Build a concise, bounded repository skeleton map."""
    repo_path = Path(repo_dir).resolve()
    if not repo_path.is_dir():
        return ""

    char_budget = budget_tokens * 4

    # 1. Discover python files
    py_files: list[Path] = []
    for root, dirs, files in os.walk(repo_path):
        dirs[:] = [d for d in dirs if d not in EXCLUDED_DIRS and not d.startswith(".")]
        for f in files:
            if f.endswith(".py"):
                py_files.append(Path(root) / f)

    if not py_files:
        return ""

    # Normalize targets
    normalized_targets: set[str] = set()
    for t in target_files:
        p = Path(t)
        if not p.is_absolute():
            p = (repo_path / p).resolve()
        normalized_targets.add(str(p).lower())

    # 2. Rank files: targets first, then related, then others
    ranked_files: list[Path] = []
    other_files: list[Path] = []

    for f in py_files:
        resolved_str = str(f.resolve()).lower()
        if resolved_str in normalized_targets:
            ranked_files.append(f)
        else:
            other_files.append(f)

    # Sort remaining by path stability
    other_files.sort(key=lambda p: str(p.relative_to(repo_path)))
    ranked_files.extend(other_files)

    # 3. Extract skeletons until budget is exhausted
    output_blocks: list[str] = []
    current_chars = 0

    for py_file in ranked_files:
        try:
            rel_path = py_file.relative_to(repo_path).as_posix()
            source = py_file.read_text(encoding="utf-8-sig", errors="replace")
            skeleton = extract_file_skeleton(source, file_path=rel_path)
            if not skeleton:
                continue

            block = f"# {rel_path}\n" + "\n".join(skeleton) + "\n"
            block_len = len(block)

            if current_chars + block_len > char_budget:
                if not output_blocks:
                    # Budget is too small for full block, take partial lines
                    clipped_lines = []
                    for line in skeleton:
                        if current_chars + len(line) + 1 > char_budget:
                            break
                        clipped_lines.append(line)
                        current_chars += len(line) + 1
                    if clipped_lines:
                        output_blocks.append(f"# {rel_path}\n" + "\n".join(clipped_lines) + "\n")
                break

            output_blocks.append(block)
            current_chars += block_len
        except Exception:
            continue

    if not output_blocks:
        return ""

    header = "## Repository AST Code Map (Key Interfaces & Signatures)\n"
    return header + "\n".join(output_blocks).strip()
