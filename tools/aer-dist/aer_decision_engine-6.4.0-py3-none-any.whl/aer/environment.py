"""Canonical environment digest shared by every verification engine.

The Python closure engine, the Python baseline capture, and the PowerShell
verifiers must all produce a byte-identical ``environmentDigest``. Before this
module existed there were three independent derivations (``closure.py``,
``baseline.py``, and two PowerShell scripts), and the Python and PowerShell
pre-images disagreed on every host, so every candidate was reported BLOCKED by
the environment-delta check.

The digest covers OS *family* only. OS release strings differ between hosts and
between the Python and PowerShell detection APIs, so including them made the
two engines permanently incomparable. The family still separates
Windows/Linux/macOS baselines, which is what the environment-delta check needs.

Keep this pre-image byte-identical with ``scripts/get-environment-digest.ps1``.
"""

from __future__ import annotations

import hashlib
import platform
from typing import Any


def environment_os_family() -> str:
    """Return the canonical OS family token: windows, linux, macos, unknown."""
    system = platform.system().strip().lower()
    if system.startswith("windows"):
        return "windows"
    if system == "darwin" or system.startswith("macos"):
        return "macos"
    if system.startswith("linux"):
        return "linux"
    return "unknown"


def environment_payload_from_parts(runtime: str, required_version: str) -> str:
    """Canonical pre-image from explicit manifest fields."""
    return "|".join([environment_os_family(), str(runtime), str(required_version)])


def environment_payload(manifest: dict[str, Any]) -> str:
    """Canonical pre-image from a verification manifest."""
    environment = manifest["environment"]
    return environment_payload_from_parts(
        environment["runtime"],
        environment["requiredVersion"],
    )


def compute_environment_digest(manifest: dict[str, Any]) -> str:
    """SHA-256 digest of the canonical manifest environment pre-image."""
    return sha256_text(environment_payload(manifest))


def sha256_text(value: str) -> str:
    return "sha256:" + hashlib.sha256(value.encode("utf-8")).hexdigest()
