"""Native Python port of the RVCE verification-closure engine.

This replaces the Windows/PowerShell closure script
(``scripts/assert-verification-closure.ps1``) with a cross-platform engine that
only depends on the standard library and the Git CLI. The verdict equation is
intentionally identical to the PowerShell reference that the Golden Baseline
parity gate compares against:

    no new failures AND surface intact AND environment equivalent
    AND scope clean AND security clean

Running the gates is separated from computing the verdict so the verdict logic
stays deterministic and unit-testable on any runner.
"""

from __future__ import annotations

import hashlib
import json
import os
import re
import shlex
import subprocess
import sys
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable

from .environment import (
    compute_environment_digest,
    environment_os_family,
    environment_payload,
)
from harness.sandbox.env_scope import safe_sandbox_environment
from harness.sandbox.selection import (
    SandboxPolicyViolationError,
    select_sandbox_driver,
)
from harness.sandbox.docker import DockerUnavailableError

VERIFIER_VERSION = "rvce-v6.0.0"
EVIDENCE_SCHEMA_VERSION = "verification-evidence/v2"
ZERO_SHA = "0" * 40
LOG_TRAILER_PREFIX = "[aer]"
TRAILER_EXIT_RE = re.compile(r"^\[aer\] exit-code: (-?\d+)$", re.MULTILINE)
TRAILER_GATE_RE = re.compile(r"^\[aer\] gate-id: (.+)$", re.MULTILINE)

DEFAULT_LOG_DIR = Path("artifacts") / "aer" / "gate-logs" 


class ClosureError(RuntimeError):
    """Raised when the closure inputs are missing or malformed."""


def _utc_timestamp() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def _sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(65536), b""):
            digest.update(chunk)
    return "sha256:" + digest.hexdigest()


def _fingerprint(gate_id: str, exit_code: int, output: str) -> str:
    digest = hashlib.sha256(f"{gate_id}|{exit_code}|{output}".encode("utf-8"))
    return "fp:" + digest.hexdigest()[:16]


def _classify(exit_code: int, output: str, timed_out: bool) -> str:
    if timed_out:
        return "FAIL_TIMEOUT"
    lowered = output.lower()
    if "syntaxerror" in lowered or "importerror" in lowered or "parse" in lowered:
        return "FAIL_COMPILATION"
    return "FAIL_ASSERTION"


@dataclass(frozen=True)
class GateOutcome:
    """Observed result of running one manifest gate."""

    test_id: str
    passed: bool
    classification: str = ""
    fingerprint: str = ""
    duration_sec: float = 0.0
    output: str = ""
    exit_code: int = 0
    timed_out: bool = False
    log_path: str = ""
    log_digest: str = ""
    observed_at: str = ""

    def failure_record(self) -> dict[str, Any]:
        """Evidence record for a failing gate.

        The log digest covers a trailer that repeats ``exit_code``, so the
        recorded exit code and the raw observation cannot be edited
        independently.
        """
        record: dict[str, Any] = {
            "testId": self.test_id,
            "classification": self.classification,
            "fingerprint": self.fingerprint,
            "exitCode": self.exit_code,
        }
        if self.log_path:
            record["logPath"] = self.log_path
        if self.log_digest:
            record["logDigest"] = self.log_digest
        if self.observed_at:
            record["observedAt"] = self.observed_at
        return record


def _shell_argv(command: str) -> list[str]:
    """Split a manifest command, routing the python token to this interpreter."""
    parts = shlex.split(command, posix=os.name != "nt")
    if parts and Path(parts[0]).stem.lower() == "python":
        parts[0] = sys.executable
    return parts


def _run_gate(
    gate: dict[str, Any],
    *,
    cwd: Path,
    env: dict[str, str] | None = None,
    log_dir: Path | None = None,
    sandbox: Any | None = None,
) -> GateOutcome:
    test_id = f"{gate['id']}::exec"
    timeout = float(gate.get("timeoutSec") or 300)
    command = str(gate["command"])
    started = datetime.now(timezone.utc)
    timed_out = False
    safe_env = safe_sandbox_environment(caller_env=env)
    try:
        if sandbox is not None:
            sandbox_res = sandbox.run_command(_shell_argv(command), cwd=cwd, env=safe_env, timeout_sec=timeout)
            completed = subprocess.CompletedProcess(_shell_argv(command), sandbox_res.exit_code, sandbox_res.stdout, sandbox_res.stderr)
            if sandbox_res.timed_out:
                raise subprocess.TimeoutExpired(_shell_argv(command), timeout, output=sandbox_res.stdout, stderr=sandbox_res.stderr)
        else:
            completed = subprocess.run(
                _shell_argv(command),
                cwd=str(cwd),
                capture_output=True,
                text=True,
                timeout=timeout,
                env=safe_env,
                check=False,
            )
        exit_code = completed.returncode
        output = f"{completed.stdout}\n{completed.stderr}"
    except subprocess.TimeoutExpired as exc:
        timed_out = True
        exit_code = 124
        stdout = exc.stdout.decode() if isinstance(exc.stdout, bytes) else exc.stdout or ""
        stderr = exc.stderr.decode() if isinstance(exc.stderr, bytes) else exc.stderr or ""
        output = f"{stdout}\n{stderr}"
    except FileNotFoundError as exc:
        exit_code = 127
        output = str(exc)

    duration = (datetime.now(timezone.utc) - started).total_seconds()
    observed_at = _utc_timestamp()
    log_path, log_digest = _write_gate_log(
        gate_id=str(gate["id"]),
        output=output,
        exit_code=exit_code,
        observed_at=observed_at,
        log_dir=log_dir,
    )
    if exit_code == 0:
        return GateOutcome(
            test_id=test_id,
            passed=True,
            duration_sec=duration,
            exit_code=0,
            log_path=log_path,
            log_digest=log_digest,
            observed_at=observed_at,
        )
    return GateOutcome(
        test_id=test_id,
        passed=False,
        classification=_classify(exit_code, output, timed_out),
        fingerprint=_fingerprint(gate["id"], exit_code, output),
        duration_sec=duration,
        output=output,
        exit_code=exit_code,
        timed_out=timed_out,
        log_path=log_path,
        log_digest=log_digest,
        observed_at=observed_at,
    )


def _write_gate_log(
    *,
    gate_id: str,
    output: str,
    exit_code: int,
    observed_at: str,
    log_dir: Path | None,
) -> tuple[str, str]:
    """Write a gate log whose digest covers its own exit-code trailer.

    Hashing a log alone only proves the file is unchanged. Appending the exit
    code as a machine-readable trailer *before* hashing means an edit to the
    recorded exit code either breaks the digest or contradicts the trailer.

    Returns ``("", "")`` when no log directory is configured, so injected and
    in-memory outcomes keep the previous behaviour.
    """
    if log_dir is None:
        return "", ""
    log_dir = Path(log_dir)
    log_dir.mkdir(parents=True, exist_ok=True)
    safe_id = re.sub(r"[^A-Za-z0-9._-]+", "_", gate_id).strip("_") or "gate"
    path = log_dir / f"{safe_id}.log"
    trailer = (
        f"{LOG_TRAILER_PREFIX} gate-id: {gate_id}\n"
        f"{LOG_TRAILER_PREFIX} exit-code: {exit_code}\n"
        f"{LOG_TRAILER_PREFIX} observed-at: {observed_at}\n"
    )
    path.write_text(f"{output}\n{trailer}", encoding="utf-8")
    return path.as_posix(), _sha256_file(path)


def select_gates(manifest: dict[str, Any], tier: str) -> list[dict[str, Any]]:
    gates = manifest["gates"]
    if tier == "cheap":
        return [gate for gate in gates if gate.get("tier") == "cheap"]
    return list(gates)


def run_gates(
    manifest: dict[str, Any],
    *,
    tier: str = "cheap",
    cwd: Path | str = ".",
    env: dict[str, str] | None = None,
    log_dir: Path | str | None = None,
    sandbox: Any | None = None,
) -> list[GateOutcome]:
    """Run every selected gate and return their observed outcomes."""
    workdir = Path(cwd)
    resolved_log_dir = Path(log_dir) if log_dir is not None else None
    return [
        _run_gate(gate, cwd=workdir, env=env, log_dir=resolved_log_dir, sandbox=sandbox)
        for gate in select_gates(manifest, tier)
    ]


def _git(repo: Path, *args: str) -> str:
    completed = subprocess.run(
        ["git", "-C", str(repo), *args],
        capture_output=True,
        text=True,
        check=False,
    )
    if completed.returncode != 0:
        return ""
    if "-z" in args:
        # NUL records keep their leading status byte; strip only the trailing
        # record terminator so `status --porcelain -z` is not corrupted.
        return completed.stdout.rstrip("\0")
    return completed.stdout.strip()


def modified_files(repo: Path, baseline_sha: str) -> list[str]:
    """Return changed paths between the baseline commit and the candidate.

    ``git diff --name-only -z`` is used because porcelains quote and escape
    paths; the NUL-separated form needs no unquoting and stays correct for
    renamed or space-containing files.
    """
    if baseline_sha and baseline_sha != ZERO_SHA:
        diff = _git(repo, "diff", "--name-only", "-z", baseline_sha, "HEAD")
        if diff:
            return [item for item in diff.split("\0") if item.strip()]
    status = _git(repo, "status", "--porcelain", "-z")
    files: list[str] = []
    for entry in status.split("\0"):
        if not entry:
            continue
        # "<XY> <path>" with a NUL separator; the two status bytes plus the
        # separating space are stripped without touching unusual path bytes.
        files.append(entry[3:] if len(entry) > 3 else entry.strip())
    return files


def _matches_glob(path: str, pattern: str) -> bool:
    regex: list[str] = []
    index = 0
    while index < len(pattern):
        char = pattern[index]
        if char == "*" and index + 1 < len(pattern) and pattern[index + 1] == "*":
            regex.append(".*")
            index += 2
            continue
        if char == "*":
            regex.append("[^/]*")
        else:
            regex.append(re.escape(char))
        index += 1
    return bool(re.fullmatch("".join(regex), path))


def protected_surface_touched(
    files: Iterable[str],
    protected_surface: Iterable[str],
) -> bool:
    for modified in files:
        normalized = str(modified).replace("\\", "/")
        for pattern in protected_surface:
            if _matches_glob(normalized, str(pattern)):
                return True
    return False


def build_evidence(
    *,
    baseline: dict[str, Any],
    manifest: dict[str, Any],
    outcomes: Iterable[GateOutcome],
    candidate_sha: str,
    modified: Iterable[str],
    environment_digest: str,
    secrets_found: bool = False,
    scan_engine: str = "aer",
    timestamp: str = "",
    mutation_report: dict[str, Any] | None = None,
    allow_protected: bool = False,
) -> dict[str, Any]:
    """Compute verification evidence using the RVCE v2 verdict equation."""
    outcomes = list(outcomes)
    # The baseline document stores the surface under `surface.testIds`, matching
    # contracts/verification-baseline.schema.json; accept a flat list as well so
    # hand-written baselines stay usable.
    raw_surface = baseline.get("surface") or {}
    if isinstance(raw_surface, dict) and raw_surface.get("testIds"):
        base_test_ids = [str(item) for item in raw_surface["testIds"]]
    else:
        base_test_ids = [str(item) for item in baseline.get("testIds") or ()]
    candidate_test_ids = [outcome.test_id for outcome in outcomes]
    removed = [test_id for test_id in base_test_ids if test_id not in candidate_test_ids]
    surface_intact = not removed

    base_failures = {
        str(item["testId"]): item for item in baseline.get("failures") or ()
    }
    new_failures: list[dict[str, Any]] = []
    candidate_failure_ids: list[str] = []
    for outcome in outcomes:
        if outcome.passed:
            continue
        candidate_failure_ids.append(outcome.test_id)
        known = base_failures.get(outcome.test_id)
        record = outcome.failure_record()
        if known is None:
            new_failures.append(record)
        elif str(known.get("fingerprint")) != outcome.fingerprint:
            new_failures.append({**record, "reason": "FINGERPRINT_MODIFIED"})

    resolved = [
        known
        for test_id, known in base_failures.items()
        if test_id not in candidate_failure_ids
    ]

    environment_equivalent = (
        str(baseline.get("environmentDigest") or "") == environment_digest
    )
    modified = list(modified)
    protected_touched = protected_surface_touched(
        modified, manifest.get("protectedSurface") or ()
    )

    mutants_survived = False
    if mutation_report:
        if mutation_report.get("applicable", True):
            if mutation_report.get("survivingMutants") or mutation_report.get("survivedMutants", 0) > 0:
                mutants_survived = True

    if not environment_equivalent:
        verdict = "BLOCKED"
    elif protected_touched and not allow_protected:
        verdict = "HUMAN_REQUIRED"
    elif not surface_intact or new_failures or secrets_found or mutants_survived:
        verdict = "FAIL"
    else:
        verdict = "PASS"

    evidence_doc = {
        "schemaVersion": EVIDENCE_SCHEMA_VERSION,
        "runId": baseline.get("runId", ""),
        "candidateSha": candidate_sha,
        "timestamp": timestamp or _utc_timestamp(),
        "verdict": verdict,
        "causalAttribution": {
            "failureDeltaCount": len(new_failures),
            "newFailures": new_failures,
            "resolvedFailures": resolved,
            "surfaceDelta": {
                "baseCount": len(base_test_ids),
                "candidateCount": len(candidate_test_ids),
                "removedTestIds": removed,
                "isSurfaceIntact": surface_intact,
            },
            "environmentDelta": {
                "baseDigest": str(baseline.get("environmentDigest") or ""),
                "candidateDigest": environment_digest,
                "isEquivalent": environment_equivalent,
            },
        },
        "scopeCheck": {
            "isScopeClean": not protected_touched,
            "protectedSurfaceTouched": protected_touched,
            "modifiedFiles": [str(path).replace("\\", "/") for path in modified],
        },
        "securityCheck": {
            "secretsFound": secrets_found,
            "scanEngine": scan_engine,
        },
    }
    if mutation_report is not None:
        evidence_doc["mutationReport"] = mutation_report
    return evidence_doc


@dataclass
class ClosureRun:
    """Result of a full verify/gate run."""

    evidence: dict[str, Any]
    outcomes: list[GateOutcome] = field(default_factory=list)

    @property
    def verdict(self) -> str:
        return str(self.evidence["verdict"])

    @property
    def exit_code(self) -> int:
        # FAIL/BLOCKED mean "gate failed"; HUMAN_REQUIRED means a human must
        # decide, which is a distinct routing signal from a mechanical failure.
        return 0 if self.verdict == "PASS" else 1


def load_manifest(repo: Path | str = ".") -> dict[str, Any]:
    path = Path(repo) / "config" / "verification-manifest.json"
    if not path.is_file():
        raise ClosureError(f"Verification manifest not found: {path}")
    return json.loads(path.read_text(encoding="utf-8-sig"))


def run_closure(
    repo: Path | str = ".",
    *,
    baseline_path: Path | str | None = None,
    tier: str = "cheap",
    secrets_found: bool = False,
    outcomes: Iterable[GateOutcome] | None = None,
    timestamp: str = "",
    log_dir: Path | str | None = None,
    sandbox: Any | None = None,
    sandbox_driver: str | None = None,
    customer_code_mode: bool = False,
    allow_protected: bool = False,
) -> ClosureRun:
    """Run the closure verdict over a baseline and the current worktree.

    When ``log_dir`` is given (the default for a real run), each gate writes a
    log whose digest covers a trailer repeating the observed exit code. Injected
    ``outcomes`` bypass gate execution and keep whatever log metadata they carry.
    """
    repo_path = Path(repo).resolve()
    manifest = load_manifest(repo_path)

    baseline: dict[str, Any] = {}
    if baseline_path is not None:
        baseline_file = Path(baseline_path)
        if not baseline_file.is_file():
            raise ClosureError(f"Baseline file not found: {baseline_file}")
        baseline = json.loads(baseline_file.read_text(encoding="utf-8-sig"))
        tier = str(baseline.get("tier") or tier)

    driver_instance = sandbox
    owned_driver = False

    # P0-B: Prevent dependency-injection policy bypass in customer-code mode
    if customer_code_mode and driver_instance is not None:
        from harness.sandbox.docker import DockerSandbox
        if not isinstance(driver_instance, DockerSandbox):
            raise ClosureError(
                f"In customer-code mode, injected sandbox must be an isolated container driver (DockerSandbox), got '{type(driver_instance).__name__}'."
            )

    if driver_instance is None and (sandbox_driver is not None or customer_code_mode):
        profile = "aer-verify" if customer_code_mode else "autopilot-low"
        try:
            driver_instance = select_sandbox_driver(
                repo_dir=repo_path,
                profile=profile,
                requested_driver=sandbox_driver,
                customer_code_mode=customer_code_mode,
            )
            owned_driver = True
        except (SandboxPolicyViolationError, DockerUnavailableError) as exc:
            raise ClosureError(f"Sandbox isolation failed to initialize: {exc}") from exc

    try:
        if outcomes is None:
            if log_dir is None:
                log_dir = repo_path / DEFAULT_LOG_DIR
            outcomes = run_gates(
                manifest, tier=tier, cwd=repo_path, log_dir=Path(log_dir), sandbox=driver_instance
            )
        outcomes = list(outcomes)

        candidate_sha = _git(repo_path, "rev-parse", "HEAD") or ZERO_SHA
        modified = modified_files(repo_path, str(baseline.get("baselineSha") or ""))
        evidence = build_evidence(
            baseline=baseline,
            manifest=manifest,
            outcomes=outcomes,
            candidate_sha=candidate_sha,
            modified=modified,
            environment_digest=compute_environment_digest(manifest),
            secrets_found=secrets_found,
            scan_engine="aer",
            timestamp=timestamp,
            allow_protected=allow_protected,
        )
        log_findings = verify_gate_logs(evidence, base_dir=repo_path)
        if log_findings and evidence.get("verdict") == "PASS":
            evidence["verdict"] = "FAIL"
        return ClosureRun(evidence=evidence, outcomes=outcomes)
    finally:
        # P0-D: Deterministic lifecycle cleanup for owned drivers
        if owned_driver and driver_instance is not None:
            try:
                driver_instance.dispose()
            except Exception:
                pass


def write_evidence(evidence: dict[str, Any], output: Path | str) -> None:
    target = Path(output)
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(
        json.dumps(evidence, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )


@dataclass(frozen=True)
class LogIntegrityFinding:
    """One reason a gate log cannot be reconciled with its evidence record."""

    test_id: str
    code: str
    message: str

    def to_dict(self) -> dict[str, str]:
        return {"testId": self.test_id, "code": self.code, "message": self.message}


def verify_gate_logs(
    evidence: dict[str, Any],
    *,
    base_dir: Path | str = ".",
) -> list[LogIntegrityFinding]:
    """Reconcile each recorded gate log against its evidence record.

    Catches three tamper shapes the digest alone misses:

    1. the log was edited after hashing (digest mismatch);
    2. the recorded exit code was edited (log trailer disagrees);
    3. the pass/fail classification was edited (contradicts the exit code).

    Records without log metadata are reported as ``log-metadata-missing`` rather
    than silently passing, so evidence cannot opt out by omitting fields.
    """
    findings: list[LogIntegrityFinding] = []
    root = Path(base_dir)

    def _records() -> Iterable[tuple[str, dict[str, Any]]]:
        # Only records produced by the current run are checked. resolvedFailures
        # come from the baseline and by definition have no log from this run.
        for item in evidence.get("causalAttribution", {}).get("newFailures", []) or []:
            if isinstance(item, dict):
                yield "newFailures", item
        for item in evidence.get("testResults", []) or []:
            if isinstance(item, dict):
                yield "testResults", item

    for section, record in _records():
        test_id = str(record.get("testId") or record.get("commandId") or "unknown")
        log_path = record.get("logPath")
        log_digest = record.get("logDigest")
        if not log_path or not log_digest:
            findings.append(
                LogIntegrityFinding(
                    test_id=test_id,
                    code="log-metadata-missing",
                    message=(
                        f"{section} record has no logPath/logDigest, so its exit "
                        "code cannot be reconciled with a raw observation"
                    ),
                )
            )
            continue

        resolved = Path(log_path)
        if not resolved.is_absolute():
            resolved = root / resolved
        if not resolved.is_file():
            findings.append(
                LogIntegrityFinding(
                    test_id=test_id,
                    code="log-missing",
                    message=f"no gate log at {log_path}",
                )
            )
            continue

        if _sha256_file(resolved) != str(log_digest):
            findings.append(
                LogIntegrityFinding(
                    test_id=test_id,
                    code="log-digest-mismatch",
                    message=f"{log_path} does not match the recorded digest",
                )
            )
            continue

        text_content = resolved.read_text(encoding="utf-8", errors="replace")
        exit_match = TRAILER_EXIT_RE.search(text_content)
        gate_match = TRAILER_GATE_RE.search(text_content)
        if exit_match is None or gate_match is None:
            findings.append(
                LogIntegrityFinding(
                    test_id=test_id,
                    code="log-trailer-missing",
                    message=f"{log_path} carries no aer exit-code trailer",
                )
            )
            continue

        trailer_gate = gate_match.group(1).strip()
        # failure_record stores "gate-id::exec"; testResults may store commandId.
        declared_gate = record.get("gateId") or record.get("commandId")
        if declared_gate is None:
            declared_gate = str(record.get("testId") or "").split("::", 1)[0]
        if declared_gate and trailer_gate != str(declared_gate):
            findings.append(
                LogIntegrityFinding(
                    test_id=test_id,
                    code="log-gate-id-mismatch",
                    message=(
                        f"{log_path} was produced for gate '{trailer_gate}', not "
                        f"'{declared_gate}'"
                    ),
                )
            )

        trailer_exit = int(exit_match.group(1))
        recorded_exit = record.get("exitCode")
        if recorded_exit is None:
            findings.append(
                LogIntegrityFinding(
                    test_id=test_id,
                    code="exit-code-missing",
                    message="record has no exitCode to reconcile against the log trailer",
                )
            )
            continue

        # A record filed as a new failure cannot have exited zero. Without this
        # invariant, an edit to the trailer + digest + exitCode together would be
        # internally consistent and slip through.
        if section == "newFailures" and int(recorded_exit) == 0 and trailer_exit == 0:
            findings.append(
                LogIntegrityFinding(
                    test_id=test_id,
                    code="failure-with-zero-exit",
                    message=(
                        "record is filed as a new failure but both the evidence "
                        "and its log report exit 0"
                    ),
                )
            )
            continue

        if int(recorded_exit) != trailer_exit:
            findings.append(
                LogIntegrityFinding(
                    test_id=test_id,
                    code="exit-code-mismatch",
                    message=(
                        f"record claims exit {recorded_exit}, log trailer says "
                        f"{trailer_exit}"
                    ),
                )
            )
            continue

        status = record.get("status")
        if status == "RESOLVED" and trailer_exit != 0:
            findings.append(
                LogIntegrityFinding(
                    test_id=test_id,
                    code="status-mismatch",
                    message=(
                        f"record is marked RESOLVED but its log shows exit "
                        f"{trailer_exit}"
                    ),
                )
            )

    return findings
