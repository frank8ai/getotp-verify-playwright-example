"""Shared plumbing for the ported gates.

Two things every gate needs, kept in one place so they cannot drift apart:

``GateResult``
    The outcome type: an exit code plus exactly one line for *stdout*.  The
    references use ``Write-Host``, which writes to the host stream rather than
    stderr, and callers both branch on the exit code and grep the marker on
    that line -- so the code and the message are equally part of the contract.

``load_document``
    Read + parse a JSON document the way the references do, which is *not* the
    same as ``json.loads(path.read_text())``.

``write_json_report``
    ``Set-Content -LiteralPath`` for a JSON document, including the
    create-the-parent-directory-only-when-there-is-one rule.  Three ports write
    reports now, and each had grown its own copy.

``ps_has_member`` / ``ps_string`` / ``ps_truthy`` / ``ps_equals`` / ``dotnet_trim``
    The coercions the validators lean on.  Every reference that inspects a JSON
    value eventually writes ``[string]$value``, ``-not $value``, or
    ``$value -eq $other``, and all three follow rules that are not the Python
    ones.  Getting one wrong either lets an unverified change through or breaks
    a legitimate agent, so each rule below was measured against the running
    reference and is pinned by a parity test.

    ``[string]`` -- note that an element *inside* a collection renders
    differently from the same value at the top level::

        ConvertFrom-Json '{"a":1}'       -> '@{a=1}'
        ConvertFrom-Json '{}'            -> ''
        ConvertFrom-Json '[{"a":1}]'     -> ''
        ConvertFrom-Json '{"a":{"b":1}}' -> '@{a=}'
        ConvertFrom-Json '[1,[2]]'       -> '1 System.Object[]'
        ConvertFrom-Json '[0,1]'         -> '0 1'
        ConvertFrom-Json 'true'          -> 'True'

    ``-not`` / ``[bool]``::

        {}         -> False     []         -> True      [null] -> True
        {"a":1}    -> False     [{}]       -> False     [0]    -> True
        "0"        -> False     [0,1]      -> False     ""     -> True

    ``-eq`` / ``-ne`` take their type from the **left** operand, so
    ``"0" -eq 0`` is True (the right side becomes a string) while
    ``$false -ne 0`` is False (the right side becomes a bool).  On a collection
    they *filter* instead of comparing, which is why a ``status`` of
    ``["pass"]`` counts as a pass.

    ``Trim()`` and ``IsNullOrWhiteSpace`` use .NET's whitespace set, which is
    **not** Python's: ``str.strip()`` also removes U+001C..U+001F and .NET keeps
    them.  Measured by making a reference emit 0x1C from a command -- the
    summary came back ``'x\\x1c'``, so the character survived the trim.

Why the helpers are shared
--------------------------

They started life as private copies, one per gate, and a probe against the live
references showed the copies disagreed with each other on real inputs -- which
is precisely the failure mode a parity gate exists to catch:

    input                     reference                  a divergent copy
    ------------------------- -------------------------- -------------------------
    empty file                unsupported schemaVersion  invalid json
    a directory               invalid json (exit 2)      uncaught PermissionError
    ``ConvertFrom-Json '{}'`` blank                      non-blank (``"@{}"``)
    ``-not {}``               False                      True
    ``-not [0]``              True                       False
    ``status: ["pass"]``      a pass                     not a pass

The blank-file row comes from ``ConvertFrom-Json ""`` returning ``$null``
*without throwing*, so a truncated write falls through to the schemaVersion
check instead of being reported as malformed JSON.  The directory row comes
from ``Test-Path`` being true for a directory while ``Get-Content -Raw`` on one
throws -- and the references wrap that call in ``try``/``catch``, so any read
failure at all becomes "invalid json".
"""

from __future__ import annotations

import json
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Any

INVALID_JSON = "invalid json"


@dataclass(frozen=True)
class GateResult:
    """Outcome of a gate: the exit code plus what to print, and where.

    ``message`` is the line callers grep for -- the marker.  ``extra_lines``
    carries the rest of a multi-line report (the permission resolver prints four
    lines, the evidence collector prints a whole JSON document before its
    marker).

    ``to_stderr`` exists because two references report a *different kind* of
    failure through a different stream: a deliberate refusal is ``Write-Host``
    plus ``exit 2`` on stdout, while an uncaught ``throw`` leaves stdout empty
    and puts the reason on stderr with exit 1.  Callers distinguish the two, so
    the port has to as well.
    """

    exit_code: int
    message: str
    extra_lines: tuple[str, ...] = ()
    to_stderr: bool = False

    def emit(self) -> int:
        """Write the report to its stream(s) and return the exit code."""
        stream = sys.stderr if self.to_stderr else sys.stdout
        print(self.message, file=stream)
        for line in self.extra_lines:
            print(line, file=stream)
        return self.exit_code


def parse_document(text: str) -> tuple[Any, str | None]:
    """Parse JSON text the way ``ConvertFrom-Json`` does.

    A blank document is ``$null``, *not* a parse failure: ``ConvertFrom-Json ""``
    returns ``$null`` without throwing.  That is why a truncated or empty file
    falls through to whichever check runs next -- ``unsupported schemaVersion``
    in most gates, ``serviceOrchestrator configuration missing`` in the
    permission resolver -- instead of being reported as malformed JSON.
    """
    if not text.strip():
        return None, None
    try:
        return json.loads(text), None
    except json.JSONDecodeError:
        return None, INVALID_JSON


def load_document(path: str | Path) -> tuple[Any, str | None]:
    """Read and parse a JSON document, returning ``(document, error_reason)``.

    ``error_reason`` is ``None`` when the file parsed -- or when it was blank,
    which the references treat as ``$null`` rather than as a parse failure.

    A *missing* file is deliberately not handled here: every reference checks
    existence first and reports its own wording ("missing brief file",
    "missing work-unit file", ...), so callers must do the same before calling
    this.  Anything else that goes wrong while reading is "invalid json",
    matching the references' ``try``/``catch`` around the read and the parse.
    """
    target = Path(path)
    try:
        text = target.read_text(encoding="utf-8-sig")
    except (OSError, UnicodeDecodeError):
        # OSError covers a directory (the reference reaches this via a
        # throwing `Get-Content -Raw`), an unreadable file, and a file that
        # vanished between the caller's existence check and this read.
        return None, INVALID_JSON
    return parse_document(text)


def ps_element_string(value: Any) -> str:
    """``[string]`` of a value *inside* a collection or a property.

    Not the same as :func:`ps_string`.  PowerShell renders a nested object as
    empty and a nested array as the type name, while the same value at the top
    level renders as ``@{a=1}``.  Measured:

        ConvertFrom-Json '{"a":1}'      -> '@{a=1}'
        ConvertFrom-Json '[{"a":1}]'    -> ''
        ConvertFrom-Json '{"a":{"b":1}}'-> '@{a=}'
        ConvertFrom-Json '[1,[2]]'      -> '1 System.Object[]'
        ConvertFrom-Json '{"a":[1,2]}'  -> '@{a=System.Object[]}'
    """
    if value is None:
        return ""
    if isinstance(value, bool):
        return "True" if value else "False"
    if isinstance(value, str):
        return value
    if isinstance(value, int):
        return str(value)
    if isinstance(value, float):
        return _ps_float_string(value)
    if isinstance(value, dict):
        # A nested object contributes nothing to the rendering.
        return ""
    if isinstance(value, list):
        return "System.Object[]"
    return str(value)


def ps_string(value: Any) -> str:
    """Reproduce PowerShell's ``[string]`` coercion for JSON-derived values.

    A top-level collection joins its elements with ``$OFS`` (a space); a
    collection *inside* one does not -- see :func:`ps_element_string`.  An empty
    object renders as the empty string, which is why ``is_blank`` treats ``{}``
    as blank: the reference's
    ``-not [string]::IsNullOrWhiteSpace([string]$_)`` filters it out.

    An integral JSON float is deliberately *not* pinned here: PowerShell 5.1
    deserialises ``0.0`` as a ``Decimal`` and prints ``"0.0"``, while pwsh 7
    deserialises it as a ``Double`` and prints ``"0"``.  The port follows pwsh
    (the CI host); the case is kept out of the parity matrix.
    """
    if isinstance(value, dict):
        if not value:
            return ""
        rendered = "; ".join(f"{key}={ps_element_string(item)}" for key, item in value.items())
        return "@{" + rendered + "}"
    if isinstance(value, list):
        return " ".join(ps_element_string(item) for item in value)
    return ps_element_string(value)


def _ps_float_string(value: float) -> str:
    """``[string]`` of a float, matching pwsh 7's ``Double`` rendering."""
    if value.is_integer() and abs(value) < 1e16:
        return str(int(value))
    return repr(value)


# ``Char.IsWhiteSpace`` -- the set .NET's ``Trim()`` and ``IsNullOrWhiteSpace``
# use.  Python's ``str.isspace()`` is *wider*: it also reports U+001C..U+001F,
# so ``str.strip()`` would remove four characters .NET keeps.
DOTNET_WHITESPACE = frozenset(
    "\t\n\v\f\r \x85\xa0\u1680"
    "\u2000\u2001\u2002\u2003\u2004\u2005\u2006\u2007\u2008\u2009\u200a"
    "\u2028\u2029\u202f\u205f\u3000"
)


def dotnet_trim(text: str) -> str:
    """``String.Trim()`` -- .NET's whitespace set, not Python's.

    The two differ on exactly U+001C..U+001F, which matters only because the
    trimmed text is sometimes *output* rather than merely tested for blankness:
    a summary that ends with a file separator keeps it, and a port built on
    ``str.strip()`` would drop it.
    """
    start = 0
    end = len(text)
    while start < end and text[start] in DOTNET_WHITESPACE:
        start += 1
    while end > start and text[end - 1] in DOTNET_WHITESPACE:
        end -= 1
    return text[start:end]


def is_blank(value: Any) -> bool:
    """``[string]::IsNullOrWhiteSpace([string]$value)``."""
    return dotnet_trim(ps_string(value)) == ""


def ps_truthy(value: Any) -> bool:
    """PowerShell truthiness, as applied by ``-not`` and ``[bool]``.

    Not ``bool(value)``.  The three rules that bite:

      * a **one-element collection converts its element**, so ``[0]`` and
        ``[null]`` are falsy while ``[0, 1]`` is truthy
      * a hashtable / PSCustomObject is an object, so it is truthy even when
        empty -- unlike an empty array
      * the string ``"0"`` is truthy while the number ``0`` is not

    Measured through ``ConvertFrom-Json``, which is how every gate sees these
    values:

        JSON value      -not    [bool]
        --------------  ------  ------
        {}              False   True
        {"a":1}         False   True
        []              True    False
        [null]          True    False
        [0]             True    False
        [{}]            False   True
        [""]            True    False
        ["x"]           False   True
        [0,1]           False   True
        [null,null]     False   True
        0               True    False
        "0"             False   True
        ""              True    False
    """
    if value is None:
        return False
    if isinstance(value, bool):
        return value
    if isinstance(value, (int, float)):
        return value != 0
    if isinstance(value, str):
        return len(value) > 0
    if isinstance(value, list):
        if len(value) == 1:
            return ps_truthy(value[0])
        return len(value) > 0
    if isinstance(value, dict):
        return True
    return True


def ps_has_member(value: Any, name: str) -> bool:
    """Whether a property *exists*, which ``ps_member`` cannot answer.

    ``ps_member`` returns the value, so a property that is present but ``$null``
    is indistinguishable from a missing one.  ``Add-Member`` cares about the
    difference: it refuses to add a property that already exists even when the
    existing value is falsy, which turns a re-written ``schemaVersion`` into a
    terminating error rather than a silent default.
    """
    if isinstance(value, dict):
        wanted = name.lower()
        return any(str(key).lower() == wanted for key in value)
    return False


def write_json_report(path: str | Path, text: str) -> None:
    """Write a JSON report the way ``Set-Content -LiteralPath`` does.

    Two host-isms are deliberately dropped, for the reasons spelled out in
    ``evidence_collection``'s module docstring: PowerShell 5.1 writes
    ``-Encoding UTF8`` **with a BOM** and ``ConvertTo-Json`` emits CRLF, while
    the port writes UTF-8 without a BOM and LF.  Callers parse the document, so
    neither is a contract -- and a BOM is actively hostile to ``git diff``.

    ``Split-Path -Parent`` yields ``""`` for a bare filename and every reference
    guards its ``New-Item -ItemType Directory`` on that being non-empty, so a
    relative name must not create ``./``.  ``Path("x.json").parent`` is ``"."``,
    which is why both spellings are excluded.
    """
    destination = Path(path)
    parent = str(destination.parent)
    if parent not in ("", "."):
        destination.parent.mkdir(parents=True, exist_ok=True)
    # `Set-Content` appends a line terminator after the value.
    destination.write_text(text + "\n", encoding="utf-8")


def ps_member(value: Any, name: str) -> Any:
    """``$value.<name>`` including PowerShell's member enumeration.

    Property lookup is case-insensitive, a missing property is ``$null``, and
    reading a property off a *collection* maps over its elements and collapses
    the result -- which is how ``@().reviewer.name`` ends up ``$null``.
    """
    if isinstance(value, dict):
        wanted = name.lower()
        for key, item in value.items():
            if str(key).lower() == wanted:
                return item
        return None
    if isinstance(value, list):
        found = [ps_member(item, name) for item in value]
        found = [item for item in found if item is not None]
        if not found:
            return None
        if len(found) == 1:
            return found[0]
        return found
    return None


def _ps_equals_scalar(left: Any, right: Any) -> bool:
    """``$left -eq $right`` for a scalar left operand."""
    if left is None:
        return right is None
    if isinstance(left, bool):
        # The left operand's type wins: the right operand becomes a bool.
        return ps_truthy(right) is left
    if isinstance(left, (int, float)):
        if isinstance(right, bool):
            return left == (1 if right else 0)
        if isinstance(right, (int, float)):
            return left == right
        if isinstance(right, str):
            # A non-numeric string simply does not compare equal; PowerShell
            # returns $false here rather than throwing.
            try:
                return left == float(right)
            except ValueError:
                return False
        return False
    if isinstance(left, str):
        # The left operand's type wins again: the right operand becomes a string.
        return left.lower() == ps_string(right).lower()
    if isinstance(left, dict):
        # Hashtables compare by reference.
        return left is right
    return left is right


def ps_equals(left: Any, right: Any) -> bool:
    """Truthiness of ``$left -eq $right``.

    On a collection ``-eq`` *filters* instead of comparing, so the result is
    truthy exactly when at least one element matches -- which is why a
    ``status`` of ``["pass"]`` counts as a pass.
    """
    if isinstance(left, list):
        return any(_ps_equals_scalar(item, right) for item in left)
    return _ps_equals_scalar(left, right)


def ps_not_equals(left: Any, right: Any) -> bool:
    """Truthiness of ``$left -ne $right`` -- the complement, element-wise."""
    if isinstance(left, list):
        return any(not _ps_equals_scalar(item, right) for item in left)
    return not _ps_equals_scalar(left, right)
