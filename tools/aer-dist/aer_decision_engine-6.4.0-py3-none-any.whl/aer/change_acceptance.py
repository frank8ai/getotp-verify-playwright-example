"""Baseline vs Candidate Executable Acceptance Core (Task E2).

Implements the first-principles change acceptance model:
1. Targeted defect evidence:
   - BASELINE demonstrates the defect (reproduction command fails).
   - CANDIDATE cures the defect (same reproduction command passes).
2. Regression evidence:
   - Regression gates run on both baseline and candidate in separate, fresh sandboxes.
   - Computes failure delta: pre-existing, resolved, newly introduced, and missing surface.
3. Strict verdict semantics:
   - PASS: defect cured, no new regressions, surface intact, environment equivalent.
   - FAIL: defect unresolved, new regressions introduced, or required surface removed.
   - UNKNOWN: defect not reproduced on baseline, environment mismatch, or infrastructure failure.
"""

from __future__ import annotations

import hashlib
import json
import os
import shlex
import shutil
import subprocess
import sys
import tempfile
import time
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable, Iterable, Mapping, Sequence

from harness.sandbox.base import SandboxDriver, SandboxExecutionResult, compute_dir_diff_digest
from harness.sandbox.docker import DockerSandbox, is_docker_available
from harness.sandbox.selection import SandboxPolicyViolationError, select_sandbox_driver
from .closure import (
    ClosureError,
    _classify,
    _fingerprint,
    compute_environment_digest,
    load_manifest,
    select_gates,
)
from .environment import sha256_text

ACCEPTANCE_SCHEMA_VERSION = "change-acceptance/v1"
LOG_TRAILER_PREFIX = "[aer]"


class AcceptanceExecutionError(RuntimeError):
    pass

AER_PYTEST_COLLECTOR_PLUGIN_SOURCE = """# AER Structured Pytest Outcome Collector
import json
import os
import sys
import pytest

class AerPytestOutcomeCollector:
    def __init__(self, out_path: str):
        self.out_path = out_path
        self.reports = []
        self.collection_errors = []

    def pytest_collectreport(self, report):
        if report.failed:
            err_msg = str(report.longrepr)
            self.collection_errors.append({
                "nodeid": report.nodeid,
                "outcome": report.outcome,
                "longrepr": err_msg,
            })

    @pytest.hookimpl(hookwrapper=True)
    def pytest_runtest_makereport(self, item, call):
        outcome = yield
        report = outcome.get_result()
        if call.excinfo is not None:
            report.exc_type = getattr(call.excinfo, "typename", None)
            report.exc_value = str(getattr(call.excinfo, "value", ""))

    def pytest_runtest_logreport(self, report):
        long_txt = getattr(report, "longreprtext", None) or (str(report.longrepr) if report.longrepr else "")
        exc_type = getattr(report, "exc_type", None)
        exc_value = getattr(report, "exc_value", None)
        if not exc_type and report.failed and long_txt:
            if "AssertionError" in long_txt or "assert " in long_txt:
                exc_type = "AssertionError"
            else:
                for line in reversed(long_txt.strip().splitlines()):
                    if ":" in line:
                        cand = line.split(":")[-1].strip().split()[0] if line.split(":")[-1].strip() else ""
                        if cand and cand.isidentifier():
                            exc_type = cand
                            break
        self.reports.append({
            "nodeid": report.nodeid,
            "when": report.when,
            "outcome": report.outcome,
            "failed": report.failed,
            "passed": report.passed,
            "skipped": report.skipped,
            "exc_type": exc_type,
            "exc_value": exc_value,
            "longrepr": long_txt if report.failed else None,
            "duration": getattr(report, "duration", 0.0),
        })

    def pytest_sessionfinish(self, session, exitstatus):
        data = {
            "exitstatus": int(exitstatus),
            "collection_errors": self.collection_errors,
            "reports": self.reports,
        }
        try:
            with open(self.out_path, "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False)
        except OSError:
            pass

def pytest_configure(config):
    out = os.environ.get("AER_PYTEST_OUTCOME_FILE", ".aer_pytest_outcome.json")
    config.pluginmanager.register(AerPytestOutcomeCollector(out), "aer_pytest_outcome_collector")
"""


def classify_pytest_outcome_data(
    exit_code: int,
    data: dict[str, Any] | None,
    stdout: str,
    stderr: str,
    *,
    customer_code_mode: bool = True,
) -> tuple[str, str | None]:
    out_all = f"{stdout}\n{stderr}"
    if exit_code in (126, 127, 9009) or "not recognized as an internal or external command" in out_all:
        return "HARNESS_ERROR", "COMMAND_NOT_FOUND"
    if "No module named" in out_all:
        return "HARNESS_ERROR", "RUNNER_MODULE_NOT_FOUND"
    if exit_code == 4 or "file or directory not found" in out_all:
        return "HARNESS_ERROR", "PYTEST_USAGE_OR_MISSING_PATH_ERROR"
    if exit_code == 5:
        return "HARNESS_ERROR", "PYTEST_NO_TESTS_COLLECTED"

    if data is None:
        if exit_code == 0:
            return "DEFECT_ABSENT", None
        if not customer_code_mode:
            if "ModuleNotFoundError" in out_all or "ImportError" in out_all:
                return "HARNESS_ERROR", "IMPORT_OR_DEPENDENCY_FAILURE"
            if "SyntaxError" in out_all:
                return "HARNESS_ERROR", "SYNTAX_ERROR"
            return "DEFECT_OBSERVED", None
        return "HARNESS_ERROR", f"PYTEST_NO_STRUCTURED_DATA_EXIT_{exit_code}"

    exitstatus = data.get("exitstatus", exit_code)
    coll_errors = data.get("collection_errors", [])
    reports = data.get("reports", [])

    if coll_errors:
        return "HARNESS_ERROR", "PYTEST_COLLECTION_ERROR"
    if exitstatus == 4:
        return "HARNESS_ERROR", "PYTEST_USAGE_OR_MISSING_PATH_ERROR"
    if exitstatus == 5 or (not reports and exitstatus != 0):
        return "HARNESS_ERROR", "PYTEST_NO_TESTS_COLLECTED"
    if exitstatus in (2, 3) and not reports:
        return "HARNESS_ERROR", "PYTEST_COLLECTION_OR_INTERNAL_ERROR"

    # Check setup / teardown errors
    for r in reports:
        when = r.get("when")
        failed = r.get("failed")
        exc = r.get("exc_type")
        if when == "setup" and failed:
            return "HARNESS_ERROR", f"PYTEST_SETUP_ERROR:{exc or 'UNKNOWN'}"
        if when == "teardown" and failed:
            return "HARNESS_ERROR", f"PYTEST_TEARDOWN_ERROR:{exc or 'UNKNOWN'}"

    call_reports = [r for r in reports if r.get("when") == "call"]
    if not call_reports:
        if exitstatus == 0:
            return "DEFECT_ABSENT", None
        return "HARNESS_ERROR", "PYTEST_NO_TEST_CALL_EVALUATED"

    call_failures = [r for r in call_reports if r.get("failed")]
    if not call_failures and exitstatus == 0:
        return "DEFECT_ABSENT", None

    for cf in call_failures:
        exc = cf.get("exc_type")
        val = cf.get("exc_value", "") or ""
        longrepr = cf.get("longrepr", "") or ""

        # If explicit exception type is known:
        if exc:
            if exc == "AssertionError":
                return "DEFECT_OBSERVED", None
            return "HARNESS_ERROR", f"UNEXPECTED_EXCEPTION:{exc}"

        # Fallback inspection of failure representation:
        if "AssertionError" in val or "AssertionError" in longrepr:
            return "DEFECT_OBSERVED", None
        return "HARNESS_ERROR", f"UNEXPECTED_EXCEPTION:RUNTIME_ERROR"

    return "HARNESS_ERROR", "PYTEST_INCONCLUSIVE"


def classify_script_outcome(
    exit_code: int,
    stdout: str,
    stderr: str,
    *,
    customer_code_mode: bool = True,
) -> tuple[str, str | None]:
    out_all = f"{stdout}\n{stderr}"
    if exit_code == 0:
        return "DEFECT_ABSENT", None
    if exit_code in (126, 127, 9009) or "not recognized as an internal or external command" in out_all or "can'''t open file" in stderr:
        return "HARNESS_ERROR", "COMMAND_NOT_FOUND"
    if "No module named" in out_all:
        return "HARNESS_ERROR", "RUNNER_MODULE_NOT_FOUND"
    if exit_code == 2 and ("usage:" in stderr or "error: unrecognized" in stderr):
        return "HARNESS_ERROR", "COMMAND_OR_USAGE_ERROR"
    if "ModuleNotFoundError" in out_all or "ImportError" in out_all:
        return "HARNESS_ERROR", "IMPORT_OR_DEPENDENCY_FAILURE"
    if "SyntaxError" in out_all:
        return "HARNESS_ERROR", "SYNTAX_ERROR"

    # Dedicated documented code 101 or structured marker
    if exit_code == 101 or "AER_DEFECT_OBSERVED" in out_all or "[DEFECT_OBSERVED]" in out_all:
        return "DEFECT_OBSERVED", None

    # In customer code mode, strict reproduction protocol requires explicit evidence
    if customer_code_mode:
        return "HARNESS_ERROR", f"SCRIPT_EXIT_{exit_code}_WITHOUT_EXPLICIT_DEFECT_SIGNAL"

    # Legacy / non-customer compatibility fallback
    if "AssertionError" in out_all:
        return "DEFECT_OBSERVED", None

    return "HARNESS_ERROR", f"SCRIPT_EXIT_{exit_code}_WITHOUT_EXPLICIT_DEFECT_SIGNAL"


def classify_reproduction_observation(
    outcome: AcceptanceOutcome,
    *,
    customer_code_mode: bool = True,
) -> tuple[str, str | None]:
    """Classify reproduction execution into DEFECT_OBSERVED, DEFECT_ABSENT, or HARNESS_ERROR.

    Enforces the Phase-1 acceptance invariant:
    AER must never infer target-defect observation merely because a command failed.
    """
    if outcome.observation in ("DEFECT_OBSERVED", "DEFECT_ABSENT", "HARNESS_ERROR"):
        if customer_code_mode and outcome.protocol == "LEGACY" and outcome.observation == "DEFECT_OBSERVED":
            return "HARNESS_ERROR", "NON_AUTHORITATIVE_REPRODUCTION_PROTOCOL"
        return outcome.observation, outcome.harness_error

    cmd = outcome.command or ""
    code = outcome.exit_code
    stdout = outcome.stdout or ""
    stderr = outcome.stderr or ""
    proto = outcome.protocol

    if proto == "PYTEST_TARGET" or "pytest" in cmd:
        return classify_pytest_outcome_data(
            code,
            getattr(outcome, "structured_data", None),
            stdout,
            stderr,
            customer_code_mode=customer_code_mode,
        )

    if proto == "EXPLICIT_SCRIPT" or (cmd and not cmd.startswith("pytest")):
        return classify_script_outcome(code, stdout, stderr, customer_code_mode=customer_code_mode)

    return "HARNESS_ERROR", f"UNKNOWN_PROTOCOL_EXIT_{code}"

@dataclass(frozen=True)
class AcceptanceOutcome:
    """Outcome of running the targeted reproduction command on a commit."""

    command: str
    exit_code: int
    passed: bool
    stdout: str
    stderr: str
    duration_ms: float
    log_digest: str
    protocol: str = "GENERIC"
    observation: str = "INCONCLUSIVE"
    harness_error: str | None = None
    structured_data: dict[str, Any] | None = None

    def to_dict(self) -> dict[str, Any]:
        data = {
            "command": self.command,
            "exitCode": self.exit_code,
            "passed": self.passed,
            "durationMs": self.duration_ms,
            "logDigest": self.log_digest,
            "protocol": self.protocol,
            "observation": self.observation,
        }
        if self.harness_error is not None:
            data["harnessError"] = self.harness_error
        return data

@dataclass(frozen=True)
class RegressionGateOutcome:
    """Outcome of running one regression gate on a commit."""

    id: str
    command: str
    exit_code: int
    passed: bool
    fingerprint: str
    duration_ms: float
    log_digest: str

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "command": self.command,
            "exitCode": self.exit_code,
            "passed": self.passed,
            "fingerprint": self.fingerprint,
            "durationMs": self.duration_ms,
            "logDigest": self.log_digest,
        }


@dataclass(frozen=True)
class CommitExecutionRecord:
    """Complete execution record for a commit (baseline or candidate)."""

    sha: str
    tree_sha: str
    environment_digest: str
    image: str
    reproduction_outcome: AcceptanceOutcome
    gate_outcomes: list[RegressionGateOutcome]
    duration_ms: float

    def to_dict(self) -> dict[str, Any]:
        return {
            "sha": self.sha,
            "treeSha": self.tree_sha,
            "environmentDigest": self.environment_digest,
            "image": self.image,
            "reproductionOutcome": self.reproduction_outcome.to_dict(),
            "gateOutcomes": [g.to_dict() for g in self.gate_outcomes],
            "durationMs": self.duration_ms,
        }


@dataclass(frozen=True)
class ChangeAcceptanceReport:
    """Final structured evidence report bound to exact baseline and candidate SHAs."""

    schema_version: str
    verdict: str  # PASS | FAIL | UNKNOWN
    reasons: list[str]
    timestamp: str
    repository: str
    baseline: CommitExecutionRecord
    candidate: CommitExecutionRecord
    causal_attribution: dict[str, Any]
    execution_metrics: dict[str, Any]
    test_integrity: dict[str, Any] | None = None
    reproduction: dict[str, Any] | None = None
    acceptance_contract: dict[str, Any] | None = None

    def render_brief(self) -> str:
        from .acceptance_brief import render_acceptance_brief
        return render_acceptance_brief(self)

    def to_dict(self) -> dict[str, Any]:
        data = {
            "schemaVersion": self.schema_version,
            "verdict": self.verdict,
            "reasons": list(self.reasons),
            "timestamp": self.timestamp,
            "repository": self.repository,
            "baseline": self.baseline.to_dict(),
            "candidate": self.candidate.to_dict(),
            "causalAttribution": self.causal_attribution,
            "executionMetrics": self.execution_metrics,
        }
        if self.test_integrity is not None:
            data["testIntegrity"] = self.test_integrity
        if self.reproduction is not None:
            data["reproduction"] = self.reproduction
        if self.acceptance_contract is not None:
            data["acceptanceContract"] = self.acceptance_contract
        return data

def _compute_log_digest(stdout: str, stderr: str, exit_code: int) -> str:
    payload = f"{stdout}\n{stderr}\n{LOG_TRAILER_PREFIX} exit-code: {exit_code}\n".encode("utf-8")
    return "sha256:" + hashlib.sha256(payload).hexdigest()


def _git_output(repo_path: Path, *args: str) -> str:
    completed = subprocess.run(
        ["git", "-C", str(repo_path), *args],
        capture_output=True,
        text=True,
        check=False,
    )
    if completed.returncode != 0:
        raise AcceptanceExecutionError(
            f"Git command failed (exit {completed.returncode}): git -C {repo_path} {' '.join(args)}\n{completed.stderr}"
        )
    return completed.stdout.strip()


def resolve_commit_shas(repo_path: Path, ref_or_sha: str) -> tuple[str, str]:
    """Resolve commit SHA and tree SHA for a given git reference."""
    commit_sha = _git_output(repo_path, "rev-parse", f"{ref_or_sha}^{{commit}}")
    tree_sha = _git_output(repo_path, "rev-parse", f"{commit_sha}^{{tree}}")
    return commit_sha, tree_sha


def checkout_commit_tree(repo_path: Path, commit_sha: str, target_dir: Path) -> None:
    """Extract pristine file tree at commit_sha into target_dir."""
    target_dir.mkdir(parents=True, exist_ok=True)
    # Try git worktree add first to preserve local git tracking if needed
    try:
        subprocess.run(
            ["git", "-C", str(repo_path), "worktree", "add", "--detach", str(target_dir), commit_sha],
            capture_output=True,
            text=True,
            check=True,
        )
        return
    except subprocess.SubprocessError:
        pass

    # Fallback to git archive extraction
    archive_proc = subprocess.run(
        ["git", "-C", str(repo_path), "archive", commit_sha],
        capture_output=True,
        check=True,
    )
    import io
    import tarfile

    with tarfile.open(fileobj=io.BytesIO(archive_proc.stdout)) as tar:
        tar.extractall(path=target_dir)


def cleanup_commit_worktree(repo_path: Path, target_dir: Path) -> None:
    """Clean up worktree or temporary directory."""
    try:
        subprocess.run(
            ["git", "-C", str(repo_path), "worktree", "remove", "--force", str(target_dir)],
            capture_output=True,
            check=False,
        )
    except Exception:
        pass
    shutil.rmtree(target_dir, ignore_errors=True)


def evaluate_change_acceptance(
    baseline: CommitExecutionRecord,
    candidate: CommitExecutionRecord,
    *,
    repository: str,
    timestamp: str = "",
    integrity_report: Any | None = None,
    customer_code_mode: bool | None = None,
    acceptance_contract: Any | None = None,
) -> ChangeAcceptanceReport:
    """Evaluate First-Principles change acceptance from baseline and candidate records.

    This function is completely deterministic and in-memory testable.
    """
    reasons: list[str] = []

    # 1. Environment Equivalence
    is_equivalent = baseline.environment_digest == candidate.environment_digest
    if not is_equivalent:
        reasons.append("ENVIRONMENT_DIGEST_MISMATCH")

    # 2. Targeted Defect Evidence (Phase-1 Strict Observation Truth Model)
    # BASELINE: must demonstrate the defect (DEFECT_OBSERVED)
    # CANDIDATE: must cure the defect (DEFECT_ABSENT)
    if customer_code_mode is None:
        customer_mode = getattr(baseline, "customer_code_mode", False)
    else:
        customer_mode = customer_code_mode
    base_obs, base_harness_err = classify_reproduction_observation(
        baseline.reproduction_outcome,
        customer_code_mode=customer_mode,
    )
    cand_obs, cand_harness_err = classify_reproduction_observation(
        candidate.reproduction_outcome,
        customer_code_mode=customer_mode,
    )

    if base_obs == "HARNESS_ERROR":
        reproduction_transition = "ERROR"
        reasons.append(f"BASELINE_REPRODUCTION_HARNESS_ERROR:{base_harness_err}")
    elif cand_obs == "HARNESS_ERROR":
        reproduction_transition = "ERROR"
        reasons.append(f"CANDIDATE_REPRODUCTION_HARNESS_ERROR:{cand_harness_err}")
    elif base_obs == "DEFECT_ABSENT":
        reproduction_transition = "NON_REPRODUCIBLE"
        reasons.append("TARGET_DEFECT_NOT_REPRODUCED_ON_BASELINE")
    elif cand_obs == "DEFECT_OBSERVED":
        reproduction_transition = "UNRESOLVED"
        reasons.append("TARGET_DEFECT_NOT_FIXED_ON_CANDIDATE")
    elif base_obs == "DEFECT_OBSERVED" and cand_obs == "DEFECT_ABSENT":
        reproduction_transition = "CURED"
    else:
        reproduction_transition = "ERROR"
        reasons.append("REPRODUCTION_OBSERVATION_INCONCLUSIVE")

    # 3. Regression Differential
    base_failures = {
        g.id: g.fingerprint
        for g in baseline.gate_outcomes
        if not g.passed
    }
    candidate_failures = {
        g.id: g.fingerprint
        for g in candidate.gate_outcomes
        if not g.passed
    }

    base_gate_ids = [g.id for g in baseline.gate_outcomes]
    cand_gate_ids = [g.id for g in candidate.gate_outcomes]
    removed_gate_ids = [gid for gid in base_gate_ids if gid not in cand_gate_ids]
    is_surface_intact = len(removed_gate_ids) == 0

    if not is_surface_intact:
        reasons.append("TEST_SURFACE_REMOVED")

    new_failures: list[dict[str, Any]] = []
    for g in candidate.gate_outcomes:
        if g.passed:
            continue
        if g.id not in base_failures:
            new_failures.append({"id": g.id, "fingerprint": g.fingerprint, "reason": "NEW_FAILURE"})
        elif base_failures[g.id] != g.fingerprint:
            new_failures.append({"id": g.id, "fingerprint": g.fingerprint, "reason": "FINGERPRINT_MODIFIED"})

    if new_failures:
        reasons.append("NEW_REGRESSIONS_INTRODUCED")

    resolved_failures = [
        {"id": gid, "fingerprint": fp}
        for gid, fp in base_failures.items()
        if gid not in candidate_failures
    ]

    # 4. Test Integrity & Anti-Tautology Audit (Task E3)
    integrity_dict = None
    if integrity_report is not None:
        integrity_dict = integrity_report.to_dict() if hasattr(integrity_report, "to_dict") else dict(integrity_report)
        status = integrity_dict.get("status", "PASS")
        if status != "PASS":
            reasons.append("TEST_INTEGRITY_VIOLATION")
            for f in integrity_dict.get("findings", []):
                kind = f.get("kind", "UNKNOWN")
                loc = f.get("location", "")
                reasons.append(f"{kind}:{loc}")
            if status == "HUMAN_REQUIRED":
                reasons.append("TEST_INTEGRITY_HUMAN_REQUIRED")

    # 5. Verdict Synthesis
    if (
        "ENVIRONMENT_DIGEST_MISMATCH" in reasons
        or "TARGET_DEFECT_NOT_REPRODUCED_ON_BASELINE" in reasons
        or "TEST_INTEGRITY_HUMAN_REQUIRED" in reasons
        or any(r.startswith("BASELINE_REPRODUCTION_HARNESS_ERROR") for r in reasons)
        or any(r.startswith("CANDIDATE_REPRODUCTION_HARNESS_ERROR") for r in reasons)
        or "REPRODUCTION_OBSERVATION_INCONCLUSIVE" in reasons
    ):
        verdict = "UNKNOWN"
    elif (
        "TARGET_DEFECT_NOT_FIXED_ON_CANDIDATE" in reasons
        or "NEW_REGRESSIONS_INTRODUCED" in reasons
        or "TEST_SURFACE_REMOVED" in reasons
        or "TEST_INTEGRITY_VIOLATION" in reasons
    ):
        verdict = "FAIL"
    elif (
        reproduction_transition == "CURED"
        and not new_failures
        and is_surface_intact
        and is_equivalent
        and "TEST_INTEGRITY_VIOLATION" not in reasons
    ):
        verdict = "PASS"
    else:
        verdict = "UNKNOWN"

    requested_condition = baseline.reproduction_outcome.command
    repro_protocol = baseline.reproduction_outcome.protocol
    harness_status = "OK"
    if base_obs == "HARNESS_ERROR":
        harness_status = f"BASELINE_HARNESS_ERROR:{base_harness_err}"
    elif cand_obs == "HARNESS_ERROR":
        harness_status = f"CANDIDATE_HARNESS_ERROR:{cand_harness_err}"

    reproduction_evidence = {
        "protocol": repro_protocol,
        "requestedCondition": requested_condition,
        "baselineObservation": base_obs,
        "candidateObservation": cand_obs,
        "harnessStatus": harness_status,
    }

    causal_attribution = {
        "reproductionTransition": reproduction_transition,
        "failureDeltaCount": len(new_failures),
        "newFailures": new_failures,
        "resolvedFailures": resolved_failures,
        "surfaceDelta": {
            "baseCount": len(base_gate_ids),
            "candidateCount": len(cand_gate_ids),
            "removedGateIds": removed_gate_ids,
            "isSurfaceIntact": is_surface_intact,
        },
        "environmentDelta": {
            "baseDigest": baseline.environment_digest,
            "candidateDigest": candidate.environment_digest,
            "isEquivalent": is_equivalent,
        },
        "reproduction": reproduction_evidence,
    }

    execution_metrics = {
        "baselineDurationMs": baseline.duration_ms,
        "candidateDurationMs": candidate.duration_ms,
        "totalDurationMs": baseline.duration_ms + candidate.duration_ms,
    }

    ts = timestamp or datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")

    contract_dict = None
    if acceptance_contract is not None:
        contract_dict = acceptance_contract.to_dict() if hasattr(acceptance_contract, "to_dict") else dict(acceptance_contract)

    # In customer_code_mode, authoritative PASS requires a trusted acceptance contract!
    if customer_mode:
        if contract_dict is None:
            if verdict == "PASS":
                verdict = "UNKNOWN"
            if "UNTRUSTED_OR_MISSING_ACCEPTANCE_CONTRACT" not in reasons:
                reasons.append("UNTRUSTED_OR_MISSING_ACCEPTANCE_CONTRACT")
        else:
            # Verify contract matches expected transitions
            contract_proto = contract_dict.get("protocol")
            contract_cond = contract_dict.get("condition")
            if contract_proto and repro_protocol != contract_proto:
                if verdict == "PASS":
                    verdict = "UNKNOWN"
                if "ACCEPTANCE_CONTRACT_PROTOCOL_MISMATCH" not in reasons:
                    reasons.append("ACCEPTANCE_CONTRACT_PROTOCOL_MISMATCH")
            if contract_cond and requested_condition.strip() != contract_cond.strip():
                if verdict == "PASS":
                    verdict = "UNKNOWN"
                if "ACCEPTANCE_CONTRACT_CONDITION_MISMATCH" not in reasons:
                    reasons.append("ACCEPTANCE_CONTRACT_CONDITION_MISMATCH")
            contract_target = contract_dict.get("target")
            if contract_target and contract_target.strip() not in requested_condition:
                if verdict == "PASS":
                    verdict = "UNKNOWN"
                if "ACCEPTANCE_CONTRACT_CONDITION_MISMATCH" not in reasons:
                    reasons.append("ACCEPTANCE_CONTRACT_CONDITION_MISMATCH")

    return ChangeAcceptanceReport(
        schema_version=ACCEPTANCE_SCHEMA_VERSION,
        verdict=verdict,
        reasons=reasons,
        timestamp=ts,
        repository=repository,
        baseline=baseline,
        candidate=candidate,
        causal_attribution=causal_attribution,
        execution_metrics=execution_metrics,
        test_integrity=integrity_dict,
        reproduction=reproduction_evidence,
        acceptance_contract=contract_dict,
    )


def execute_commit_in_sandbox(
    workspace_dir: Path,
    *,
    sha: str,
    tree_sha: str,
    reproduce_command: str,
    gates: Sequence[dict[str, Any]],
    environment_digest: str,
    sandbox_factory: Callable[[Path], SandboxDriver] | None = None,
    sandbox_driver: str = "docker",
    customer_code_mode: bool = True,
    docker_image: str = "python:3.12-slim",
) -> CommitExecutionRecord:
    """Execute reproduction command and regression gates within a dedicated, fresh sandbox."""
    t0 = time.perf_counter()

    if sandbox_factory is not None:
        driver = sandbox_factory(workspace_dir)
    else:
        profile = "aer-verify" if customer_code_mode else "autopilot-low"
        driver = select_sandbox_driver(
            repo_dir=workspace_dir,
            profile=profile,
            requested_driver=sandbox_driver,
            customer_code_mode=customer_code_mode,
            docker_image=docker_image,
        )

    try:
        # Detect reproduction protocol
        cmd_str = reproduce_command
        cmd_lower = cmd_str.lower()
        is_pytest = "pytest" in cmd_lower
        protocol = "PYTEST_TARGET" if is_pytest else "EXPLICIT_SCRIPT"

        # Prepare pytest outcome collection plugin if pytest protocol
        outcome_file_rel = ".aer_pytest_outcome.json"
        conftest_file = workspace_dir / "conftest.py"
        existing_conftest_content = None

        if is_pytest:
            try:
                if conftest_file.is_file():
                    existing_conftest_content = conftest_file.read_text(encoding="utf-8")
                    conftest_file.write_text(
                        existing_conftest_content + "\n\n" + AER_PYTEST_COLLECTOR_PLUGIN_SOURCE,
                        encoding="utf-8",
                    )
                else:
                    conftest_file.write_text(AER_PYTEST_COLLECTOR_PLUGIN_SOURCE, encoding="utf-8")
            except OSError:
                pass

        extra_env: dict[str, str] = {}
        try:
            import site
            site_dirs = os.pathsep.join(p for p in site.getsitepackages() if os.path.isdir(p))
            if site_dirs:
                cur_pypath = os.environ.get("PYTHONPATH", "")
                extra_env["PYTHONPATH"] = f"{cur_pypath}{os.pathsep}{site_dirs}" if cur_pypath else site_dirs
        except Exception:
            pass

        # 1. Run targeted reproduction command (command is 100% unmutated, passes verified site packages)
        t_rep0 = time.perf_counter()
        rep_res = driver.run_command(reproduce_command, cwd=workspace_dir, env=extra_env if extra_env else None)
        rep_dur = (time.perf_counter() - t_rep0) * 1000.0
        rep_passed = rep_res.exit_code == 0
        rep_log_digest = _compute_log_digest(rep_res.stdout, rep_res.stderr, rep_res.exit_code)

        structured_data = None
        outcome_file_path = workspace_dir / outcome_file_rel
        if outcome_file_path.is_file():
            try:
                structured_data = json.loads(outcome_file_path.read_text(encoding="utf-8"))
            except Exception:
                structured_data = None

        obs, harness_err = classify_reproduction_observation(
            AcceptanceOutcome(
                command=reproduce_command,
                exit_code=rep_res.exit_code,
                passed=rep_passed,
                stdout=rep_res.stdout,
                stderr=rep_res.stderr,
                duration_ms=rep_dur,
                log_digest=rep_log_digest,
                protocol=protocol,
                structured_data=structured_data,
            ),
            customer_code_mode=customer_code_mode,
        )

        reproduction_outcome = AcceptanceOutcome(
            command=reproduce_command,
            exit_code=rep_res.exit_code,
            passed=rep_passed,
            stdout=rep_res.stdout,
            stderr=rep_res.stderr,
            duration_ms=rep_dur,
            log_digest=rep_log_digest,
            protocol=protocol,
            observation=obs,
            harness_error=harness_err,
            structured_data=structured_data,
        )

        # 2. Run regression gates
        gate_outcomes: list[RegressionGateOutcome] = []
        for g in gates:
            cmd = str(g["command"])
            gid = str(g["id"])
            t_gate0 = time.perf_counter()
            gate_res = driver.run_command(cmd, cwd=workspace_dir)
            gate_dur = (time.perf_counter() - t_gate0) * 1000.0
            gate_passed = gate_res.exit_code == 0
            gate_fp = _fingerprint(gid, gate_res.exit_code, f"{gate_res.stdout}\n{gate_res.stderr}")
            gate_log_digest = _compute_log_digest(gate_res.stdout, gate_res.stderr, gate_res.exit_code)
            gate_outcomes.append(
                RegressionGateOutcome(
                    id=gid,
                    command=cmd,
                    exit_code=gate_res.exit_code,
                    passed=gate_passed,
                    fingerprint=gate_fp,
                    duration_ms=gate_dur,
                    log_digest=gate_log_digest,
                )
            )
    finally:
        driver.dispose()

    total_dur = (time.perf_counter() - t0) * 1000.0

    rec = CommitExecutionRecord(
        sha=sha,
        tree_sha=tree_sha,
        environment_digest=environment_digest,
        image=docker_image,
        reproduction_outcome=reproduction_outcome,
        gate_outcomes=gate_outcomes,
        duration_ms=total_dur,
    )
    object.__setattr__(rec, "customer_code_mode", customer_code_mode)
    return rec

def run_change_acceptance(
    repo: Path | str = ".",
    *,
    base_ref: str,
    candidate_ref: str,
    reproduce_command: str = "",
    acceptance_contract: Any | None = None,
    contract_path: str | Path | None = None,
    tier: str = "cheap",
    sandbox_driver: str = "docker",
    customer_code_mode: bool = True,
    docker_image: str = "python:3.12-slim",
    sandbox_factory: Callable[[Path], SandboxDriver] | None = None,
) -> ChangeAcceptanceReport:
    """Orchestrate Task E2 dual-sandbox baseline vs candidate acceptance protocol."""
    repo_path = Path(repo).resolve()
    manifest = load_manifest(repo_path)
    env_digest = compute_environment_digest(manifest)
    gates = select_gates(manifest, tier)
    repo_name = manifest.get("repoKey", repo_path.name)

    base_sha, base_tree = resolve_commit_shas(repo_path, base_ref)
    cand_sha, cand_tree = resolve_commit_shas(repo_path, candidate_ref)

    from .antithesis import (
        analyze_added_test,
        analyze_test_diff_integrity,
        is_collected_test_path,
        is_non_python_test_path,
    )

    base_test_files: dict[str, str] = {}
    cand_test_files: dict[str, str] = {}
    unsupported_test_files: list[str] = []

    # P0-3: Measure wall-clock start immediately before acceptance execution begins
    wall_start_dt = datetime.now(timezone.utc)
    wall_start_iso = wall_start_dt.isoformat().replace("+00:00", "Z")
    wall_t0 = time.perf_counter()

    # Step 1: Baseline sandbox execution
    base_tmp = Path(tempfile.mkdtemp(prefix="aer-accept-base-"))
    try:
        checkout_commit_tree(repo_path, base_sha, base_tmp)
        from .contract import load_trusted_acceptance_contract, TrustedAcceptanceContract
        active_contract = load_trusted_acceptance_contract(
            base_tmp,
            contract_path=contract_path,
            explicit_contract=acceptance_contract if isinstance(acceptance_contract, TrustedAcceptanceContract) else (
                TrustedAcceptanceContract.from_dict(acceptance_contract) if acceptance_contract else None
            ),
        )
        if active_contract is not None:
            active_reproduce_command = active_contract.condition
        else:
            active_reproduce_command = reproduce_command
        # Validate reproduction command target existence
        # If reproduce command points to a specific test file, verify it exists on baseline

        for p in base_tmp.rglob("*.py"):
            rel = p.relative_to(base_tmp).as_posix()
            if is_collected_test_path(rel):
                try:
                    base_test_files[rel] = p.read_text(encoding="utf-8-sig")
                except OSError:
                    pass
        baseline_record = execute_commit_in_sandbox(
            base_tmp,
            sha=base_sha,
            tree_sha=base_tree,
            reproduce_command=active_reproduce_command,
            gates=gates,
            environment_digest=env_digest,
            sandbox_factory=sandbox_factory,
            sandbox_driver=sandbox_driver,
            customer_code_mode=customer_code_mode,
            docker_image=docker_image,
        )
    finally:
        cleanup_commit_worktree(repo_path, base_tmp)

    # Step 2: Candidate sandbox execution (completely separate, fresh sandbox instance!)
    cand_tmp = Path(tempfile.mkdtemp(prefix="aer-accept-cand-"))
    try:
        checkout_commit_tree(repo_path, cand_sha, cand_tmp)

        for p in cand_tmp.rglob("*.py"):
            rel = p.relative_to(cand_tmp).as_posix()
            if is_collected_test_path(rel):
                try:
                    cand_test_files[rel] = p.read_text(encoding="utf-8-sig")
                except OSError:
                    pass
        for p in cand_tmp.rglob("*"):
            if p.is_file():
                rel = p.relative_to(cand_tmp).as_posix()
                if is_non_python_test_path(rel):
                    unsupported_test_files.append(rel)
        candidate_record = execute_commit_in_sandbox(
            cand_tmp,
            sha=cand_sha,
            tree_sha=cand_tree,
            reproduce_command=active_reproduce_command,
            gates=gates,
            environment_digest=env_digest,
            sandbox_factory=sandbox_factory,
            sandbox_driver=sandbox_driver,
            customer_code_mode=customer_code_mode,
            docker_image=docker_image,
        )
    finally:
        cleanup_commit_worktree(repo_path, cand_tmp)

    # Step 3: Test Integrity & Anti-Tautology Scan (Task E3)
    integrity_report = analyze_test_diff_integrity(base_test_files, cand_test_files)
    for path, code in cand_test_files.items():
        if path not in base_test_files:
            sub = analyze_added_test(code, location=path)
            integrity_report.findings.extend(sub.findings)
            if sub.status != "PASS":
                if sub.status == "DENY" or integrity_report.status != "DENY":
                    integrity_report.status = sub.status

    # P0-9: Explicit Phase-1 Language Coverage:
    # Non-Python test files cannot be analyzed by AST and must not silently produce PASS
    if unsupported_test_files and not cand_test_files:
        for unsupp_path in sorted(unsupported_test_files):
            integrity_report.add(
                "NON_PYTHON_TEST_INTEGRITY",
                unsupp_path,
                f"test file '{unsupp_path}' is in a non-Python language unsupported for AST integrity in Phase 1",
                severity="UNSUPPORTED",
            )

    # Step 4: Synthesis & Evidence Binding
    wall_end_dt = datetime.now(timezone.utc)
    wall_end_iso = wall_end_dt.isoformat().replace("+00:00", "Z")
    wall_duration_ms = (time.perf_counter() - wall_t0) * 1000.0

    report = evaluate_change_acceptance(
        baseline_record,
        candidate_record,
        repository=repo_name,
        timestamp=wall_start_iso,
        integrity_report=integrity_report,
        customer_code_mode=customer_code_mode,
        acceptance_contract=active_contract,
    )
    report.execution_metrics["verificationStartedAt"] = wall_start_iso
    report.execution_metrics["verificationEndedAt"] = wall_end_iso
    report.execution_metrics["verificationLatencyMs"] = wall_duration_ms
    return report
