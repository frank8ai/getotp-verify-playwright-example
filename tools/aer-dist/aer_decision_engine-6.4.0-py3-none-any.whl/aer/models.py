"""Model routing and resolution for AER development and repair."""

from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Mapping

# Exact, verified catalog slugs available on the host workstation
DEFAULT_FAST_MODEL = "gemini-3.8-flash"
DEFAULT_REASONING_MODEL = "deepseek-v4.1-flash"


@dataclass
class ResolvedModel:
    slug: str
    tier: int
    role: str
    available: bool = True

    def to_dict(self) -> dict:
        return {
            "slug": self.slug,
            "tier": self.tier,
            "role": self.role,
            "available": self.available,
        }


def resolve_steward_model(attempt: int, catalog: Mapping[str, object] | None = None) -> ResolvedModel:
    """Resolve model slug for a given auto-fix attempt.
    
    Attempt 1: gemini-3.8-flash (fast syntax/test patch)
    Attempt 2: gemini-3.8-flash (reflective patch with previous failure context)
    Attempt 3: deepseek-v4.1-flash (divergent reasoning)
    """
    if attempt >= 3:
        slug = DEFAULT_REASONING_MODEL
        tier = 3
        role = "divergent-reasoning"
    elif attempt == 2:
        slug = DEFAULT_FAST_MODEL
        tier = 2
        role = "reflective-repair"
    else:
        slug = DEFAULT_FAST_MODEL
        tier = 1
        role = "fast-repair"

    # Optional local catalog verification
    available = True
    if catalog is not None and "models" in catalog:
        models = catalog.get("models") or []
        known_slugs = {
            m.get("slug") or m.get("id") or m.get("model")
            for m in models
            if isinstance(m, dict)
        }
        if known_slugs and slug not in known_slugs:
            available = False

    return ResolvedModel(slug=slug, tier=tier, role=role, available=available)
