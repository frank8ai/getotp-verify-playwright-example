"""Deterministic finding-to-diff positioning.

A model may describe a defect but must never supply a trusted line number.
This module parses the unified diff, extracts the added lines, and maps a
finding onto them. When a finding cannot be aligned it is marked
``position=unresolved`` with no line number; inventing a plausible line is the
failure mode this component exists to prevent.
"""

from __future__ import annotations

import re
from dataclasses import dataclass

_HUNK_HEADER = re.compile(
    r"^@@ -(?P<old_start>\d+)(?:,(?P<old_count>\d+))? "
    r"\+(?P<new_start>\d+)(?:,(?P<new_count>\d+))? @@"
)


class LocatorError(RuntimeError):
    """Raised when a diff cannot be parsed."""


@dataclass(frozen=True)
class AddedLine:
    """One added line in the new file."""

    number: int
    text: str


@dataclass(frozen=True)
class LocatedFinding:
    """A finding with verified positioning."""

    position: str  # "resolved" or "unresolved"
    start_line: int = 0
    end_line: int = 0
    reason: str = ""

    def to_dict(self) -> dict:
        payload: dict[str, object] = {"position": self.position}
        if self.position == "resolved":
            payload["start_line"] = self.start_line
            payload["end_line"] = self.end_line
        else:
            # 0/0 matches the "positioning failed" convention already used by
            # the external review tooling this engine interoperates with.
            payload["start_line"] = 0
            payload["end_line"] = 0
            payload["reason"] = self.reason
        return payload


def parse_added_lines(diff: str) -> list[AddedLine]:
    """Extract the added lines of a unified diff with their new-file numbers."""

    added: list[AddedLine] = []
    new_line = 0
    in_hunk = False

    for raw in diff.splitlines():
        header = _HUNK_HEADER.match(raw)
        if header:
            new_line = int(header.group("new_start"))
            in_hunk = True
            continue
        if not in_hunk:
            continue
        if raw.startswith("+++") or raw.startswith("---"):
            continue
        if raw.startswith("+"):
            added.append(AddedLine(number=new_line, text=raw[1:]))
            new_line += 1
        elif raw.startswith("-"):
            # Deleted lines do not advance the new-file counter.
            continue
        elif raw.startswith("\\"):
            # "\ No newline at end of file" is metadata, not content.
            continue
        else:
            new_line += 1

    return added


def locate_finding(
    diff: str,
    *,
    evidence: str = "",
    start_line: int = 0,
    end_line: int = 0,
) -> LocatedFinding:
    """Align a finding to real added lines.

    ``evidence`` is the code snippet the finding refers to. It is matched
    against added lines first; a supplied line number is trusted only when it
    lands on an actually-added line.
    """

    added = parse_added_lines(diff)
    if not added:
        return LocatedFinding(
            position="unresolved",
            reason="diff contains no added lines",
        )

    added_numbers = {line.number for line in added}

    if start_line and start_line in added_numbers:
        resolved_end = end_line if end_line in added_numbers else start_line
        if resolved_end < start_line:
            resolved_end = start_line
        return LocatedFinding(
            position="resolved",
            start_line=start_line,
            end_line=resolved_end,
        )

    needle = (evidence or "").strip()
    if needle:
        needle_lines = [line.strip() for line in needle.splitlines() if line.strip()]
        if needle_lines:
            first = needle_lines[0]
            candidates = [
                line for line in added if first and first in line.text.strip()
            ]
            if not candidates:
                trimmed = first.rstrip("\"\'`;,) .\u2026").strip()
                if trimmed and len(trimmed) >= 4:
                    candidates = [
                        line for line in added if trimmed in line.text.strip()
                    ]
            if not candidates and len(needle_lines) > 1:
                # Fall back to the first distinctive line when the snippet's
                # opening line was reformatted.
                for candidate_text in needle_lines[1:]:
                    candidates = [
                        line
                        for line in added
                        if candidate_text in line.text.strip()
                    ]
                    if not candidates:
                        trimmed_c = candidate_text.rstrip("\"\'`;,) .\u2026").strip()
                        if trimmed_c and len(trimmed_c) >= 4:
                            candidates = [
                                line for line in added if trimmed_c in line.text.strip()
                            ]
                    if candidates:
                        break
            if candidates:
                matched_numbers = [line.number for line in candidates]
                resolved_start = min(matched_numbers)
                resolved_end = max(matched_numbers)
                if end_line and resolved_end > end_line:
                    resolved_end = end_line
                return LocatedFinding(
                    position="resolved",
                    start_line=resolved_start,
                    end_line=max(resolved_end, resolved_start),
                )

    return LocatedFinding(
        position="unresolved",
        reason="finding could not be aligned to an added line",
    )
