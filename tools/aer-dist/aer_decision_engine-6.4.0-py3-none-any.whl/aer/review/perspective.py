"""Markdown formatter for CodeRabbit-grade PR perspective reports and comments.

Transforms ReviewRun and Finding data into structured, high-density, low-friction
Markdown reports suitable for GitHub PR top-level comments and line-level reviews.
"""

from __future__ import annotations

import html
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Sequence

from .engine import Finding, ReviewRun

PERSPECTIVE_ANCHOR = "<!-- aer-review-perspective -->"

_CATEGORY_LABELS = {
    "bug": "🐞 Bug",
    "security": "🛡️ Security",
    "performance": "⚡ Performance",
    "maintainability": "🧹 Maintainability",
    "test": "🧪 Test",
    "style": "🎨 Style",
    "documentation": "📝 Documentation",
    "other": "💡 Other",
}

_SEVERITY_BADGES = {
    "critical": "🚨 `CRITICAL`",
    "high": "🔴 `HIGH`",
    "medium": "🟡 `MEDIUM`",
    "low": "🟢 `LOW`",
}


@dataclass
class PerspectiveReport:
    summary_text: str
    walkthrough_by_module: dict[str, list[dict]]
    findings: list[Finding]
    coverage_rate: float
    reviewed_count: int
    skipped_count: int
    blocking_count: int
    decision: str
    anchor: str = PERSPECTIVE_ANCHOR

    def to_markdown(self) -> str:
        """Render the complete top-level PR perspective report in GitHub Flavored Markdown."""
        lines: list[str] = [self.anchor, ""]

        # 1. Header & Decision Banner
        decision_emoji = "✅" if self.decision == "PASS" else "❌" if self.decision == "CHANGES_REQUESTED" else "⚠️"
        lines.append(f"## {decision_emoji} AER Code Review Perspective")
        lines.append("")

        # 2. Executive Summary
        lines.append("### 📋 Executive Summary")
        lines.append(self.summary_text.strip() or "Review completed across affected changes.")
        lines.append("")

        # 3. Gate & Metrics Dashboard
        lines.append("### 📊 Gate & Coverage Status")
        cov_pct = round(self.coverage_rate * 100, 1)
        lines.append(
            f"- **Decision**: `{self.decision}` | **Coverage**: `{cov_pct}%` "
            f"({self.reviewed_count} reviewed, {self.skipped_count} skipped)"
        )
        lines.append(
            f"- **Findings**: `{len(self.findings)} total` | **Blocking**: `{self.blocking_count}`"
        )
        lines.append("")

        # 4. Collapsible Walkthrough by Module
        if self.walkthrough_by_module:
            lines.append("### 🔍 Changes Walkthrough")
            for module_name, files in sorted(self.walkthrough_by_module.items()):
                file_count = len(files)
                lines.append(f"<details><summary>📁 <b>{module_name}</b> ({file_count} file{'s' if file_count > 1 else ''})</summary>")
                lines.append("")
                lines.append("| File | Status | Changes | Summary / Impact |")
                lines.append("|---|---|---|---|")
                for item in files:
                    p = item.get("path", "")
                    st = item.get("status", "modified")
                    diff_stats = f"+{item.get('additions', 0)} / -{item.get('deletions', 0)}"
                    desc = item.get("description", "").replace("|", "\\|")
                    lines.append(f"| `{p}` | `{st}` | {diff_stats} | {desc} |")
                lines.append("")
                lines.append("</details>")
                lines.append("")

        # 5. Key Review Findings & Interactive Checklist
        if self.findings:
            lines.append("### 💡 Actionable Findings & Checklist")
            lines.append("> Check the box `[x]` to mark an item as handled, or reply `@aer-bot fix <finding-idx>`.")
            lines.append("")
            for idx, finding in enumerate(self.findings, 1):
                cat_label = _CATEGORY_LABELS.get(finding.category, finding.category)
                sev_badge = _SEVERITY_BADGES.get(finding.severity, f"`{finding.severity.upper()}`")
                loc_str = f"`{finding.path}:{finding.start_line}`" if finding.position == "resolved" else f"`{finding.path}`"
                
                lines.append(f"- [ ] **#{idx}** {sev_badge} {cat_label} at {loc_str}")
                lines.append(f"  - **Issue**: {finding.content}")
                if finding.evidence:
                    lines.append(f"  - **Evidence**: `{finding.evidence.strip()}`")
                if finding.suggestion_code:
                    lines.append(f"  - **Suggestion**:")
                    lines.append(f"    ```suggestion")
                    for s_line in finding.suggestion_code.splitlines():
                        lines.append(f"    {s_line}")
                    lines.append(f"    ```")
                lines.append("")
        else:
            lines.append("### ✨ Clean Review")
            lines.append("No defects, security alerts, or anti-patterns detected in reviewed lines.")
            lines.append("")

        # 6. Interaction Controls Footer
        lines.append("---")
        lines.append(
            "<sub>💡 <b>AER Interactive Commands</b>: Reply `@aer-bot review` to re-analyze, "
            "`@aer-bot fix` to trigger autonomous patch & test, or `@aer-bot explain <symbol>` for deep analysis.</sub>"
        )
        return "\n".join(lines).strip() + "\n"

    def to_dict(self) -> dict:
        return {
            "summaryText": self.summary_text,
            "decision": self.decision,
            "coverageRate": round(self.coverage_rate, 4),
            "reviewedCount": self.reviewed_count,
            "skippedCount": self.skipped_count,
            "blockingCount": self.blocking_count,
            "walkthroughByModule": self.walkthrough_by_module,
            "findings": [
                {
                    **f.to_dict(),
                    "inlineComment": render_inline_comment(f),
                }
                for f in self.findings
            ],
            "markdown": self.to_markdown(),
        }


def render_inline_comment(finding: Finding) -> str:
    """Render a single finding as a GitHub inline review comment with suggestion block."""
    lines: list[str] = []
    cat_label = _CATEGORY_LABELS.get(finding.category, finding.category)
    sev_badge = _SEVERITY_BADGES.get(finding.severity, f"`{finding.severity.upper()}`")
    lines.append(f"{sev_badge} **AER Review** ({cat_label})")
    lines.append("")
    lines.append(finding.content)
    lines.append("")
    if finding.evidence:
        lines.append(f"> **Evidence**: `{finding.evidence.strip()}`")
        lines.append("")
    if finding.suggestion_code:
        lines.append("```suggestion")
        lines.append(finding.suggestion_code.rstrip())
        lines.append("```")
        lines.append("")
    lines.append("<sub>Reply `@aer-bot fix` to automatically verify and apply this suggestion.</sub>")
    return "\n".join(lines).strip()


def build_perspective_report(run: ReviewRun, summary_text: str = "") -> PerspectiveReport:
    """Build a PerspectiveReport from a completed ReviewRun."""
    # Module grouping logic: group files by top-level or second-level directory
    modules: dict[str, list[dict]] = {}
    for f in run.selection.files:
        p = Path(f.path)
        parts = p.parts
        if len(parts) > 1:
            mod_key = f"{parts[0]}/{parts[1]}" if len(parts) > 2 else parts[0]
        else:
            mod_key = "root"
        
        # Look for findings in this file to synthesize description
        file_findings = [find for find in run.findings if find.path == f.path]
        if file_findings:
            desc = f"{len(file_findings)} finding(s) flagged"
        else:
            desc = "Clean / no issues"

        modules.setdefault(mod_key, []).append({
            "path": f.path,
            "status": f.status,
            "additions": f.additions,
            "deletions": f.deletions,
            "description": desc,
        })

    decision = "PASS"
    if run.blocking_findings:
        decision = "CHANGES_REQUESTED"
    elif run.coverage_rate < 1.0 and run.skipped_count > 0 and run.reviewed_count == 0 and len(run.coverage) > 0:
        decision = "NEED_USER_ACTION"

    if not summary_text:
        total_files = len(run.selection.files)
        total_findings = len(run.findings)
        if total_findings == 0:
            summary_text = f"Reviewed {total_files} file(s) across the changes. All checks passed cleanly with no actionable findings."
        else:
            summary_text = (
                f"Reviewed {total_files} file(s) across the changes. Flagged {total_findings} finding(s) "
                f"({len(run.blocking_findings)} blocking) requiring attention."
            )

    return PerspectiveReport(
        summary_text=summary_text,
        walkthrough_by_module=modules,
        findings=run.findings,
        coverage_rate=run.coverage_rate,
        reviewed_count=run.reviewed_count,
        skipped_count=run.skipped_count,
        blocking_count=len(run.blocking_findings),
        decision=decision,
    )
