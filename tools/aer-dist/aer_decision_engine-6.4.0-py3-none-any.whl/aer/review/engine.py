"""AER review engine: deterministic analysis plus optional host-agent review.

Two modes share one output shape:

* ``analyze`` runs deterministic detectors over the added lines. It makes no
  model call, so it is safe in CI and reproducible.
* ``adjudicate`` adds host-agent findings on top. The host agent (Codex)
  supplies analysis; it never supplies a trusted line number, which the locator
  verifies against the diff.

Every candidate finding passes an adversarial reflection pass before it is
reported. The pass demands concrete evidence from the diff and records its
verdict, so an unsupported claim is dropped rather than forwarded as a review
comment.
"""

from __future__ import annotations

import fnmatch
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable, Iterable

from .context import ContextSlice, build_context_slice
from .locator import locate_finding, parse_added_lines
from .rules import RuleResolution, is_sensitive_path, resolve_rules
from .selector import ReviewSelection, SelectedFile, select_review_files

REVIEW_FINDING_SCHEMA_VERSION = "review-finding/v1"

SEVERITIES = ("critical", "high", "medium", "low")
CATEGORIES = (
    "bug",
    "security",
    "performance",
    "maintainability",
    "test",
    "style",
    "documentation",
    "other",
)

_SEVERITY_RANK = {name: index for index, name in enumerate(SEVERITIES)}


class ReviewEngineError(RuntimeError):
    """Raised when the review engine cannot complete."""


@dataclass
class Finding:
    path: str
    content: str
    severity: str
    category: str
    evidence: str = ""
    suggestion_code: str = ""
    detector: str = ""
    sensitive: bool = False
    position: str = "unresolved"
    start_line: int = 0
    end_line: int = 0
    position_reason: str = ""
    challenge_verdict: str = ""
    challenge_reason: str = ""

    def __post_init__(self) -> None:
        if self.severity not in SEVERITIES:
            raise ReviewEngineError(f"unsupported severity: {self.severity}")
        if self.category not in CATEGORIES:
            raise ReviewEngineError(f"unsupported category: {self.category}")

    @property
    def severity_rank(self) -> int:
        return _SEVERITY_RANK[self.severity]

    def to_dict(self) -> dict:
        return {
            "schemaVersion": REVIEW_FINDING_SCHEMA_VERSION,
            "path": self.path,
            "content": self.content,
            "severity": self.severity,
            "category": self.category,
            "position": self.position,
            "start_line": self.start_line,
            "end_line": self.end_line,
            "position_reason": self.position_reason,
            "evidence": self.evidence,
            "suggestion_code": self.suggestion_code,
            "detector": self.detector,
            "sensitive": self.sensitive,
            "challenge": {
                "verdict": self.challenge_verdict,
                "reason": self.challenge_reason,
            },
        }


@dataclass
class CoverageEntry:
    path: str
    status: str  # "reviewed" or "skipped"
    reason: str = ""

    def to_dict(self) -> dict:
        payload = {"path": self.path, "status": self.status}
        if self.status == "skipped":
            payload["reason"] = self.reason
        return payload


@dataclass
class ReviewRun:
    mode: str
    selection: ReviewSelection
    findings: list[Finding] = field(default_factory=list)
    coverage: list[CoverageEntry] = field(default_factory=list)
    context: ContextSlice | None = None
    rules: list[RuleResolution] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
    adapter_fallback: str = ""
    schema_version: str = "review-run/v1"

    @property
    def reviewed_count(self) -> int:
        return sum(1 for c in self.coverage if c.status == "reviewed")

    @property
    def skipped_count(self) -> int:
        return sum(1 for c in self.coverage if c.status == "skipped")

    @property
    def coverage_rate(self) -> float:
        total = len(self.coverage)
        if total == 0:
            return 1.0
        return self.reviewed_count / total

    @property
    def blocking_findings(self) -> list[Finding]:
        return [
            f
            for f in self.findings
            if f.severity in ("critical", "high")
            and f.challenge_verdict == "supported"
        ]

    def to_dict(self) -> dict:
        return {
            "schemaVersion": self.schema_version,
            "mode": self.mode,
            "selection": self.selection.to_dict(),
            "findings": [f.to_dict() for f in self.findings],
            "coverage": [c.to_dict() for c in self.coverage],
            "coverage_rate": round(self.coverage_rate, 4),
            "totals": {
                "selected": len(self.selection.files),
                "reviewed": self.reviewed_count,
                "skipped": self.skipped_count,
                "findings": len(self.findings),
                "blocking": len(self.blocking_findings),
            },
            "budget": self._budget_dict(),
            "warnings": list(self.warnings),
            "adapterFallback": self.adapter_fallback,
        }

    def _budget_dict(self) -> dict:
        if self.context is None:
            return {}
        return {
            "contextChars": self.context.char_count,
            "contextCharBudget": self.context.char_budget,
            "contextTruncated": self.context.truncated,
        }


@dataclass
class _AddedLineView:
    number: int
    text: str


def _added_lines(diff: str) -> list[_AddedLineView]:
    return [
        _AddedLineView(number=line.number, text=line.text)
        for line in parse_added_lines(diff)
    ]


# --------------------------------------------------------------------------
# Deterministic detectors
# --------------------------------------------------------------------------

_SECRET_PATTERNS: tuple[tuple[str, re.Pattern[str]], ...] = (
    ("openai-style key", re.compile(r"\bsk-[A-Za-z0-9_\-]{16,}\b")),
    ("github token", re.compile(r"\bgh[pousr]_[A-Za-z0-9]{20,}\b")),
    ("aws access key", re.compile(r"\bAKIA[0-9A-Z]{16}\b")),
    ("authorization header", re.compile(r"(?i)\bauthorization\b\s*[:=]\s*['\"]?bearer\s+\S+")),
    ("private key block", re.compile(r"-----BEGIN [A-Z ]*PRIVATE KEY-----")),
    ("generic assigned secret", re.compile(
        r"(?i)\b(?:api[_-]?key|secret|password|passwd|token)\b\s*[:=]\s*"
        r"['\"][^'\"\s]{8,}['\"]"
    )),
)

# Values that look like placeholders are not secrets.
_PLACEHOLDER = re.compile(
    r"(?i)(redacted|placeholder|example|dummy|changeme|your[_-]?|xxx+|<[^>]+>|\$\{|\$env)"
)


def _detect_secrets(file: SelectedFile, lines: list[_AddedLineView]) -> list[Finding]:
    findings: list[Finding] = []
    for line in lines:
        for label, pattern in _SECRET_PATTERNS:
            if not pattern.search(line.text):
                continue
            if _PLACEHOLDER.search(line.text):
                continue
            findings.append(
                Finding(
                    path=file.path,
                    content=(
                        f"Possible committed secret ({label}) on an added line. "
                        "Secrets, tokens, and Authorization headers must never be "
                        "committed; use a redacted placeholder or environment reference."
                    ),
                    severity="critical",
                    category="security",
                    evidence=line.text.strip(),
                    detector="secret-scan",
                    sensitive=True,
                )
            )
            break
    return findings


_PS_RECURSIVE_DELETE = re.compile(
    r"(?i)\bRemove-Item\b[^\n]*-(Recurse|Force)\b[^\n]*"
    r"(\$[A-Za-z_]|Join-Path|\[IO\.Path\]|\$env:)"
)
_PS_MIXED_SHELL = re.compile(r"(?i)\b(cmd(\.exe)?\s+/c|Start-Process\s+cmd|bash\s+-c|sh\s+-c)\b")


def _detect_powershell_destructive(
    file: SelectedFile, lines: list[_AddedLineView]
) -> list[Finding]:
    findings: list[Finding] = []
    if not file.path.lower().endswith(".ps1"):
        return findings

    for line in lines:
        text = line.text
        if not text.strip() or text.lstrip().startswith("#"):
            continue
        if _PS_RECURSIVE_DELETE.search(text):
            findings.append(
                Finding(
                    path=file.path,
                    content=(
                        "Recursive delete or forced removal of a runtime-derived "
                        "path. Resolve the absolute target with -LiteralPath and "
                        "verify it stays inside the intended directory before "
                        "removing anything."
                    ),
                    severity="high",
                    category="bug",
                    evidence=text.strip(),
                    detector="powershell-destructive",
                )
            )
        if _PS_MIXED_SHELL.search(text) and re.search(
            r"(?i)(del|erase|rmdir|Remove-Item|Move-Item)", text
        ):
            findings.append(
                Finding(
                    path=file.path,
                    content=(
                        "Directory delete or move is composed across shells. Use "
                        "one shell end to end, preferably native PowerShell "
                        "cmdlets with -LiteralPath, so the resolved target cannot "
                        "be reinterpreted by a second shell."
                    ),
                    severity="high",
                    category="security",
                    evidence=text.strip(),
                    detector="powershell-mixed-shell",
                )
            )
    return findings


_UNPINNED_VERSION = re.compile(
    r"@fission-ai/openspec\s*[\"']?\s*:\s*[\"'](\^|~|latest)"
)


def _detect_openspec_drift(
    file: SelectedFile, lines: list[_AddedLineView]
) -> list[Finding]:
    findings: list[Finding] = []
    normalized = file.path.replace("\\", "/")
    if "openspec" not in normalized.lower() and not normalized.endswith("package.json"):
        return findings
    for line in lines:
        match = _UNPINNED_VERSION.search(line.text)
        if not match:
            continue
        findings.append(
            Finding(
                path=file.path,
                content=(
                    "OpenSpec dependency is not pinned to an exact released "
                    "version. The repository policy rejects latest, caret, and "
                    "tilde ranges; pin the exact version in both package files."
                ),
                severity="high",
                category="maintainability",
                evidence=line.text.strip(),
                detector="openspec-pin",
            )
        )
    return findings


_ASSERTION_SIGNAL = re.compile(
    r"(?i)(\bassert\b|self\.assert|pytest\.raises|with\s+raises|\.should|expect\(|"
    r"raise\s+|\.toEqual|\.toBe|assertEqual|assertTrue|assertIn|assertRaises)"
)
_TEST_DEF = re.compile(r"(?m)^\s*(?:async\s+)?def\s+(test_[A-Za-z0-9_]*)|^\s*it\s*\(|^\s*test\s*\(")


def _detect_assertion_free_tests(
    file: SelectedFile, diff: str, lines: list[_AddedLineView]
) -> list[Finding]:
    findings: list[Finding] = []
    normalized = file.path.replace("\\", "/")
    is_test_file = (
        "/tests/" in f"/{normalized}"
        or normalized.startswith("tests/")
        or Path(normalized).name.startswith("test_")
        or ".test." in normalized
        or ".spec." in normalized
    )
    if not is_test_file:
        return findings

    # Only added test functions count; editing an existing test is covered by
    # the anti-tautology guard instead.
    added_test_defs = [line for line in lines if _TEST_DEF.match(line.text)]
    if not added_test_defs:
        return findings

    body = "\n".join(line.text for line in lines)
    if _ASSERTION_SIGNAL.search(body):
        return findings

    first = added_test_defs[0]
    findings.append(
        Finding(
            path=file.path,
            content=(
                "Added test function contains no assertion or failure signal, so "
                "it cannot fail on the base revision and provides no regression "
                "protection."
            ),
            severity="high",
            category="test",
            evidence=first.text.strip(),
            detector="assertion-free-test",
        )
    )
    return findings


_DETECTORS: tuple[tuple[str, Callable[[SelectedFile, str, list[_AddedLineView]], list[Finding]]], ...] = (
    ("secret-scan", lambda f, _d, lines: _detect_secrets(f, lines)),
    ("powershell-destructive", lambda f, _d, lines: _detect_powershell_destructive(f, lines)),
    ("openspec-pin", lambda f, _d, lines: _detect_openspec_drift(f, lines)),
    ("assertion-free-test", _detect_assertion_free_tests),
)


# --------------------------------------------------------------------------
# Adversarial reflection
# --------------------------------------------------------------------------


def _line_is_added(diff: str, evidence: str) -> bool:
    needle = evidence.strip()
    if not needle:
        return False
    added = parse_added_lines(diff)
    return any(needle in line.text.strip() for line in added)


def reflect_finding(finding: Finding, diff: str) -> Finding:
    """Challenge a candidate finding and record the verdict.

    A finding is ``supported`` only when its evidence is an actual added line.
    Findings whose evidence cannot be corroborated are downgraded one severity
    step, and findings with no evidence at all are dropped. A sensitive-path
    finding additionally requires evidence, because an unsupported claim about
    auth or payment code is worse than silence.
    """

    if not finding.evidence.strip():
        finding.challenge_verdict = "dropped"
        finding.challenge_reason = "no supporting evidence supplied"
        finding.severity = "low"
        return finding

    if _line_is_added(diff, finding.evidence):
        finding.challenge_verdict = "supported"
        finding.challenge_reason = "evidence matches an added line in the diff"
        return finding

    if finding.sensitive or is_sensitive_path(finding.path):
        finding.challenge_verdict = "dropped"
        finding.challenge_reason = (
            "sensitive-path finding requires evidence present in the diff"
        )
        finding.severity = "low"
        return finding

    downgraded = min(finding.severity_rank + 1, len(SEVERITIES) - 1)
    finding.severity = SEVERITIES[downgraded]
    finding.challenge_verdict = "downgraded"
    finding.challenge_reason = (
        "evidence could not be matched to an added line; severity reduced"
    )
    return finding


# --------------------------------------------------------------------------
# Engine entry points
# --------------------------------------------------------------------------


def _position_findings(findings: Iterable[Finding], file: SelectedFile) -> None:
    for finding in findings:
        located = locate_finding(
            file.diff,
            evidence=finding.evidence,
            start_line=finding.start_line,
            end_line=finding.end_line,
        )
        finding.position = located.position
        finding.start_line = located.start_line
        finding.end_line = located.end_line
        finding.position_reason = located.reason


def _build_coverage(
    selection: ReviewSelection,
    *,
    failures: dict[str, str],
) -> list[CoverageEntry]:
    coverage: list[CoverageEntry] = []
    for file in selection.files:
        if file.path in failures:
            coverage.append(
                CoverageEntry(file.path, "skipped", failures[file.path])
            )
        else:
            coverage.append(CoverageEntry(file.path, "reviewed"))
    # Excluded files are part of the coverage record so an exclusion is visible
    # rather than indistinguishable from a clean result.
    for excluded in selection.excluded:
        coverage.append(CoverageEntry(excluded.path, "skipped", excluded.reason))
    return coverage


def _resolve_file_rules(
    selection: ReviewSelection,
    *,
    explicit_rule: str,
) -> list[RuleResolution]:
    resolutions: list[RuleResolution] = []
    for file in selection.files:
        resolutions.append(
            resolve_rules(
                file.path,
                explicit_path=explicit_rule,
                repo_root=selection.repo_root,
            )
        )
    return resolutions


def analyze(
    *,
    repo: str = ".",
    mode: str = "workspace",
    from_ref: str = "",
    to_ref: str = "",
    commit: str = "",
    paths: list[str] | None = None,
    exclude: list[str] | None = None,
    rule_path: str = "",
    include_context: bool = True,
    char_budget: int = 120_000,
) -> ReviewRun:
    """Run deterministic analysis with no model call."""

    selection = select_review_files(
        repo=repo,
        mode=mode,
        from_ref=from_ref,
        to_ref=to_ref,
        commit=commit,
        paths=paths,
        exclude=exclude,
    )
    run = ReviewRun(mode=mode, selection=selection)
    run.rules = _resolve_file_rules(selection, explicit_rule=rule_path)

    failures: dict[str, str] = {}
    for file in selection.files:
        lines = _added_lines(file.diff)
        if not lines:
            failures[file.path] = "no added lines to analyze"
            continue
        try:
            for _name, detector in _DETECTORS:
                for finding in detector(file, file.diff, lines):
                    finding.sensitive = finding.sensitive or is_sensitive_path(
                        finding.path
                    )
                    finding = reflect_finding(finding, file.diff)
                    if finding.challenge_verdict == "dropped":
                        continue
                    _position_findings([finding], file)
                    run.findings.append(finding)
        except Exception as exc:  # pragma: no cover - defensive
            failures[file.path] = f"detector error: {exc}"

    run.coverage = _build_coverage(selection, failures=failures)

    if include_context:
        run.context = build_context_slice(
            selection.files,
            repo_root=selection.repo_root,
            char_budget=char_budget,
        )
        if run.context.truncated:
            run.warnings.append(
                "context slice truncated to the configured character budget"
            )

    if not selection.files:
        run.warnings.append("no files selected for review")

    run.findings.sort(
        key=lambda f: (f.severity_rank, f.path, f.start_line or 10**9)
    )
    return run


def adjudicate(
    *,
    agent_runner: Callable[[ContextSlice, SelectedFile], list[Finding]],
    repo: str = ".",
    mode: str = "workspace",
    from_ref: str = "",
    to_ref: str = "",
    commit: str = "",
    paths: list[str] | None = None,
    exclude: list[str] | None = None,
    rule_path: str = "",
    include_context: bool = True,
    char_budget: int = 120_000,
) -> ReviewRun:
    """Run deterministic analysis plus host-agent analysis.

    ``agent_runner`` is supplied by the caller and performs the model-backed
    review using the host subscription. Its findings pass through the same
    reflection and positioning checks as deterministic findings, so an agent
    claim carries no more positional authority than any other candidate.
    """

    run = analyze(
        repo=repo,
        mode=mode,
        from_ref=from_ref,
        to_ref=to_ref,
        commit=commit,
        paths=paths,
        exclude=exclude,
        rule_path=rule_path,
        include_context=include_context,
        char_budget=char_budget,
    )
    if run.context is None:
        run.context = build_context_slice(
            run.selection.files,
            repo_root=run.selection.repo_root,
            char_budget=char_budget,
        )

    failures = {
        entry.path: entry.reason
        for entry in run.coverage
        if entry.status == "skipped"
    }
    for file in run.selection.files:
        try:
            agent_findings = agent_runner(run.context, file) or []
        except Exception as exc:
            failures[file.path] = f"host agent error: {exc}"
            run.warnings.append(f"host agent failed for {file.path}: {exc}")
            continue
        for finding in agent_findings:
            finding.detector = finding.detector or "host-agent"
            finding.sensitive = finding.sensitive or is_sensitive_path(finding.path)
            finding = reflect_finding(finding, file.diff)
            if finding.challenge_verdict == "dropped":
                continue
            _position_findings([finding], file)
            run.findings.append(finding)

    run.coverage = _build_coverage(run.selection, failures=failures)
    run.findings.sort(
        key=lambda f: (f.severity_rank, f.path, f.start_line or 10**9)
    )
    return run


def render_evidence(run: ReviewRun, role: str = "scope-safety") -> dict:
    """Render a ``review-evidence/v1`` document from a review run.

    Existing required fields keep their current meaning. Engine detail is added
    only through the optional fields, so consumers that require only the
    original contract keep working.
    """

    decision = "PASS"
    required_actions: list[str] = []
    if run.blocking_findings:
        decision = "CHANGES_REQUESTED"
        required_actions = [
            f"{f.path}:{f.start_line or '?'} {f.content}"
            for f in run.blocking_findings
        ]
    if run.coverage_rate < 1.0 and run.skipped_count > 0:
        # A skipped file is not automatically a failure, but a review that
        # skipped everything cannot claim PASS.
        if run.reviewed_count == 0 and len(run.coverage) > 0:
            decision = "NEED_USER_ACTION"
            required_actions.append("no file was reviewed; scope the review explicitly")

    highest = "low"
    for finding in run.findings:
        if finding.severity == "critical":
            highest = "high"
            break
        if finding.severity == "high":
            highest = "high"
        elif finding.severity == "medium" and highest == "low":
            highest = "medium"

    tested_commands = [
        f"aer review analyze ({run.mode}, {len(run.selection.files)} files)"
    ]

    return {
        "schemaVersion": "review-evidence/v1",
        "role": role,
        "decision": decision,
        "risk": highest,
        "findings": [
            f"{f.path}:{f.start_line or '?'} [{f.severity}/{f.category}] {f.content}"
            for f in run.findings
        ],
        "required_actions": required_actions,
        "tested_commands": tested_commands,
        "changed_paths": run.selection.selected_paths,
        "forbidden_claims_detected": [],
        # Optional engine detail: consumers that predate the engine ignore it.
        "findings_detail": [f.to_dict() for f in run.findings],
        "coverage": {
            "rate": round(run.coverage_rate, 4),
            "reviewed": run.reviewed_count,
            "skipped": run.skipped_count,
            "entries": [c.to_dict() for c in run.coverage],
        },
        "budget": run._budget_dict(),
        "challenge": {
            "supported": sum(
                1 for f in run.findings if f.challenge_verdict == "supported"
            ),
            "downgraded": sum(
                1 for f in run.findings if f.challenge_verdict == "downgraded"
            ),
            "dropped": sum(
                1 for f in run.findings if f.challenge_verdict == "dropped"
            ),
        },
    }
