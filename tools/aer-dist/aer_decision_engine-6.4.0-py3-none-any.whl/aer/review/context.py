"""Per-invocation context trimming for review.

Review prompts fail when they carry an entire repository, and they mislead when
they carry only a diff. This module builds the small slice that matters: the
changed files, the symbols they touch, and a bounded set of same-repository
references to those symbols.

There is no persistent index, database, or background service. Every slice is
derived from the working tree on demand and discarded afterwards.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path

from .selector import SelectedFile

# Rough character budget for the context slice. Kept conservative because the
# host agent's own instructions and tool output also consume context.
DEFAULT_CONTEXT_CHAR_BUDGET = 120_000
DEFAULT_REFERENCE_LIMIT = 5

_DEFINITION_PATTERNS: tuple[re.Pattern[str], ...] = (
    re.compile(r"^\s*(?:async\s+)?def\s+([A-Za-z_][A-Za-z0-9_]*)"),
    re.compile(r"^\s*class\s+([A-Za-z_][A-Za-z0-9_]*)"),
    re.compile(r"^\s*func\s+([A-Za-z_][A-Za-z0-9_]*)"),
    re.compile(r"^\s*function\s+([A-Za-z_][A-Za-z0-9_]*)"),
    re.compile(
        r"^\s*(?:export\s+)?(?:const|let|var)\s+([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(?:async\s*)?\("
    ),
)

_SEARCH_SUFFIXES = (".py", ".ps1", ".js", ".ts", ".tsx", ".jsx", ".go", ".rs", ".md")
_SKIP_DIRS = {
    ".git",
    "node_modules",
    "__pycache__",
    ".pytest_cache",
    ".venv",
    "venv",
    "dist",
    "build",
}


@dataclass
class ContextSlice:
    """Bounded review context derived from the current working tree."""

    changed_paths: list[str] = field(default_factory=list)
    symbols: list[str] = field(default_factory=list)
    references: dict[str, list[str]] = field(default_factory=dict)
    rendered: str = ""
    truncated: bool = False
    char_budget: int = DEFAULT_CONTEXT_CHAR_BUDGET
    schema_version: str = "review-context/v1"

    @property
    def char_count(self) -> int:
        return len(self.rendered)

    def to_dict(self) -> dict:
        return {
            "schemaVersion": self.schema_version,
            "changedPaths": list(self.changed_paths),
            "symbols": list(self.symbols),
            "references": {k: list(v) for k, v in self.references.items()},
            "truncated": self.truncated,
            "charBudget": self.char_budget,
            "charCount": self.char_count,
        }


def extract_symbols(diff: str) -> list[str]:
    """Collect definition names introduced or touched by a diff."""

    symbols: list[str] = []
    for raw in diff.splitlines():
        if not raw.startswith("+"):
            continue
        text = raw[1:]
        for pattern in _DEFINITION_PATTERNS:
            match = pattern.match(text)
            if match:
                name = match.group(1)
                if name not in symbols:
                    symbols.append(name)
                break
    return symbols


def _iter_repo_files(repo_root: Path) -> list[Path]:
    files: list[Path] = []
    for path in repo_root.rglob("*"):
        if not path.is_file():
            continue
        if any(part in _SKIP_DIRS for part in path.parts):
            continue
        if path.suffix not in _SEARCH_SUFFIXES:
            continue
        files.append(path)
    return files


def _find_references(
    repo_root: Path,
    symbol: str,
    *,
    limit: int,
    skip_paths: set[str],
    file_cache: list[tuple[str, list[str]]] | None = None,
) -> list[str]:
    """Find same-repository references to a symbol, capped at ``limit``."""

    pattern = re.compile(rf"\b{re.escape(symbol)}\b")
    hits: list[str] = []

    if file_cache is not None:
        source_items = file_cache
    else:
        raw_items: list[tuple[str, list[str]]] = []
        for path in _iter_repo_files(repo_root):
            try:
                relative = path.relative_to(repo_root).as_posix()
            except ValueError:
                continue
            if relative in skip_paths:
                continue
            try:
                text = path.read_text(encoding="utf-8-sig", errors="replace")
            except OSError:
                continue
            raw_items.append((relative, text.splitlines()))
        source_items = raw_items

    for relative, lines in source_items:
        if relative in skip_paths:
            continue
        for number, line in enumerate(lines, start=1):
            if pattern.search(line):
                hits.append(f"{relative}:{number}: {line.strip()[:160]}")
                break
        if len(hits) >= limit:
            break
    return hits


def build_context_slice(
    files: list[SelectedFile],
    *,
    repo_root: str | Path = ".",
    char_budget: int = DEFAULT_CONTEXT_CHAR_BUDGET,
    reference_limit: int = DEFAULT_REFERENCE_LIMIT,
    find_references: bool = True,
) -> ContextSlice:
    """Build a bounded context slice for the selected files."""

    root = Path(repo_root)
    changed_paths = [f.path for f in files]
    symbols: list[str] = []
    for file in files:
        for symbol in extract_symbols(file.diff):
            if symbol not in symbols:
                symbols.append(symbol)

    references: dict[str, list[str]] = {}
    if find_references:
        skip = set(changed_paths)
        file_cache: list[tuple[str, list[str]]] = []
        for path in _iter_repo_files(root):
            try:
                relative = path.relative_to(root).as_posix()
            except ValueError:
                continue
            if relative in skip:
                continue
            try:
                text = path.read_text(encoding="utf-8-sig", errors="replace")
            except OSError:
                continue
            file_cache.append((relative, text.splitlines()))

        for symbol in symbols:
            refs = _find_references(
                root,
                symbol,
                limit=reference_limit,
                skip_paths=skip,
                file_cache=file_cache,
            )
            if refs:
                references[symbol] = refs

    sections: list[str] = ["# Review Context", "", "## Changed Files", ""]
    for file in files:
        sections.append(f"- {file.path} ({file.status}, +{file.additions}/-{file.deletions})")

    if symbols:
        sections.extend(["", "## Touched Symbols", ""])
        sections.extend(f"- {symbol}" for symbol in symbols)

    if references:
        sections.extend(["", "## Same-Repository References", ""])
        for symbol, refs in references.items():
            sections.append(f"### {symbol}")
            sections.extend(f"- {ref}" for ref in refs)

    rendered = "\n".join(sections).rstrip() + "\n"
    truncated = False
    if len(rendered) > char_budget:
        # Truncation is recorded, never silent: a caller that sees
        # ``truncated`` must know the slice is incomplete.
        cutoff = max(char_budget - 1, 0)
        rendered = (rendered[:cutoff].rstrip() + "\n") if char_budget > 0 else ""
        truncated = True

    return ContextSlice(
        changed_paths=changed_paths,
        symbols=symbols,
        references=references,
        rendered=rendered,
        truncated=truncated,
        char_budget=char_budget,
    )
