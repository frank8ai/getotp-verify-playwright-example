"""AER native code review engine.

Deterministic engineering owns scope selection, rule resolution, positioning,
and coverage accounting. Model-backed analysis is opt-in and never supplies a
trusted line number.

See ``docs/review-engine.md`` and
``openspec/changes/2026-09-16-native-review-engine-v2`` for the contract.
"""

from .context import ContextSlice, build_context_slice
from .engine import (
    REVIEW_FINDING_SCHEMA_VERSION,
    ReviewEngineError,
    ReviewRun,
    analyze,
    adjudicate,
    render_evidence,
)
from .locator import LocatorError, locate_finding, parse_added_lines
from .perspective import (
    PERSPECTIVE_ANCHOR,
    PerspectiveReport,
    build_perspective_report,
    render_inline_comment,
)
from .rules import (
    BUILTIN_RULES,
    RuleMatch,
    RuleResolution,
    load_rules,
    resolve_rules,
)
from .selector import (
    REVIEW_MODES,
    ExcludedPath,
    ReviewSelection,
    SelectedFile,
    bundle_files,
    select_review_files,
)

__all__ = [
    "BUILTIN_RULES",
    "ContextSlice",
    "ExcludedPath",
    "LocatorError",
    "PERSPECTIVE_ANCHOR",
    "PerspectiveReport",
    "REVIEW_FINDING_SCHEMA_VERSION",
    "REVIEW_MODES",
    "ReviewEngineError",
    "ReviewRun",
    "ReviewSelection",
    "RuleMatch",
    "RuleResolution",
    "SelectedFile",
    "adjudicate",
    "analyze",
    "build_context_slice",
    "build_perspective_report",
    "bundle_files",
    "load_rules",
    "locate_finding",
    "parse_added_lines",
    "render_evidence",
    "render_inline_comment",
    "resolve_rules",
    "select_review_files",
]
