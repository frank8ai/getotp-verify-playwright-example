"""Deterministic review rule resolution.

Rules are matched to files by glob path. Resolution order is: an explicit rule
file supplied by the caller, then the repository rule file, then the built-in
defaults. A matching user rule replaces the built-in rule for that path unless
the entry sets ``merge_system_rule``, in which case both apply.

Rule text is data, not authority. It shapes what the host agent looks for; it
cannot grant permissions or relax a gate.
"""

from __future__ import annotations

import fnmatch
import json
from dataclasses import dataclass, field
from pathlib import Path

REPO_RULE_PATH = ".aer-review/rule.json"

# Built-in rules mirror the concerns in ``code_review.md``: secret and
# prompt-history safety, destructive script handling, workflow gate integrity,
# and specification governance.
BUILTIN_RULES: tuple[dict[str, object], ...] = (
    {
        "path": "**/*.ps1",
        "rule": (
            "PowerShell safety: verify literal paths and repository-root checks "
            "before any delete or move; never route file deletion through a "
            "second shell; never print secret values, tokens, or raw prompt "
            "content; keep output safe for CI logs."
        ),
    },
    {
        "path": ".github/workflows/**",
        "rule": (
            "Workflow integrity: reject changes that remove backup verification, "
            "secret scanning, or required-check enforcement; reject unknown "
            "action references that are not pinned."
        ),
    },
    {
        "path": "codex/config/**",
        "rule": (
            "Backup safety: raw credentials, tokens, cookies, Authorization "
            "headers, prompt history, and session state must never be committed. "
            "Redacted placeholders are acceptable; real values are not."
        ),
    },
    {
        "path": "tools/openspec/**",
        "rule": (
            "OpenSpec governance: the version must be exact and pinned in both "
            "package files; reject latest, caret, or tilde ranges."
        ),
    },
    {
        "path": "tests/**",
        "rule": (
            "Test integrity: reject tests that cannot fail. Added tests must "
            "contain a real assertion or a failure signal tied to the behavior "
            "under test."
        ),
    },
)

# Findings on these paths require evidence plus a counter-example check.
SENSITIVE_PATH_PATTERNS: tuple[str, ...] = (
    "**/auth/**",
    "**/payment/**",
    "**/billing/**",
    "**/ledger/**",
    "**/migrations/**",
    "**/secrets/**",
    "**/secret/**",
    "**/sessions/**",
    "codex/config/**",
    ".github/workflows/**",
)


class RuleError(RuntimeError):
    """Raised when a rule file cannot be read or parsed."""


@dataclass(frozen=True)
class RuleMatch:
    rule: str
    source: str
    pattern: str
    merge_system_rule: bool = False


@dataclass
class RuleResolution:
    rules: list[RuleMatch] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {
            "schemaVersion": "review-rules/v1",
            "rules": [
                {
                    "rule": r.rule,
                    "source": r.source,
                    "pattern": r.pattern,
                    "mergeSystemRule": r.merge_system_rule,
                }
                for r in self.rules
            ],
            "warnings": list(self.warnings),
        }


def _normalize_entries(payload: object, *, source: str) -> list[dict]:
    if isinstance(payload, dict):
        entries = payload.get("rules", [])
    else:
        entries = payload
    if not isinstance(entries, list):
        raise RuleError(f"{source}: expected a list of rule entries")
    normalized: list[dict] = []
    for entry in entries:
        if not isinstance(entry, dict):
            raise RuleError(f"{source}: rule entries must be objects")
        pattern = entry.get("path")
        rule = entry.get("rule")
        if not isinstance(pattern, str) or not pattern.strip():
            raise RuleError(f"{source}: rule entry is missing a path")
        if not isinstance(rule, str) or not rule.strip():
            raise RuleError(f"{source}: rule entry is missing rule text")
        normalized.append(
            {
                "path": pattern.strip(),
                "rule": rule.strip(),
                "merge_system_rule": bool(entry.get("merge_system_rule", False)),
            }
        )
    return normalized


def load_rules(path: str | Path) -> list[dict]:
    """Load and validate a rule file."""

    target = Path(path)
    if not target.is_file():
        raise RuleError(f"rule file not found: {target}")
    try:
        payload = json.loads(target.read_text(encoding="utf-8-sig"))
    except json.JSONDecodeError as exc:
        raise RuleError(f"invalid rule JSON in {target}: {exc}") from exc
    return _normalize_entries(payload, source=str(target))


def rule_matches_path(pattern: str, path: str) -> bool:
    normalized_path = path.replace("\\", "/")
    normalized_pattern = pattern.replace("\\", "/")
    if fnmatch.fnmatch(normalized_path, normalized_pattern):
        return True
    return fnmatch.fnmatch(normalized_path, f"**/{normalized_pattern}")


def is_sensitive_path(path: str) -> bool:
    normalized = path.replace("\\", "/")
    for pattern in SENSITIVE_PATH_PATTERNS:
        if fnmatch.fnmatch(normalized, pattern):
            return True
        if fnmatch.fnmatch(normalized, f"**/{pattern}"):
            return True
    lowered = normalized.lower()
    return any(
        token in lowered
        for token in ("auth", "payment", "billing", "ledger", "migration", "secret")
    )


def resolve_rules(
    path: str,
    *,
    explicit_path: str = "",
    repo_root: str | Path = ".",
    explicit_entries: list[dict] | None = None,
) -> RuleResolution:
    """Resolve the rules that apply to one path.

    An explicit rule file outranks the repository rule file, which outranks the
    built-in defaults. An explicit rule entry replaces the built-in rule for the
    same path unless it requests a merge.
    """

    resolution = RuleResolution()
    user_entries: list[dict] = []
    user_source = ""

    if explicit_entries is not None:
        user_entries = _normalize_entries(explicit_entries, source="explicit rules")
        user_source = "explicit"
    elif explicit_path:
        user_entries = load_rules(explicit_path)
        user_source = "explicit"
    else:
        repo_rule_file = Path(repo_root) / REPO_RULE_PATH
        if repo_rule_file.is_file():
            user_entries = load_rules(repo_rule_file)
            user_source = "repository"

    builtin_entries = _normalize_entries(list(BUILTIN_RULES), source="builtin")
    matched_user = [e for e in user_entries if rule_matches_path(e["path"], path)]
    matched_builtin = [e for e in builtin_entries if rule_matches_path(e["path"], path)]

    for entry in matched_user:
        resolution.rules.append(
            RuleMatch(
                rule=entry["rule"],
                source=user_source,
                pattern=entry["path"],
                merge_system_rule=bool(entry["merge_system_rule"]),
            )
        )

    # Built-in rules apply only when no user rule matched, unless a matching
    # user rule explicitly asked to keep the system rule.
    keep_system = not matched_user or any(e["merge_system_rule"] for e in matched_user)
    if keep_system:
        for entry in matched_builtin:
            resolution.rules.append(
                RuleMatch(
                    rule=entry["rule"],
                    source="builtin",
                    pattern=entry["path"],
                )
            )

    if not resolution.rules:
        resolution.warnings.append(f"no rule matched path: {path}")

    return resolution
