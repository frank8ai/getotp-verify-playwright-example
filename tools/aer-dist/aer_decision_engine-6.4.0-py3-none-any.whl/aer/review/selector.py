"""Deterministic review scope selection.

Scope selection decides which files a review covers and which are excluded.
It never calls a model: an unreviewed file is a coverage decision that must be
reproducible and auditable, not something an LLM should influence.

The component also bundles related files (for example a parser and its golden
fixture, or parallel translation files) into one review unit so a change that
only makes sense across files is not reviewed in isolation.
"""

from __future__ import annotations

import fnmatch
import subprocess
from dataclasses import dataclass, field
from pathlib import Path

REVIEW_MODES = ("workspace", "range", "commit", "scan")

# Paths that are never reviewed: generated output, vendored dependencies, and
# binary or lock artifacts whose diffs carry no reviewable logic.
DEFAULT_EXCLUDES: tuple[str, ...] = (
    "**/node_modules/**",
    "**/__pycache__/**",
    "**/.pytest_cache/**",
    "**/.git/**",
    "**/*.pyc",
    "**/*.min.js",
    "**/*.min.css",
    "**/*.map",
    "**/*.png",
    "**/*.jpg",
    "**/*.jpeg",
    "**/*.gif",
    "**/*.webp",
    "**/*.ico",
    "**/*.pdf",
    "**/*.zip",
    "**/*.exe",
    "**/*.dll",
    "**/*.so",
    "**/*.dylib",
    "**/*.lock",
    "**/package-lock.json",
    "inventory/generated-at.txt",
)

# A file whose diff is enormous is skipped rather than truncated, because a
# partial diff silently hides the remainder of the change.
DEFAULT_MAX_FILE_DIFF_LINES = 4000

# Related-file suffix pairs keep parallel or split definitions in one unit.
_RELATED_SUFFIXES: tuple[tuple[str, str], ...] = (
    (".en.txt", ".zh.txt"),
    ("_en.txt", "_zh.txt"),
    ("_en.md", "_zh.md"),
    (".en.md", ".zh.md"),
)


class SelectionError(RuntimeError):
    """Raised when review scope cannot be determined."""


@dataclass(frozen=True)
class ExcludedPath:
    path: str
    reason: str


@dataclass(frozen=True)
class SelectedFile:
    path: str
    status: str
    diff: str
    additions: int
    deletions: int
    is_untracked: bool = False
    bundle: str = ""

    @property
    def changed_lines(self) -> int:
        return self.additions + self.deletions


@dataclass
class ReviewSelection:
    mode: str
    repo_root: str
    files: list[SelectedFile] = field(default_factory=list)
    excluded: list[ExcludedPath] = field(default_factory=list)
    range_from: str = ""
    range_to: str = ""
    merge_base: str = ""
    commit: str = ""
    warnings: list[str] = field(default_factory=list)

    @property
    def selected_paths(self) -> list[str]:
        return [f.path for f in self.files]

    def to_dict(self) -> dict:
        return {
            "schemaVersion": "review-selection/v1",
            "mode": self.mode,
            "repoRoot": self.repo_root,
            "rangeFrom": self.range_from,
            "rangeTo": self.range_to,
            "mergeBase": self.merge_base,
            "commit": self.commit,
            "files": [
                {
                    "path": f.path,
                    "status": f.status,
                    "additions": f.additions,
                    "deletions": f.deletions,
                    "isUntracked": f.is_untracked,
                    "bundle": f.bundle,
                }
                for f in self.files
            ],
            "excluded": [{"path": e.path, "reason": e.reason} for e in self.excluded],
            "warnings": list(self.warnings),
        }


def _run_git(args: list[str], *, cwd: str) -> str:
    result = subprocess.run(
        ["git", *args],
        cwd=cwd,
        capture_output=True,
        text=True,
        check=False,
    )
    if result.returncode != 0:
        stderr = (result.stderr or "").strip()
        raise SelectionError(f"git {' '.join(args)} failed: {stderr}")
    return result.stdout


def _match_any(path: str, patterns: tuple[str, ...] | list[str]) -> bool:
    normalized = path.replace("\\", "/")
    for pattern in patterns:
        candidate = pattern.replace("\\", "/")
        if fnmatch.fnmatch(normalized, candidate):
            return True
        if candidate.startswith("**/") and fnmatch.fnmatch(normalized, candidate[3:]):
            return True
        # A bare directory pattern such as ``docs`` excludes its whole subtree.
        if not candidate.endswith("/**") and fnmatch.fnmatch(normalized, f"{candidate}/**"):
            return True
    return False


def _count_diff_lines(diff: str) -> tuple[int, int]:
    additions = 0
    deletions = 0
    for line in diff.splitlines():
        if line.startswith("+++") or line.startswith("---"):
            continue
        if line.startswith("+"):
            additions += 1
        elif line.startswith("-"):
            deletions += 1
    return additions, deletions


def _resolve_repo_root(cwd: str) -> str:
    return _run_git(["rev-parse", "--show-toplevel"], cwd=cwd).strip()


def _status_for_paths(repo_root: str, paths: list[str]) -> dict[str, str]:
    output = _run_git(["status", "--porcelain", "--", *paths], cwd=repo_root)
    statuses: dict[str, str] = {}
    for line in output.splitlines():
        if len(line) < 4:
            continue
        code = line[:2].strip()
        raw_path = line[3:]
        # Renames are reported as ``old -> new``; the new path is reviewed.
        if " -> " in raw_path:
            raw_path = raw_path.split(" -> ", 1)[1]
        statuses[raw_path.strip().strip('"')] = code or "M"
    return statuses


def _workspace_paths(repo_root: str) -> list[str]:
    tracked = _run_git(["diff", "--name-only", "HEAD"], cwd=repo_root)
    # ``git diff HEAD`` omits untracked files even though they are part of the
    # working copy under review; list them explicitly.
    untracked = _run_git(
        ["ls-files", "--others", "--exclude-standard"],
        cwd=repo_root,
    )
    paths: list[str] = []
    for block in (tracked, untracked):
        for line in block.splitlines():
            candidate = line.strip()
            if candidate and candidate not in paths:
                paths.append(candidate)
    return paths


def _diff_for_workspace(repo_root: str, path: str) -> str:
    tracked = _run_git(["diff", "HEAD", "--", path], cwd=repo_root)
    if tracked.strip():
        return tracked
    # An untracked file has no diff; treat its full contents as additions.
    absolute = Path(repo_root, path)
    try:
        text = absolute.read_text(encoding="utf-8-sig", errors="replace")
    except OSError:
        return ""
    lines = [f"+{line}" for line in text.splitlines()]
    return "\n".join(
        [
            f"diff --git a/{path} b/{path}",
            "new file mode 100644",
            "--- /dev/null",
            f"+++ b/{path}",
            f"@@ -0,0 +1,{len(lines)} @@",
            *lines,
        ]
    )


def _resolve_range(repo_root: str, from_ref: str, to_ref: str) -> tuple[str, str]:
    merge_base = _run_git(["merge-base", from_ref, to_ref], cwd=repo_root).strip()
    if not merge_base:
        merge_base = from_ref
    return merge_base, to_ref


def select_review_files(
    *,
    repo: str = ".",
    mode: str = "workspace",
    from_ref: str = "",
    to_ref: str = "",
    commit: str = "",
    paths: list[str] | None = None,
    exclude: list[str] | None = None,
    max_file_diff_lines: int = DEFAULT_MAX_FILE_DIFF_LINES,
) -> ReviewSelection:
    """Determine the files under review for the given mode.

    Excluded paths are always reported with a reason. A path is never dropped
    silently, because silent omission is indistinguishable from a clean review.
    """

    if mode not in REVIEW_MODES:
        raise SelectionError(f"unsupported review mode: {mode}")

    repo_root = _resolve_repo_root(repo)
    exclude_patterns = list(DEFAULT_EXCLUDES) + list(exclude or [])
    selection = ReviewSelection(mode=mode, repo_root=repo_root)

    if mode == "workspace":
        candidate_paths = _workspace_paths(repo_root)
    elif mode == "range":
        if not from_ref or not to_ref:
            raise SelectionError("range mode requires both from_ref and to_ref")
        selection.merge_base, selection.range_to = _resolve_range(
            repo_root, from_ref, to_ref
        )
        selection.range_from = from_ref
        diff_range = f"{selection.merge_base}..{to_ref}"
        candidate_paths = _run_git(
            ["diff", "--name-only", diff_range], cwd=repo_root
        ).splitlines()
    elif mode == "commit":
        if not commit:
            raise SelectionError("commit mode requires a commit reference")
        selection.commit = commit
        candidate_paths = _run_git(
            ["show", "--pretty=format:", "--name-only", commit], cwd=repo_root
        ).splitlines()
    else:  # scan
        glob = (paths or ["."])[0]
        candidate_paths = _run_git(["ls-files", glob], cwd=repo_root).splitlines()

    candidate_paths = [p.strip() for p in candidate_paths if p.strip()]
    if paths and mode != "scan":
        wanted = {p.replace("\\", "/") for p in paths}
        candidate_paths = [
            p for p in candidate_paths if p.replace("\\", "/") in wanted
        ]

    statuses = _status_for_paths(repo_root, candidate_paths) if candidate_paths else {}

    for path in candidate_paths:
        if _match_any(path, exclude_patterns):
            selection.excluded.append(ExcludedPath(path, "excluded by pattern"))
            continue

        if mode == "workspace":
            diff = _diff_for_workspace(repo_root, path)
            is_untracked = statuses.get(path, "").startswith("??")
        elif mode == "range":
            diff = _run_git(
                ["diff", f"{selection.merge_base}..{to_ref}", "--", path],
                cwd=repo_root,
            )
            is_untracked = False
        elif mode == "commit":
            diff = _run_git(
                ["show", "--format=", commit, "--", path], cwd=repo_root
            )
            is_untracked = False
        else:
            absolute = Path(repo_root, path)
            try:
                text = absolute.read_text(encoding="utf-8-sig", errors="replace")
            except OSError:
                selection.excluded.append(
                    ExcludedPath(path, "unreadable for full scan")
                )
                continue
            lines = [f"+{line}" for line in text.splitlines()]
            diff = "\n".join(
                [
                    f"diff --git a/{path} b/{path}",
                    f"--- a/{path}",
                    f"+++ b/{path}",
                    f"@@ -0,0 +1,{len(lines)} @@",
                    *lines,
                ]
            )
            is_untracked = False

        if not diff.strip():
            selection.excluded.append(ExcludedPath(path, "no reviewable diff"))
            continue

        additions, deletions = _count_diff_lines(diff)
        if additions + deletions > max_file_diff_lines:
            selection.excluded.append(
                ExcludedPath(
                    path,
                    f"diff exceeds {max_file_diff_lines} lines "
                    f"({additions + deletions}); scope it explicitly",
                )
            )
            continue

        status = statuses.get(path, "")
        if not status:
            status = "A" if mode in ("commit", "scan") else "M"
        selection.files.append(
            SelectedFile(
                path=path,
                status=status,
                diff=diff,
                additions=additions,
                deletions=deletions,
                is_untracked=is_untracked,
            )
        )

    return selection


def bundle_files(files: list[SelectedFile]) -> list[list[SelectedFile]]:
    """Group related files so cross-file changes are reviewed together.

    Bundles are keyed deterministically by the sorted path set, so two runs over
    the same selection produce the same groups.
    """

    by_path = {f.path: f for f in files}
    assigned: set[str] = set()
    bundles: list[list[SelectedFile]] = []

    for file in sorted(files, key=lambda f: f.path):
        if file.path in assigned:
            continue
        group_paths = {file.path}
        for left, right in _RELATED_SUFFIXES:
            if file.path.endswith(left):
                sibling = file.path[: -len(left)] + right
                if sibling in by_path:
                    group_paths.add(sibling)
            if file.path.endswith(right):
                sibling = file.path[: -len(right)] + left
                if sibling in by_path:
                    group_paths.add(sibling)
        assigned.update(group_paths)
        bundles.append([by_path[p] for p in sorted(group_paths)])

    return bundles
