"""Optional external review adapters.

Adapters are never required. Every adapter must fail open to the native engine
because a missing third-party CLI must not block a review.
"""

from .ocr import (
    OcrAdapterResult,
    cross_check_selection,
    normalize_ocr_findings,
    ocr_available,
)

__all__ = [
    "OcrAdapterResult",
    "cross_check_selection",
    "normalize_ocr_findings",
    "ocr_available",
]
