"""Optional adapter for the Alibaba Open Code Review (``ocr``) CLI.

The adapter is a cross-check, not a dependency. When ``ocr`` is present it can
preview file selection and normalise its findings into ``review-finding/v1``.
When it is absent, exits non-zero, or returns an unparseable payload, the
caller keeps the native result and records why the cross-check was skipped.

No provider credentials are read, written, or logged here.
"""

from __future__ import annotations

import json
import shutil
import subprocess
from dataclasses import dataclass, field

from ..engine import CATEGORIES, SEVERITIES, Finding
from ..selector import ReviewSelection

ADAPTER_NAME = "open-code-review"
DEFAULT_TIMEOUT_SECONDS = 120


@dataclass
class OcrAdapterResult:
    """Outcome of an adapter call."""

    available: bool
    used: bool = False
    fallback_reason: str = ""
    findings: list[Finding] = field(default_factory=list)
    reviewable_paths: list[str] = field(default_factory=list)
    raw_warnings: list[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {
            "adapter": ADAPTER_NAME,
            "available": self.available,
            "used": self.used,
            "fallbackReason": self.fallback_reason,
            "reviewablePaths": list(self.reviewable_paths),
            "findings": [f.to_dict() for f in self.findings],
            "warnings": list(self.raw_warnings),
        }


def ocr_available() -> bool:
    """Return whether the optional CLI is on PATH."""

    return shutil.which("ocr") is not None


def _run_ocr(
    args: list[str],
    *,
    cwd: str,
    timeout: int = DEFAULT_TIMEOUT_SECONDS,
) -> tuple[int, str, str]:
    result = subprocess.run(
        ["ocr", *args],
        cwd=cwd,
        capture_output=True,
        text=True,
        timeout=timeout,
        check=False,
    )
    return result.returncode, result.stdout or "", result.stderr or ""


def cross_check_selection(
    selection: ReviewSelection,
    *,
    timeout: int = DEFAULT_TIMEOUT_SECONDS,
) -> OcrAdapterResult:
    """Cross-check selected files against the external CLI's preview.

    The native selection stays authoritative: this only reports the difference.
    """

    if not ocr_available():
        return OcrAdapterResult(
            available=False,
            fallback_reason="ocr CLI not installed; native selection used",
        )

    args = ["delegate", "preview", "--format", "json"]
    if selection.mode == "range" and selection.range_from and selection.range_to:
        args += ["--from", selection.range_from, "--to", selection.range_to]
    elif selection.mode == "commit" and selection.commit:
        args += ["--commit", selection.commit]

    try:
        code, stdout, stderr = _run_ocr(
            args, cwd=selection.repo_root, timeout=timeout
        )
    except (OSError, subprocess.SubprocessError) as exc:
        return OcrAdapterResult(
            available=True,
            fallback_reason=f"ocr preview failed: {exc}; native selection used",
        )

    if code != 0:
        detail = (stderr or "").strip().splitlines()
        reason = detail[0] if detail else f"exit code {code}"
        return OcrAdapterResult(
            available=True,
            fallback_reason=f"ocr preview exited non-zero ({reason}); native selection used",
        )

    try:
        payload = json.loads(stdout)
    except json.JSONDecodeError:
        return OcrAdapterResult(
            available=True,
            fallback_reason="ocr preview returned unparseable JSON; native selection used",
        )

    paths = _extract_reviewable_paths(payload)
    native = set(selection.selected_paths)
    external = set(paths)
    warnings: list[str] = []
    only_native = sorted(native - external)
    only_external = sorted(external - native)
    if only_native:
        warnings.append(
            "reviewed by AER but not listed by ocr: " + ", ".join(only_native)
        )
    if only_external:
        warnings.append(
            "listed by ocr but not reviewed by AER: " + ", ".join(only_external)
        )

    return OcrAdapterResult(
        available=True,
        used=True,
        reviewable_paths=paths,
        raw_warnings=warnings,
    )


def _extract_reviewable_paths(payload: object) -> list[str]:
    """Pull reviewable paths out of the CLI's preview payload."""

    paths: list[str] = []

    def consider(entry: object) -> None:
        if isinstance(entry, str):
            if entry and entry not in paths:
                paths.append(entry)
        elif isinstance(entry, dict):
            for key in ("path", "file", "filename"):
                value = entry.get(key)
                if isinstance(value, str) and value and value not in paths:
                    paths.append(value)
                    return

    if isinstance(payload, dict):
        for key in ("reviewable_files", "reviewableFiles", "files"):
            value = payload.get(key)
            if isinstance(value, list):
                for entry in value:
                    consider(entry)
    elif isinstance(payload, list):
        for entry in payload:
            consider(entry)

    return paths


def normalize_ocr_findings(payload: object) -> list[Finding]:
    """Convert an ``ocr review --format json`` payload into engine findings.

    Unknown severity or category values are mapped onto the closest supported
    value instead of being dropped, so an upstream vocabulary change degrades
    rather than silently discarding findings.
    """

    entries: list[object] = []
    if isinstance(payload, dict):
        for key in ("comments", "findings", "review_comments"):
            value = payload.get(key)
            if isinstance(value, list):
                entries = value
                break
    elif isinstance(payload, list):
        entries = payload

    findings: list[Finding] = []
    for entry in entries:
        if not isinstance(entry, dict):
            continue
        path = str(entry.get("path") or entry.get("file") or "").strip()
        content = str(entry.get("content") or entry.get("message") or "").strip()
        if not path or not content:
            continue
        severity = str(entry.get("severity") or "medium").strip().lower()
        category = str(entry.get("category") or "other").strip().lower()
        if severity not in SEVERITIES:
            severity = "medium"
        if category not in CATEGORIES:
            category = "other"
        findings.append(
            Finding(
                path=path,
                content=content,
                severity=severity,
                category=category,
                evidence=str(
                    entry.get("existing_code") or entry.get("evidence") or ""
                ).strip(),
                suggestion_code=str(entry.get("suggestion_code") or "").strip(),
                detector=ADAPTER_NAME,
                start_line=int(entry.get("start_line") or 0),
                end_line=int(entry.get("end_line") or 0),
            )
        )
    return findings
