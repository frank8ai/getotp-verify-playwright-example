"""Trusted Acceptance Contract v0 (Trust Root of AER Verify).

Core invariant:
A candidate software change must never define or silently modify the acceptance
condition used to certify itself.

Phase-1 Trusted Sources:
1. MAINTAINER_SUPPLIED: operator/maintainer provided outside candidate control.
2. BASE_BRANCH_TRUSTED: loaded from trusted BASE commit tree (.aer/acceptance/*.yml).
"""

from __future__ import annotations

import hashlib
import json
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Mapping

import yaml

ACCEPTANCE_CONTRACT_SCHEMA_VERSION = "acceptance-contract/v0"
VALID_PROTOCOLS = ("PYTEST_TARGET", "EXPLICIT_SCRIPT")
VALID_SOURCES = ("MAINTAINER_SUPPLIED", "BASE_BRANCH_TRUSTED", "OPERATOR_OVERRIDE")
VALID_BASELINE_EXPECTED = ("DEFECT_OBSERVED",)
VALID_CANDIDATE_EXPECTED = ("DEFECT_ABSENT",)


class AcceptanceContractError(ValueError):
    """Raised when an acceptance contract is malformed or invalid."""


@dataclass(frozen=True)
class TrustedAcceptanceContract:
    schema_version: str
    protocol: str
    condition: str
    baseline_expected: str = "DEFECT_OBSERVED"
    candidate_expected: str = "DEFECT_ABSENT"
    source: str = "BASE_BRANCH_TRUSTED"
    source_reference: str | None = None
    target: str | None = None
    description: str | None = None
    contract_sha256: str = ""

    def __post_init__(self) -> None:
        if self.schema_version not in ("acceptance-contract/v0", "acceptance-contract/v1"):
            raise AcceptanceContractError(f"Unsupported schemaVersion: {self.schema_version}")
        if self.protocol not in VALID_PROTOCOLS:
            raise AcceptanceContractError(f"Invalid protocol: {self.protocol}. Must be one of {VALID_PROTOCOLS}")
        if not self.condition or not str(self.condition).strip():
            raise AcceptanceContractError("Contract condition cannot be empty")
        if self.baseline_expected != "DEFECT_OBSERVED":
            raise AcceptanceContractError(f"baselineExpected must be DEFECT_OBSERVED, got {self.baseline_expected}")
        if self.candidate_expected != "DEFECT_ABSENT":
            raise AcceptanceContractError(f"candidateExpected must be DEFECT_ABSENT, got {self.candidate_expected}")
        if self.source not in VALID_SOURCES:
            raise AcceptanceContractError(f"Invalid source: {self.source}. Must be one of {VALID_SOURCES}")

        # Compute contract SHA256 if not set
        if not self.contract_sha256:
            canonical_repr = json.dumps({
                "schemaVersion": self.schema_version,
                "protocol": self.protocol,
                "condition": self.condition,
                "baselineExpected": self.baseline_expected,
                "candidateExpected": self.candidate_expected,
                "target": self.target,
                "description": self.description,
            }, sort_keys=True, separators=(',', ':')).encode('utf-8')
            digest = hashlib.sha256(canonical_repr).hexdigest()
            object.__setattr__(self, "contract_sha256", f"sha256:{digest}")

    def to_dict(self) -> dict[str, Any]:
        data: dict[str, Any] = {
            "schemaVersion": self.schema_version,
            "protocol": self.protocol,
            "condition": self.condition,
            "baselineExpected": self.baseline_expected,
            "candidateExpected": self.candidate_expected,
            "source": self.source,
            "sourceReference": self.source_reference,
            "contractSha256": self.contract_sha256,
        }
        if self.target is not None:
            data["target"] = self.target
        if self.description is not None:
            data["description"] = self.description
        return data

    @classmethod
    def from_dict(cls, data: Mapping[str, Any], *, source: str = "BASE_BRANCH_TRUSTED", source_reference: str | None = None) -> TrustedAcceptanceContract:
        schema_version = str(data.get("schemaVersion") or ACCEPTANCE_CONTRACT_SCHEMA_VERSION)
        protocol = str(data.get("protocol") or "")
        condition = str(data.get("condition") or data.get("command") or data.get("target") or "")
        target = data.get("target")
        if target is not None:
            target = str(target)
        desc = data.get("description")
        if desc is not None:
            desc = str(desc)
        base_exp = str(data.get("baselineExpected") or "DEFECT_OBSERVED")
        cand_exp = str(data.get("candidateExpected") or "DEFECT_ABSENT")
        c_source = str(data.get("source") or source)
        c_ref = data.get("sourceReference") or source_reference
        sha = str(data.get("contractSha256") or "")

        return cls(
            schema_version=schema_version,
            protocol=protocol,
            condition=condition,
            baseline_expected=base_exp,
            candidate_expected=cand_exp,
            source=c_source,
            source_reference=c_ref,
            target=target,
            description=desc,
            contract_sha256=sha,
        )

    @classmethod
    def from_yaml_content(cls, content: str, *, source: str = "BASE_BRANCH_TRUSTED", source_reference: str | None = None) -> TrustedAcceptanceContract:
        raw_hash = f"sha256:{hashlib.sha256(content.encode('utf-8')).hexdigest()}"
        parsed = yaml.safe_load(content)
        if not isinstance(parsed, dict):
            raise AcceptanceContractError("Acceptance contract YAML must be a mapping")
        contract = cls.from_dict(parsed, source=source, source_reference=source_reference)
        # Bind file digest if raw
        object.__setattr__(contract, "contract_sha256", raw_hash)
        return contract


def load_trusted_acceptance_contract(
    base_tree_dir: Path | str,
    *,
    contract_path: str | Path | None = None,
    explicit_contract: TrustedAcceptanceContract | None = None,
) -> TrustedAcceptanceContract | None:
    """Load trusted acceptance contract strictly from base tree or explicit maintainer supply.

    CRITICAL SECURITY INVARIANT:
    Never load from candidate checkout!
    If .aer/acceptance/*.yml exists on base, base copy is authoritative.
    """
    if explicit_contract is not None:
        return explicit_contract

    base_path = Path(base_tree_dir).resolve()
    if contract_path:
        target_path = base_path / contract_path if not Path(contract_path).is_absolute() else Path(contract_path)
        if target_path.is_file():
            rel_ref = target_path.relative_to(base_path).as_posix() if base_path in target_path.parents else str(target_path)
            return TrustedAcceptanceContract.from_yaml_content(
                target_path.read_text(encoding="utf-8"),
                source="BASE_BRANCH_TRUSTED",
                source_reference=rel_ref,
            )
        return None

    # Search for convention: .aer/acceptance/*.yml or .aer/acceptance/*.yaml
    acc_dir = base_path / ".aer" / "acceptance"
    if acc_dir.is_dir():
        for candidate_file in sorted(acc_dir.glob("*.yml")) + sorted(acc_dir.glob("*.yaml")):
            if candidate_file.is_file():
                rel_ref = candidate_file.relative_to(base_path).as_posix()
                return TrustedAcceptanceContract.from_yaml_content(
                    candidate_file.read_text(encoding="utf-8"),
                    source="BASE_BRANCH_TRUSTED",
                    source_reference=rel_ref,
                )

    return None