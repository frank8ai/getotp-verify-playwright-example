"""Session Checkpoint and Recovery Manager (AWR contract inspired).

Enforces the 4-anchor checkpoint contract:
1. contextHash (sha256 digest of consumed context)
2. digest (factual record of completed actions, max 300 chars)
3. nextAction (precise single next action, max 150 chars)
4. openLoops (unresolved loops/todos preventing false completion)
"""

from __future__ import annotations

import json
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


class CheckpointError(ValueError):
    """Raised when checkpoint data violates anchor contracts."""


@dataclass(frozen=True)
class SessionCheckpoint:
    session_id: str
    work_key: str
    context_hash: str
    digest: str
    next_action: str
    open_loops: list[str]
    checkpoint_id: str = ""
    expected_revision: int = 0
    timestamp: str = ""
    metadata: dict[str, Any] = field(default_factory=dict)
    schema_version: str = "session-checkpoint/v1"

    def __post_init__(self) -> None:
        if not self.session_id or not self.session_id.strip():
            raise CheckpointError("sessionId must not be empty")
        if not self.work_key or not self.work_key.strip():
            raise CheckpointError("workKey must not be empty")
        if not self.context_hash.startswith("sha256:") or len(self.context_hash) != 71:
            raise CheckpointError("contextHash must be a valid sha256: prefix hash (71 chars)")
        if not self.digest or not self.digest.strip() or len(self.digest) > 300:
            raise CheckpointError("digest must be non-empty and <= 300 characters")
        if not self.next_action or not self.next_action.strip() or len(self.next_action) > 150:
            raise CheckpointError("nextAction must be non-empty and <= 150 characters")
        if not isinstance(self.open_loops, list):
            raise CheckpointError("openLoops must be a list of strings")
        for loop in self.open_loops:
            if not loop or not loop.strip():
                raise CheckpointError("openLoops cannot contain empty strings")

    def to_dict(self) -> dict[str, Any]:
        ts = self.timestamp or datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")
        cid = self.checkpoint_id or f"chk_{int(datetime.now(timezone.utc).timestamp())}"
        return {
            "schemaVersion": self.schema_version,
            "sessionId": self.session_id,
            "workKey": self.work_key,
            "checkpointId": cid,
            "contextHash": self.context_hash,
            "digest": self.digest,
            "nextAction": self.next_action,
            "openLoops": list(self.open_loops),
            "expectedRevision": self.expected_revision,
            "timestamp": ts,
            "metadata": dict(self.metadata),
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> SessionCheckpoint:
        return cls(
            session_id=str(data.get("sessionId", "")),
            work_key=str(data.get("workKey", "")),
            context_hash=str(data.get("contextHash", "")),
            digest=str(data.get("digest", "")),
            next_action=str(data.get("nextAction", "")),
            open_loops=[str(x) for x in data.get("openLoops", [])],
            checkpoint_id=str(data.get("checkpointId", "")),
            expected_revision=int(data.get("expectedRevision", 0)),
            timestamp=str(data.get("timestamp", "")),
            metadata=dict(data.get("metadata", {})),
            schema_version=str(data.get("schemaVersion", "session-checkpoint/v1")),
        )


def save_checkpoint(checkpoint: SessionCheckpoint, path: str | Path) -> None:
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(
        json.dumps(checkpoint.to_dict(), indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )


def load_checkpoint(path: str | Path) -> SessionCheckpoint:
    target = Path(path)
    if not target.is_file():
        raise CheckpointError(f"Checkpoint file not found: {target}")
    data = json.loads(target.read_text(encoding="utf-8-sig"))
    return SessionCheckpoint.from_dict(data)
