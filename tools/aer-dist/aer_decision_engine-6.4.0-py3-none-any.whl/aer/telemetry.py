"""Minimum Pilot Telemetry Recorder (Task E3 Part C).

Captures structured pilot telemetry in append-only JSONL format adhering to
contracts/acceptance-telemetry.schema.json without general dashboard overhead.
"""

from __future__ import annotations

import json
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from .change_acceptance import ChangeAcceptanceReport

TELEMETRY_SCHEMA_VERSION = "acceptance-telemetry/v1"
DEFAULT_TELEMETRY_PATH = Path("artifacts/aer/acceptance-telemetry.jsonl")


class TelemetryValidationError(ValueError):
    """Raised when telemetry attributes are logically inconsistent or violate contracts."""
    pass


def build_acceptance_telemetry_event(
    report: ChangeAcceptanceReport,
    *,
    event_id: str | None = None,
    started_at: str | None = None,
    ended_at: str | None = None,
    execution_cost_estimate: float | None = None,
    human_decision: str | None = None,
    human_override: bool | None = None,
    reviewer_acceptance_minutes: float | None = None,
    override_reason: str | None = None,
) -> dict[str, Any]:
    """Construct structured pilot telemetry event conforming to acceptance-telemetry/v1."""
    # P0-4: Validate human decision enum
    if human_decision not in ("ACCEPTED", "REJECTED", None):
        raise TelemetryValidationError(
            f"humanDecision must be 'ACCEPTED', 'REJECTED', or null; got {human_decision!r}"
        )

    # P0-4: Validate reviewer duration minutes >= 0
    if reviewer_acceptance_minutes is not None and reviewer_acceptance_minutes < 0:
        raise TelemetryValidationError(
            f"reviewerAcceptanceMinutes must be >= 0 or null; got {reviewer_acceptance_minutes}"
        )

    # P0-4: Derive humanOverride deterministically if not explicitly provided or enforce consistency
    verdict = report.verdict
    derived_override = False
    if human_decision == "ACCEPTED" and verdict == "FAIL":
        derived_override = True  # false-reject candidate signal
    elif human_decision == "REJECTED" and verdict == "PASS":
        derived_override = True  # false-accept candidate signal
    elif human_decision in ("ACCEPTED", "REJECTED") and verdict == "UNKNOWN":
        derived_override = True  # human resolved unknown

    effective_override = human_override if human_override is not None else derived_override

    # Reject logically conflicting human feedback
    if human_decision == "ACCEPTED" and verdict == "PASS" and human_override is True:
        raise TelemetryValidationError("Conflicting human feedback: verdict=PASS and humanDecision=ACCEPTED cannot be an override")
    if human_decision == "REJECTED" and verdict == "FAIL" and human_override is True:
        raise TelemetryValidationError("Conflicting human feedback: verdict=FAIL and humanDecision=REJECTED cannot be an override")

    eid = event_id or f"evt-{uuid.uuid4().hex[:12]}"
    now_ts = datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")
    start_ts = started_at or report.execution_metrics.get("verificationStartedAt") or report.timestamp
    end_ts = ended_at or report.execution_metrics.get("verificationEndedAt") or now_ts

    # Decision coverage classification: PASS and FAIL are definitive COVERED decisions;
    # UNKNOWN represents evidence insufficiency.
    decision_coverage = "COVERED" if report.verdict in ("PASS", "FAIL") else "UNKNOWN"

    latency_ms = report.execution_metrics.get("verificationLatencyMs") or report.execution_metrics.get("totalDurationMs", 0.0)

    cost_val = float(execution_cost_estimate) if execution_cost_estimate is not None else None

    return {
        "schemaVersion": TELEMETRY_SCHEMA_VERSION,
        "eventId": eid,
        "repository": report.repository,
        "baselineSha": report.baseline.sha,
        "candidateSha": report.candidate.sha,
        "verdict": report.verdict,
        "decisionCoverage": decision_coverage,
        "verificationStartedAt": start_ts,
        "verificationEndedAt": end_ts,
        "verificationLatencyMs": float(latency_ms),
        "executionCostEstimate": cost_val,
        "reasons": list(report.reasons),
        "humanDecision": human_decision,
        "humanOverride": bool(effective_override),
        "reviewerAcceptanceMinutes": float(reviewer_acceptance_minutes) if reviewer_acceptance_minutes is not None else None,
        "overrideReason": override_reason,
        "createdAt": now_ts,
    }


def record_acceptance_telemetry(
    report: ChangeAcceptanceReport,
    output_path: Path | str | None = None,
    *,
    event_id: str | None = None,
    started_at: str | None = None,
    ended_at: str | None = None,
    execution_cost_estimate: float | None = None,
    human_decision: str | None = None,
    human_override: bool | None = None,
    reviewer_acceptance_minutes: float | None = None,
    override_reason: str | None = None,
) -> dict[str, Any]:
    """Append a structured pilot telemetry event to the JSONL log file."""
    event = build_acceptance_telemetry_event(
        report,
        event_id=event_id,
        started_at=started_at,
        ended_at=ended_at,
        execution_cost_estimate=execution_cost_estimate,
        human_decision=human_decision,
        human_override=human_override,
        reviewer_acceptance_minutes=reviewer_acceptance_minutes,
        override_reason=override_reason,
    )

    target = Path(output_path) if output_path else DEFAULT_TELEMETRY_PATH
    target.parent.mkdir(parents=True, exist_ok=True)

    line = json.dumps(event, ensure_ascii=False) + "\n"
    with open(target, "a", encoding="utf-8") as f:
        f.write(line)

    return event
