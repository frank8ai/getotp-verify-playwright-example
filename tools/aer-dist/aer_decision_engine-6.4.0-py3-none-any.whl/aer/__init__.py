"""AER deterministic decision engine."""

from .acceptance import AcceptanceBindingReport, verify_acceptance_bindings
from .acceptance_brief import render_acceptance_brief
from .antithesis import (
    SUPPORTED_ATTACK_CLASSES,
    UNSUPPORTED_ATTACK_CLASSES,
    analyze_added_test,
    analyze_test_diff_integrity,
)
from .attribution import CandidateSurface, build_evidence
from .baseline import capture_baseline, environment_digest, render_result_card
from .change_acceptance import (
    ChangeAcceptanceReport,
    evaluate_change_acceptance,
    run_change_acceptance,
)
from .checkpoint import SessionCheckpoint, load_checkpoint, save_checkpoint
from .context_compiler import (
    BudgetExceededError,
    ContextError,
    ContextPacket,
    compile_l0_context,
    compile_l1_context,
    estimate_tokens,
)
from .decision import (
    Decision,
    DecisionResult,
    EvidenceBundle,
    TaskContract,
    evaluate_decision,
)
from .telemetry import (
    build_acceptance_telemetry_event,
    record_acceptance_telemetry,
)

__all__ = [
    "AcceptanceBindingReport",
    "BudgetExceededError",
    "CandidateSurface",
    "ChangeAcceptanceReport",
    "ContextError",
    "ContextPacket",
    "Decision",
    "DecisionResult",
    "EvidenceBundle",
    "SUPPORTED_ATTACK_CLASSES",
    "SessionCheckpoint",
    "TaskContract",
    "UNSUPPORTED_ATTACK_CLASSES",
    "analyze_added_test",
    "analyze_test_diff_integrity",
    "build_acceptance_telemetry_event",
    "build_evidence",
    "capture_baseline",
    "compile_l0_context",
    "compile_l1_context",
    "environment_digest",
    "estimate_tokens",
    "evaluate_change_acceptance",
    "evaluate_decision",
    "load_checkpoint",
    "record_acceptance_telemetry",
    "render_acceptance_brief",
    "render_result_card",
    "run_change_acceptance",
    "save_checkpoint",
    "verify_acceptance_bindings",
]
